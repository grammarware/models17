/**
 * <copyright>
 * Copyright (c) 2010-2014 Henshin developers. All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 which 
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * </copyright>
 */
package my.example;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.bpmn2.Bpmn2Package;
import org.eclipse.bpmn2.di.BPMNDiagram;
import org.eclipse.bpmn2.util.Bpmn2ResourceFactoryImpl;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.emf.henshin.interpreter.EGraph;
import org.eclipse.emf.henshin.interpreter.Engine;
import org.eclipse.emf.henshin.interpreter.Match;
import org.eclipse.emf.henshin.interpreter.RuleApplication;
import org.eclipse.emf.henshin.interpreter.UnitApplication;
import org.eclipse.emf.henshin.interpreter.impl.EGraphImpl;
import org.eclipse.emf.henshin.interpreter.impl.EngineImpl;
import org.eclipse.emf.henshin.interpreter.impl.LoggingApplicationMonitor;
import org.eclipse.emf.henshin.interpreter.impl.RuleApplicationImpl;
import org.eclipse.emf.henshin.interpreter.impl.UnitApplicationImpl;
import org.eclipse.emf.henshin.interpreter.util.InterpreterUtil;
import org.eclipse.emf.henshin.model.Module;
import org.eclipse.emf.henshin.model.Parameter;
import org.eclipse.emf.henshin.model.Rule;
import org.eclipse.emf.henshin.model.Unit;
import org.eclipse.emf.henshin.model.resource.HenshinResourceSet;
import org.eclipse.emf.henshin.trace.TracePackage;
import org.eclipse.uml2.uml.Association;
import org.eclipse.uml2.uml.Class;
import org.eclipse.uml2.uml.CommunicationPath;
import org.eclipse.uml2.uml.Dependency;
import org.eclipse.uml2.uml.Deployment;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Model;
import org.eclipse.uml2.uml.Node;
import org.eclipse.uml2.uml.Operation;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.Profile;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.UMLPackage;
import org.junit.Test;

import carisma.profile.umlsec.rabac.RabacPackage;
import carisma.profile.umlsec.rabac.abac;
import carisma.profile.umlsec.rabac.abacRequire;
import carisma.profile.umlsec.rabac.impl.abacRequireImpl;
import carisma.profile.umlsec.Internet;
import carisma.profile.umlsec.UmlsecPackage;
import carisma.profile.umlsec.call;
import carisma.profile.umlsec.critical;
import carisma.profile.umlsec.encrypted;
import carisma.profile.umlsec.integrity;
import carisma.profile.umlsec.secrecy;
import carisma.profile.umlsec.send;
import carisma.profile.umlsec.rabac.UMLsec;

/**
 * SecBPMN2 to UMLsec.
 * 
 * @author Qusai Ramadan
 */
public class BpmnToUml {

	public static final String PATH = "src/my/example";
	public static final String EXAMPLE = "example1.bpmn";
	public static List<EObject> objects = new ArrayList<EObject>();

	/**
	 * Run the Ecore2UML conversion.
	 * 
	 * @param path
	 *            Relative path to the model files.
	 * @param ecore
	 *            The Ecore file.
	 * @param saveResult
	 *            Whether the result should be saved.
	 */
	public static void run(String path, String bpmnModel, boolean saveResult) {
		UMLPackage.eINSTANCE.getName();
		Bpmn2Package.eINSTANCE.getName();
		TracePackage.eINSTANCE.getName();
		UmlsecPackage.eINSTANCE.getName();
		RabacPackage.eINSTANCE.getName();

		// Load the transformation module and the input model:
		HenshinResourceSet rs = new HenshinResourceSet(path);
		rs.getPackageRegistry().put("http://www.omg.org/spec/BPMN/20100524/MODEL-XMI", Bpmn2Package.eINSTANCE);
		rs.getPackageRegistry().put("http://www.eclipse.org/uml2/2.0.0/UML", UMLPackage.eINSTANCE);
		rs.getPackageRegistry().put("http://www.umlsec.de/profiles/UMLsec", UmlsecPackage.eINSTANCE);
		rs.getPackageRegistry().put("http://www.umlsec.de/profiles/UMLsec/RABAC", RabacPackage.eINSTANCE);
		rs.registerDynamicEPackages("secbpmn.ecore");

		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("bpmn", new Bpmn2ResourceFactoryImpl());
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("uml", new XMIResourceFactoryImpl());

		Resource exampleModel = rs.getResource(bpmnModel);
		Engine engine = new EngineImpl();
		EGraph graph = new EGraphImpl(exampleModel);

		
		Module module_Intial = rs.getModule("GR1_intializing.henshin", false);
		Module module_ClassOp = rs.getModule("GR2_classOperation.henshin", false);
		Module module_Assoc = rs.getModule("GR3_associations.henshin", false);
		Module module_Dependency = rs.getModule("GR4_dependency.henshin", false);
		Module module_ABAC = rs.getModule("GR5_abac.henshin", false);
		Module module_SecureDependency = rs.getModule("GR5_secureDependency.henshin", false);
		Module module_SecureLinks = rs.getModule("GR6_secureLinks.henshin", false);
		Module module_SecureLinks2 = rs.getModule("GR7_secureLinks2.henshin", false);
		Module module_SecureLinks3 = rs.getModule("GR7_secureLinks3.henshin", false);
		Module module_SecureLinks4 = rs.getModule("GR7_secureLinks4.henshin", false);

//		for (Unit unit : module_Intial.getUnits()) {	
//			UnitApplication applyProfileApp = new UnitApplicationImpl(engine, graph, unit, null);
//			InterpreterUtil.executeOrDie(applyProfileApp);
//
//		
//		}
		

		// **************************************************************************************************************************/
		// **************************************************************************************************************************/
		// *****************Add Profiles to  (EGraph instance)**********************************************************/
		// **************************************************************************************************************************/
		// **************************************************************************************************************************/

		/*-----------------------------------------------Add UMLsec graph to input graph (EGraph instance)--------------------------------------------------*/

		Resource umlSecProfileResource = rs
				.createResource(URI.createURI("platform:/plugin/carisma.profile.umlsec/profile/UMLsec.profile.uml"));
		try {
			umlSecProfileResource.load(Collections.EMPTY_MAP);
			graph.addTree((Profile) umlSecProfileResource.getContents().get(0));
		} catch (IOException e) {
			e.printStackTrace();
		}

		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------------------------------Add RABAC graph to input graph (EGraph instance)--------------------------------------------------*/

		Resource rabacProfileResource = rs.createResource(
				URI.createURI("platform:/plugin/carisma.profile.umlsec.rabac/profile/RABAC.profile.uml"));
		try {
			rabacProfileResource.load(Collections.EMPTY_MAP);
			graph.addTree((Profile) rabacProfileResource.getContents().get(0));
		} catch (IOException e) {
			e.printStackTrace();
		}

		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		// **************************************************************************************************************************/
		// *****************************************Initializing Group: (A)******************************************************/
		// **************************************************************************************************************************/


		/*--------------------------------------create Model------------------------------------------------------------------*/
		Unit createModelUnit = module_Intial.getUnit("CreateModel");
		UnitApplication createUmlModelUnitApp = new UnitApplicationImpl(engine, graph, createModelUnit, null);
		InterpreterUtil.executeOrDie(createUmlModelUnitApp);

		/*--------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------Apply Profiles------------------------------------------------------------------*/
		Unit applyProfileUnit = module_Intial.getUnit("ApplyAbacProfile");
		UnitApplication applyProfileApp = new UnitApplicationImpl(engine, graph, applyProfileUnit, null);
		InterpreterUtil.executeOrDie(applyProfileApp);

		Unit applyProfileUMLsecUnit = module_Intial.getUnit("ApplyUMLsecProfile");
		UnitApplication applyProfileUMLsecApp = new UnitApplicationImpl(engine, graph, applyProfileUMLsecUnit, null);
		InterpreterUtil.executeOrDie(applyProfileUMLsecApp);
		/*--------------------------------------------------------------------------------------------------------------------*/

		
		/*----------------------------------------------------------------Add abac check----------------------------------------------------------------------*/

		Rule addAbacToRoleUnit = (Rule) module_Intial.getUnit("AddAbacToRole");
		RuleApplication addAbacToRoleApp = new RuleApplicationImpl(engine, graph, addAbacToRoleUnit, null);
		addAbacToRoleApp.execute(null);

		Match matchClassRule1 = addAbacToRoleApp.getResultMatch();
		EObject abac = (EObject) matchClassRule1.getParameterValues().get(0);
		addToResource(abac);

		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*----------------------------------------------------------------Add secure dependency check----------------------------------------------------------------------*/

		Rule addSecureDependencyUnit = (Rule) module_Intial.getUnit("AddSecureDependencyCheck");
		RuleApplication addSecureDependencyApp = new RuleApplicationImpl(engine, graph, addSecureDependencyUnit, null);
		addSecureDependencyApp.execute(null);

		Match matchClassDepCheck = addSecureDependencyApp.getResultMatch();
		EObject secureDep = (EObject) matchClassDepCheck.getParameterValues().get(0);
		addToResource(secureDep);
		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*----------------------------------------------------------------Add SecureLinks----------------------------------------------------------------------*/

		Rule addSecureLinksUnit = (Rule) module_SecureLinks.getUnit("AddSecureLinks");
		RuleApplication addSecuerLinksApp = new RuleApplicationImpl(engine, graph, addSecureLinksUnit, null);
		addSecuerLinksApp.execute(null);

		Match matchSecureLink = addSecuerLinksApp.getResultMatch();
		EObject secureLink = (EObject) matchSecureLink.getParameterValues().get(0);
		addToResource(secureLink);

		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/
			 
			 
		// **************************************************************************************************************************/
		// ******************************************Class Operation Group : (A) Create UMLsec Classes and operations****************/
		// **************************************************************************************************************************/
		
		/*--------------------------------------create participant------------------------------------------------------------------*/
		Unit createParticipantUnit = module_ClassOp.getUnit("CreateParticipant");
		UnitApplication createParticipantApp = new UnitApplicationImpl(engine, graph, createParticipantUnit, null);
		InterpreterUtil.executeOrDie(createParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create lane class------------------------------------------------------------------*/
		Unit createLaneUnit = module_ClassOp.getUnit("CreateLane");
		UnitApplication createLaneApp = new UnitApplicationImpl(engine, graph, createLaneUnit, null);
		InterpreterUtil.executeOrDie(createLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------------create Data object  class-----------------------------------------------------------*/
		Unit createDataObjectInputUnit = module_ClassOp.getUnit("CreateDataObject");
		UnitApplication createDataObjectInputApp = new UnitApplicationImpl(engine, graph, createDataObjectInputUnit,
				null);
		InterpreterUtil.executeOrDie(createDataObjectInputApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
	
		// *********************Class Operation Group : (B) Transform Event to operations**********************************************/
		// **************************************************************************************************************************/
		
		/*--------------------------------------create operation in participant class-----------------------------------------------*/
		Unit createOperationUnit = module_ClassOp.getUnit("CreateOperation");
		UnitApplication createOperationApp = new UnitApplicationImpl(engine, graph, createOperationUnit, null);
		InterpreterUtil.executeOrDie(createOperationApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create operation in lane class-----------------------------------------------*/
		Unit createOperationsLaneUnit = module_ClassOp.getUnit("CreateOperationsLane");
		UnitApplication createOperationsLaneApp = new UnitApplicationImpl(engine, graph, createOperationsLaneUnit,
				null);
		InterpreterUtil.executeOrDie(createOperationsLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/	

		/*--------------------------------------create Start Event operation in participant class-----------------------------------*/
		Unit createStartEventParticipantUnit = module_ClassOp.getUnit("CreateStartEventParticipant");
		UnitApplication createStartEventParticipantApp = new UnitApplicationImpl(engine, graph,
				createStartEventParticipantUnit, null);
		InterpreterUtil.executeOrDie(createStartEventParticipantApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create Start Event operation in lane class------------------------------------------*/
		Unit createStartEventLaneUnit = module_ClassOp.getUnit("CreateStartEventLane");
		UnitApplication createStartEventLaneApp = new UnitApplicationImpl(engine, graph, createStartEventLaneUnit,
				null);
		InterpreterUtil.executeOrDie(createStartEventLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create End Throw Event operation in Participant class-------------------------------*/
		Unit createEndEventParticipantUnit = module_ClassOp.getUnit("CreateEndEventParticipant");
		UnitApplication createEndEventParticipantApp = new UnitApplicationImpl(engine, graph,
				createEndEventParticipantUnit, null);
		InterpreterUtil.executeOrDie(createEndEventParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create End Throw Event operation in Lane class--------------------------------------*/
		Unit createEndEventLaneUnit = module_ClassOp.getUnit("CreateEndEventLane");
		UnitApplication createEndEventLaneApp = new UnitApplicationImpl(engine, graph, createEndEventLaneUnit, null);
		InterpreterUtil.executeOrDie(createEndEventLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------------create Intermediate catch Event operation in Participant class----------------------*/
		Unit createIntermediateEventParticipantUnit = module_ClassOp.getUnit("CreateIntermediateEventParticipant");
		UnitApplication createIntermediateEventParticipantApp = new UnitApplicationImpl(engine, graph,
				createIntermediateEventParticipantUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateEventParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create Intermediate catch Event operation in Lane class-----------------------------*/
		Unit createIntermediateEventLaneUnit = module_ClassOp.getUnit("CreateIntermediateEventLane");
		UnitApplication createIntermediateEventLaneApp = new UnitApplicationImpl(engine, graph,
				createIntermediateEventLaneUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateEventLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------create Intermediate Throw Event operation in Participant class----------------------*/
		Unit createIntermediateThrowEventParticipantUnit = module_ClassOp.getUnit("CreateIntermediateThrowEventParticipant");
		UnitApplication createIntermediateThrowEventParticipantApp = new UnitApplicationImpl(engine, graph,
				createIntermediateThrowEventParticipantUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateThrowEventParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create Intermediate Throw Event operation in Lane class-----------------------------*/
		Unit createIntermediateThrowEventLaneUnit = module_ClassOp.getUnit("CreateIntermediateThrowEventLane");
		UnitApplication createIntermediateThrowEventLaneApp = new UnitApplicationImpl(engine, graph,
				createIntermediateThrowEventLaneUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateThrowEventLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		
		// *********************Class Operation Parameters Group : (C) Transform Messages and Data/Input/out to parameters***********/
		// **************************************************************************************************************************/	
		
		/*--------------------------------------create Task Message Input Parameters-------------------------------------*/
		Unit taskMSGInputParametersUnit = module_ClassOp.getUnit("TaskMSGInputParameters");
		UnitApplication taskMSGInputParametersUnitApp = new UnitApplicationImpl(engine, graph, taskMSGInputParametersUnit,
				null);
		InterpreterUtil.executeOrDie(taskMSGInputParametersUnitApp);
		/*-------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------------create Task Message Output Parameters----------------------------------*/
		Unit taskMSGOutParametersUnit = module_ClassOp.getUnit("TaskMSGOutParameters");
		UnitApplication taskMSGOutParametersUnitApp = new UnitApplicationImpl(engine, graph, taskMSGOutParametersUnit,
				null);
		InterpreterUtil.executeOrDie(taskMSGOutParametersUnitApp);
		/*-------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------------create Start Event Input MSg Parameters--------------------------------*/
		Unit startEventParametersUnit = module_ClassOp.getUnit("StartEventInputParameters");
		UnitApplication startEventParametersUnitApp = new UnitApplicationImpl(engine, graph, startEventParametersUnit,
				null);
		InterpreterUtil.executeOrDie(startEventParametersUnitApp);
		/*-------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create End Event Output MSg Parameters---------------------------------*/
		Unit endEventParametersUnit = module_ClassOp.getUnit("EndEventOutParameters");
		UnitApplication endEventParametersApp = new UnitApplicationImpl(engine, graph, endEventParametersUnit, null);
		InterpreterUtil.executeOrDie(endEventParametersApp);
		/*-------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create Intermediate Catch Event Input MSg Parameters-------------------*/
		Unit intermediateCatchEventParametersUnit = module_ClassOp.getUnit("IntermediateCatchEventInputParameters");
		UnitApplication intermediateCatchEventParametersApp = new UnitApplicationImpl(engine, graph,
				intermediateCatchEventParametersUnit, null);
		InterpreterUtil.executeOrDie(intermediateCatchEventParametersApp);
		/*-------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------create Intermediate throw Event Output MSg Parameters------------------*/
		Unit intermediateThrowEventParametersUnit = module_ClassOp.getUnit("IntermediateThrowEventOutParameters");
		UnitApplication intermediateThrowEventParametersApp = new UnitApplicationImpl(engine, graph,
				intermediateThrowEventParametersUnit, null);
		InterpreterUtil.executeOrDie(intermediateThrowEventParametersApp);
		/*-------------------------------------------------------------------------------------------------------------*/
		
		

		// *******Class Operation Group : (D)Transform data input/output to parameters in the operations**/
		// ***********************************************************************************************/

		/*-------------------------create Task Data Input Parameter ----------------------------------------------------------------*/
		Unit createTaskInputParameterParticipantUnit = module_ClassOp.getUnit("CreateTaskInputParameter");
		UnitApplication createTaskInputParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createTaskInputParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createTaskInputParameterParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------create Task Data Output Parameter --------------------------------------------------------------------*/
		Unit createTaskOutParameterParticipantUnit = module_ClassOp.getUnit("CreateTaskOutParameter");
		UnitApplication createTaskOutParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createTaskOutParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createTaskOutParameterParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/


		/*--------------------create Start Event Data Output Parameter -------------------------------------------------------------*/
		Unit createStartInputParameterParticipantUnit = module_ClassOp.getUnit("CreateStartOutParameter");
		UnitApplication createStartInputParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createStartInputParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createStartInputParameterParticipantApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------create Intermediate catch Data Output Parameter -------------------------------------------------------*/
		Unit createIntermediateCatchOutParameterParticipantUnit = module_ClassOp
				.getUnit("CreateIntermediateCatchOutParameter");
		UnitApplication createIntermediateCatchOutParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createIntermediateCatchOutParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateCatchOutParameterParticipantApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------create End Event Data Input Parameter -------------------------------------------------------------*/
		Unit createEndInputParameterParticipantUnit = module_ClassOp.getUnit("CreateEndInputParameter");
		UnitApplication createEndInputParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createEndInputParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createEndInputParameterParticipantApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------create Intermediate throw Data Input Parameter --------------------------------------------------------*/
		Unit createIntermediateThrowInputParameterUnit = module_ClassOp
				.getUnit("CreateIntermediateThrowInputParameter");
		UnitApplication createIntermediateThrowInputParameterUnitApp = new UnitApplicationImpl(engine, graph,
				createIntermediateThrowInputParameterUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateThrowInputParameterUnitApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/


		// **Class Operation Group : (E) Transform Reference to Data Objects to parameters in the operations********************************************/
		// *********************************************************************************************************************************************/


		/*---------------create Task Reference Data Input Parameter ----------------------------------------------------------------*/
		Unit createRefInputParameterParticipantUnit = module_ClassOp.getUnit("CreateTaskRefInputParameter");
		UnitApplication createRefInputParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createRefInputParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createRefInputParameterParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------create Task Reference Data Output Parameter -----------------------------------------------------------*/
		Unit createRefOutParameterParticipantUnit = module_ClassOp.getUnit("CreateTaskRefOutParameter");
		UnitApplication createRefOutParameterParticipantApp = new UnitApplicationImpl(engine, graph,
				createRefOutParameterParticipantUnit, null);
		InterpreterUtil.executeOrDie(createRefOutParameterParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------create End Reference Data Output Parameter ---------------------------------------------------------*/
		Unit createEndRefInputParameterUnit = module_ClassOp.getUnit("CreateEndRefInputParameter");
		UnitApplication createEndRefInputParameterUnitApp = new UnitApplicationImpl(engine, graph,
				createEndRefInputParameterUnit, null);
		InterpreterUtil.executeOrDie(createEndRefInputParameterUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------create Start Reference Data Output Parameter ---------------------------------------------------------*/
		Unit createStartRefOutParameterUnit = module_ClassOp.getUnit("CreateStartRefOutParameter");
		UnitApplication createStartRefOutParameterUnitApp = new UnitApplicationImpl(engine, graph,
				createStartRefOutParameterUnit, null);
		InterpreterUtil.executeOrDie(createStartRefOutParameterUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------create Intermediate Catch Reference Data Output Parameter ---------------------------------------------------------*/
		Unit createIntermediateThrowRefInputParameterUnit = module_ClassOp.getUnit("CreateIntermediateThrowRefInputParameter");
		UnitApplication createIntermediateThrowRefInputParameterUnitApp = new UnitApplicationImpl(engine, graph,
				createIntermediateThrowRefInputParameterUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateThrowRefInputParameterUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------create Intermediate Throw Reference Data Output Parameter ---------------------------------------------------------*/
		Unit createIntermediateCatchRefOutParameterUnit = module_ClassOp.getUnit("CreateIntermediateCatchRefOutParameter");
		UnitApplication createIntermediateCatchRefOutParameterUnitApp = new UnitApplicationImpl(engine, graph,
				createIntermediateCatchRefOutParameterUnit, null);
		InterpreterUtil.executeOrDie(createIntermediateCatchRefOutParameterUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		

		// ***********************Associations Group 3: (A) Transform Message Flows to associations**********************************/
		// **************************************************************************************************************************/
		/*--------------------------------create association between Participant (Task out message flow) and message class---------------*/
		Unit createMessageAssociationTaskOutParticipantUnit = module_Assoc.getUnit("CreateMessageAssociationTaskOutParticipant");
		UnitApplication createMessageAssociationTaskOutParticipantUnitApp = new UnitApplicationImpl(engine, graph,
				createMessageAssociationTaskOutParticipantUnit, null);
		InterpreterUtil.executeOrDie(createMessageAssociationTaskOutParticipantUnitApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------create association between Lane (Task out message flow) and message class------------------*/
		Unit createMessageAssociationTaskOutLaneUnit = module_Assoc.getUnit("CreateMessageAssociationTaskOutLane");
		UnitApplication createMessageAssociationTaskOutLaneUnitApp = new UnitApplicationImpl(engine, graph,
				createMessageAssociationTaskOutLaneUnit, null);
		InterpreterUtil.executeOrDie(createMessageAssociationTaskOutLaneUnitApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------create association between Participant (Task input message flow) and message class---------------*/
		Unit createMessageAssociationTaskInputParticipantUnit = module_Assoc.getUnit("CreateMessageAssociationTaskInputParticipant");
		UnitApplication createMessageAssociationTaskInputParticipantUnitApp = new UnitApplicationImpl(engine, graph,
				createMessageAssociationTaskInputParticipantUnit, null);
		InterpreterUtil.executeOrDie(createMessageAssociationTaskInputParticipantUnitApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------create association between Lane  (Task input message flow) and message class---------------*/
		Unit createMessageAssociationTaskInputLaneUnit = module_Assoc.getUnit("CreateMessageAssociationTaskInputLane");
		UnitApplication createMessageAssociationTaskInputLaneUnitApp = new UnitApplicationImpl(engine, graph,
				createMessageAssociationTaskInputLaneUnit, null);
		InterpreterUtil.executeOrDie(createMessageAssociationTaskInputLaneUnitApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------create association between Participant (start catch event) and message class---------------*/
		Unit createMessageAssociationUnit = module_Assoc.getUnit("CreateMessageAssociation");
		UnitApplication createMessageAssociationApp = new UnitApplicationImpl(engine, graph,
				createMessageAssociationUnit, null);
		InterpreterUtil.executeOrDie(createMessageAssociationApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------create association between  Lane (start  event) and message class---------------*/
		 Unit createMessageAssociationLaneUnit =
		 module_Assoc.getUnit("CreateMessageAssociationLane");
		 UnitApplication createMessageAssociationLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createMessageAssociationLaneUnit, null);
		 InterpreterUtil.executeOrDie(createMessageAssociationLaneApp);
		 /*---------------------------------------------------------------------------------------------------------------------------*/

		/*---------------------------------create association between Participant (End throw event) and message class---------------*/
		Unit createMessageEndAssociationUnit = module_Assoc.getUnit("CreateMessageEndAssociation");
		UnitApplication createMessageEndAssociationApp = new UnitApplicationImpl(engine, graph,
				createMessageEndAssociationUnit, null);
		InterpreterUtil.executeOrDie(createMessageEndAssociationApp);
		/*----------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------create association between Lane (End throw event) and message class------------------*/
		 Unit createMessageEndAssociationLaneUnit =
		 module_Assoc.getUnit("CreateMessageEndAssociationLane");
		 UnitApplication createMessageEndAssociationLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createMessageEndAssociationLaneUnit, null);
		 InterpreterUtil.executeOrDie(createMessageEndAssociationLaneApp);
		 /*----------------------------------------------------------------------------------------------------------------------------*/

		/*------------------------create association between Participant (Intermediate Catch event) and message class----------------*/
		Unit createMessageIntermediateCatchAssociationUnit = module_Assoc
				.getUnit("CreateMessageIntermediateCatchAssociation");
		UnitApplication createMessageIntermediateCatchAssociationApp = new UnitApplicationImpl(engine, graph,
				createMessageIntermediateCatchAssociationUnit, null);
		InterpreterUtil.executeOrDie(createMessageIntermediateCatchAssociationApp);
		/*----------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------create association between
		 Lane (Intermediate event) and message class---------------*/
		 Unit createMessageIntermediateCatchAssociationLaneUnit =
		 module_Assoc.getUnit("CreateMessageIntermediateCatchAssociationLane");
		 UnitApplication createMessageIntermediateCatchAssociationLaneApp =
		 new UnitApplicationImpl(engine, graph,
		 createMessageIntermediateCatchAssociationLaneUnit, null);
		 InterpreterUtil.executeOrDie(createMessageIntermediateCatchAssociationLaneApp);
		 /*----------------------------------------------------------------------------------------------------------------------------*/

		/*----------------------------------create association between Participant (End throw event) and message class---------------*/
		Unit createMessageIntermediateThrowAssociationUnit = module_Assoc
				.getUnit("CreateMessageIntermediateThrowAssociation");
		UnitApplication createMessageIntermediateThrowAssociationApp = new UnitApplicationImpl(engine, graph,
				createMessageIntermediateThrowAssociationUnit, null);
		InterpreterUtil.executeOrDie(createMessageIntermediateThrowAssociationApp);
		/*----------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------create association between
		 Lane (End throw event) and message class------------------*/
		 Unit createMessageIntermediateThrowAssociationLaneUnit =
		 module_Assoc.getUnit("CreateMessageIntermediateThrowAssociationLane");
		 UnitApplication createMessageIntermediateThrowAssociationLaneApp =
		 new UnitApplicationImpl(engine, graph,
		 createMessageIntermediateThrowAssociationLaneUnit, null);
		 InterpreterUtil.executeOrDie(createMessageIntermediateThrowAssociationLaneApp);
		 /*----------------------------------------------------------------------------------------------------------------------------*/



		// *******************************Associations Group 3: (B) Transform Data Input/Output to associations*********************/
		// **************************************************************************************************************************/


		/*---------------Transform Data Input Association into association between class Participant and DataObject-----------------*/
		Unit createAssociationDataInputParticipantUnit = module_Assoc.getUnit("CreateAssociationDataInputParticipant");
		UnitApplication createAssociationDataInputParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*---------------Transform Data Output Association into association between class Participant and DataObject-----------------*/
		Unit createAssociationDataOutParticipantUnit = module_Assoc.getUnit("CreateAssociationDataOutParticipant");
		UnitApplication createAssociationDataOutParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Input Association into association between class Lane and DataObject------------------------*/
		 Unit createAssociationDataInputLaneUnit =
		 module_Assoc.getUnit("CreateAssociationDataInputLane");
		 UnitApplication createAssociationDataInputLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createAssociationDataInputLaneUnit, null);
		 InterpreterUtil.executeOrDie(createAssociationDataInputLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------*/
		
		 /*---------------Transform Data Output Association into association between class Lane and DataObject-----------------------*/
		 Unit createAssociationDataOutLaneUnit =
		 module_Assoc.getUnit("CreateAssociationDataOutLane");
		 UnitApplication createAssociationDataOutLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createAssociationDataOutLaneUnit, null);
		 InterpreterUtil.executeOrDie(createAssociationDataOutLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------*/
		 
		 
		/*---------------Transform Data Output Association into association between class Participant and DataObject (start event)-----------------*/
		Unit createAssociationDataOutStartParticipantUnit = module_Assoc.getUnit("CreateAssociationDataOutStartParticipant");
		UnitApplication createAssociationDataOutStartParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutStartParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutStartParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (start event)-----------------*/
		Unit createAssociationDataOutStartLaneUnit = module_Assoc.getUnit("CreateAssociationDataOutStartLane");
		UnitApplication createAssociationDataOutStartLaneUnitApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutStartLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutStartLaneUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*---------------Transform Data Output Association into association between class Participant and DataObject (catch event)-----------------*/
		Unit createAssociationDataOutCatchParticipantUnit = module_Assoc.getUnit("CreateAssociationDataOutCatchParticipant");
		UnitApplication createAssociationDataOutCatchParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutCatchParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutCatchParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (catch event)-----------------*/
		Unit createAssociationDataOutCatchLaneUnit = module_Assoc.getUnit("CreateAssociationDataOutCatchLane");
		UnitApplication createAssociationDataOutCatchLaneUnitApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutCatchLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutCatchLaneUnitApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Participant and DataObject (End event)-----------------*/
		Unit createAssociationDataInputEndParticipantUnit = module_Assoc.getUnit("CreateAssociationDataInputEndParticipant");
		UnitApplication createAssociationDataInputEndParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputEndParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputEndParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (End event)-----------------*/
		Unit createAssociationDataInputEndLaneUnit = module_Assoc.getUnit("CreateAssociationDataInputEndLane");
		UnitApplication createAssociationDataInputEndLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputEndLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputEndLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Participant and DataObject (Throw event)-----------------*/
		Unit createAssociationDataInputThrowParticipantUnit = module_Assoc.getUnit("CreateAssociationDataInputThrowParticipant");
		UnitApplication createAssociationDataInputThrowParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputThrowParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputThrowParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (Throw event)-----------------*/
		Unit createAssociationDataInputThrowLaneUnit = module_Assoc.getUnit("CreateAssociationDataInputThrowLane");
		UnitApplication createAssociationDataInputThrowLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputThrowLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputThrowLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		


		// *********************Associations Group 3: (C)Transform Data Input/Output Reference to associations************************************************/
		// **************************************************************************************************************************/


		/*---------------Transform Data Input Association into association between class Participant and DataObject-----------------*/
		Unit createAssociationDataInputRefParticipantUnit = module_Assoc.getUnit("CreateAssociationDataInputRefParticipant");
		UnitApplication createAssociationDataInputRefParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputRefParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputRefParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*---------------Transform Data Output Association into association between class Participant and DataObject-----------------*/
		Unit createAssociationDataOutRefParticipantUnit = module_Assoc.getUnit("CreateAssociationDataOutRefParticipant");
		UnitApplication createAssociationDataOutRefParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutRefParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutRefParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		 /*---------------Transform Data Input Association into association between class Lane and DataObject-----------------*/
		 Unit createAssociationDataInputRefLaneUnit =
		 module_Assoc.getUnit("CreateAssociationDataInputRefLane");
		 UnitApplication createAssociationDataInputRefLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createAssociationDataInputRefLaneUnit, null);
		 InterpreterUtil.executeOrDie(createAssociationDataInputRefLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------*/
		
		 /*---------------Transform Data Output Association into association between class Lane and DataObject-----------------*/
		 Unit createAssociationDataOutRefLaneUnit =
		 module_Assoc.getUnit("CreateAssociationDataOutRefLane");
		 UnitApplication createAssociationDataOutRefLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 createAssociationDataOutRefLaneUnit, null);
		 InterpreterUtil.executeOrDie(createAssociationDataOutRefLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------*/
		

		/*---------------Transform Data Output Association into association between class Participant and DataObject (start event)-----------------*/
		Unit createAssociationDataOutRefStartParticipantUnit = module_Assoc.getUnit("CreateAssociationDataOutRefStartParticipant");
		UnitApplication createAssociationDataOutRefStartParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutRefStartParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutRefStartParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (start event)-----------------*/
		Unit createAssociationDataOutRefStartLaneUnit = module_Assoc.getUnit("CreateAssociationDataOutRefStartLane");
		UnitApplication createAssociationDataOutRefStartLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutRefStartLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutRefStartLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*---------------Transform Data Output Association into association between class Participant and DataObject (catch event)-----------------*/
		Unit createAssociationDataOutRefCatchParticipantUnit = module_Assoc
				.getUnit("CreateAssociationDataOutRefCatchParticipant");
		UnitApplication createAssociationDataOutRefCatchParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutRefCatchParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutRefCatchParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Output Association into association between class Lane and DataObject (catch event)-----------------*/
		Unit createAssociationDataOutRefCatchLaneUnit = module_Assoc
				.getUnit("CreateAssociationDataOutRefCatchLane");
		UnitApplication createAssociationDataOutRefCatchLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataOutRefCatchLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataOutRefCatchLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Input Association into association between class Participant and DataObject (End event)-----------------*/
		Unit createAssociationDataInputRefEndParticipantUnit = module_Assoc
				.getUnit("CreateAssociationDataInputRefEndParticipant");
		UnitApplication createAssociationDataInputRefEndParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputRefEndParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputRefEndParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Input Association into association between class Lane and DataObject (End event)-----------------*/
		Unit createAssociationDataInputRefEndLaneUnit = module_Assoc
				.getUnit("CreateAssociationDataInputRefEndLane");
		UnitApplication createAssociationDataInputRefEndLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputRefEndLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputRefEndLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/

		/*---------------Transform Data Input Association into association between class Participant and DataObject (Throw event)-----------------*/
		Unit createAssociationDataInputRefThrowParticipantUnit = module_Assoc
				.getUnit("CreateAssociationDataInputRefThrowParticipant");
		UnitApplication createAssociationDataInputRefThrowParticipantApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputRefThrowParticipantUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputRefThrowParticipantApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		/*---------------Transform Data Input Association into association between class Lane and DataObject (Throw event)-----------------*/
		Unit createAssociationDataInputRefThrowLaneUnit = module_Assoc
				.getUnit("CreateAssociationDataInputRefThrowLane");
		UnitApplication createAssociationDataInputRefThrowLaneApp = new UnitApplicationImpl(engine, graph,
				createAssociationDataInputRefThrowLaneUnit, null);
		InterpreterUtil.executeOrDie(createAssociationDataInputRefThrowLaneApp);
		/*--------------------------------------------------------------------------------------------------------------------------*/
		
		// **********************SECURITY DEPENDENCY GROUP 4: (A) SECURITY ASSOCIATION CONNECTED TO DATA OBJECT TO DEPENDENCY********************/
		// **************************************************************************************************************************************/

		/*--------------------------------------------Transform security association to dependency Participant (confidentialityDo/integrityDo)----------------*/
		Unit transformSecurityAssociationParticipantUnit = module_Dependency.getUnit("TransformSecurityAssociationParticipant");
		UnitApplication transformSecurityAssociationParticipantApp = new UnitApplicationImpl(engine, graph,
				transformSecurityAssociationParticipantUnit, null);
		InterpreterUtil.executeOrDie(transformSecurityAssociationParticipantApp);
		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/
		 /*--------------------------------------------Transform data Input to dependency Lane (confidentialityDo/integrityDo) (Case Task)-------------------------------*/
		 Unit transformSecurityAssociationInputLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationTaskInputLane");
		 UnitApplication transformSecurityAssociationInputLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationInputLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationInputLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------------------------------*/
		 /*--------------------------------------------Transform data Input to dependency Lane (confidentialityDo/integrityDo) (Case End Event)-------------------------------*/
		 Unit transformSecurityAssociationInputEndLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationEndInputLane");
		 UnitApplication transformSecurityAssociationInputEndLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationInputEndLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationInputEndLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------------------------------*/
		 /*--------------------------------------------Transform data Input to dependency Lane (confidentialityDo/integrityDo) (Case Throw Event)-------------------------------*/
		 Unit transformSecurityAssociationInputThrowLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationThrowInputLane");
		 UnitApplication transformSecurityAssociationInputThrowLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationInputThrowLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationInputThrowLaneApp);
		 /*--------------------------------------------------------------------------------------------------------------------------------------------------*/
		 
		 /*--------------------------------------------Transform data Output to dependency Lane (confidentialityDo/integrityDo)(Case Task)------------------------------*/
		 Unit transformSecurityAssociationTaskOutLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationTaskOutLane");
		 UnitApplication transformSecurityAssociationTaskOutLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationTaskOutLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationTaskOutLaneApp);
		 /*---------------------------------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------------Transform data Output to dependency Lane (confidentialityDo/integrityDo) (Case Start Event)------------------------------*/
		 Unit transformSecurityAssociationStartOutLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationStartOutLane");
		 UnitApplication transformSecurityAssociationStartOutLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationStartOutLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationStartOutLaneApp);
		 /*---------------------------------------------------------------------------------------------------------------------------------------------------*/
		 
		 /*--------------------------------------------Transform data Output to dependency Lane (confidentialityDo/integrityDo) (Case Catch Event)------------------------------*/
		 Unit transformSecurityAssociationCatchOutLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationCatchOutLane");
		 UnitApplication transformSecurityAssociationCatchOutLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationCatchOutLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationCatchOutLaneApp);
		 /*---------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		 
		// **********************SECURITY DEPENDENCY GROUP 4: (B) SECURITY ASSOCIATION CONNECTED TO Reference DATA OBJECT TO DEPENDENCY********************/
		// ************************************************************************************************************************************************/

		/*-------------------------------------Transform security association in case of Input Reference to dependency Participant (confidentialityDo/integrityDo)----------------------------*/
		Unit transformSecurityAssociationInputRefUnit = module_Dependency.getUnit("TransformSecurityAssociationInputRef");
		UnitApplication transformSecurityAssociationInputRefApp = new UnitApplicationImpl(engine, graph,
				transformSecurityAssociationInputRefUnit, null);
		InterpreterUtil.executeOrDie(transformSecurityAssociationInputRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------Transform security association in case of Output Reference to dependency Participant (confidentialityDo/integrityDo)----------------------------*/
		Unit transformSecurityAssociationOutRefUnit = module_Dependency.getUnit("TransformSecurityAssociationOutRef");
		UnitApplication transformSecurityAssociationOutRefApp = new UnitApplicationImpl(engine, graph,
				transformSecurityAssociationOutRefUnit, null);
		InterpreterUtil.executeOrDie(transformSecurityAssociationOutRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		 /*--------------------------------------------Transform data Input Reference to dependency Lane (confidentialityDo/integrityDo)-------------------------------------------------------*/
		 Unit transformSecurityAssociationInputRefLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationInputRefLane");
		 UnitApplication transformSecurityAssociationInputRefLaneApp = new
		 UnitApplicationImpl(engine, graph,
		 transformSecurityAssociationInputRefLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationInputRefLaneApp);
		
		 /*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		 /*--------------------------------------------Transform data Output Reference to dependency Lane (confidentialityDo/integrityDo)------------------------------------------------------*/
		 Unit transformSecurityAssociationOutRefLaneUnit =module_Dependency.getUnit("TransformSecurityAssociationOutRefLane");
		 UnitApplication transformSecurityAssociationOutRefLaneApp = new
		 UnitApplicationImpl(engine, graph,transformSecurityAssociationOutRefLaneUnit, null);
		 InterpreterUtil.executeOrDie(transformSecurityAssociationOutRefLaneApp);
		 /*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		/*-------------------------------------Transform security association in case of Output Reference to dependency Participant in case of start event(confidentialityDo/integrityDo)----------------------------*/
		Unit startTransformSecurityAssociationOutRefUnit = module_Dependency.getUnit("StartTransformSecurityAssociationOutRef");
		UnitApplication startTransformSecurityAssociationOutRefApp = new UnitApplicationImpl(engine, graph,
				startTransformSecurityAssociationOutRefUnit, null);
		InterpreterUtil.executeOrDie(startTransformSecurityAssociationOutRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		/*-------------------------------------Transform security association in case of Output Reference to dependency Lane in case of start event(confidentialityDo/integrityDo)----------------------------*/
		Unit startTransformSecurityAssociationOutRefLaneUnit = module_Dependency.getUnit("StartTransformSecurityAssociationOutRefLane");
		UnitApplication startTransformSecurityAssociationOutRefLaneApp = new UnitApplicationImpl(engine, graph,
				startTransformSecurityAssociationOutRefLaneUnit, null);
		InterpreterUtil.executeOrDie(startTransformSecurityAssociationOutRefLaneApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
				
		/*-------------------------------------Transform security association in case of Output Reference to dependency Participant in case of catch event(confidentialityDo/integrityDo)----------------------------*/
		Unit catchTransformSecurityAssociationOutRefUnit = module_Dependency.getUnit("CatchTransformSecurityAssociationOutRef");
		UnitApplication catchTransformSecurityAssociationOutRefApp = new UnitApplicationImpl(engine, graph,
				catchTransformSecurityAssociationOutRefUnit, null);
		InterpreterUtil.executeOrDie(catchTransformSecurityAssociationOutRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------Transform security association in case of Output Reference to dependency Lane in case of catch event(confidentialityDo/integrityDo)----------------------------*/
		Unit catchTransformSecurityAssociationOutRefLaneUnit = module_Dependency.getUnit("CatchTransformSecurityAssociationOutRefLane");
		UnitApplication catchTransformSecurityAssociationOutRefLaneApp = new UnitApplicationImpl(engine, graph,
				catchTransformSecurityAssociationOutRefLaneUnit, null);
		InterpreterUtil.executeOrDie(catchTransformSecurityAssociationOutRefLaneApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------Transform security association in case of Output Reference to dependency Participant in case of End event(confidentialityDo/integrityDo)----------------------------*/
		Unit endTransformSecurityAssociationOutRefUnit = module_Dependency.getUnit("EndTransformSecurityAssociationOutRef");
		UnitApplication endTransformSecurityAssociationOutRefApp = new UnitApplicationImpl(engine, graph,
				endTransformSecurityAssociationOutRefUnit, null);
		InterpreterUtil.executeOrDie(endTransformSecurityAssociationOutRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------Transform security association in case of Output Reference to dependency Lane in case of End event(confidentialityDo/integrityDo)----------------------------*/
		Unit endTransformSecurityAssociationOutRefLaneUnit = module_Dependency.getUnit("EndTransformSecurityAssociationOutRefLane");
		UnitApplication endTransformSecurityAssociationOutRefLaneApp = new UnitApplicationImpl(engine, graph,
				endTransformSecurityAssociationOutRefLaneUnit, null);
		InterpreterUtil.executeOrDie(endTransformSecurityAssociationOutRefLaneApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		/*-------------------------------------Transform security association in case of Output Reference to dependency Participant in case of End event(confidentialityDo/integrityDo)----------------------------*/
		Unit thorwTransformSecurityAssociationOutRefUnit = module_Dependency.getUnit("ThrowTransformSecurityAssociationOutRef");
		UnitApplication thorwTransformSecurityAssociationOutRefApp = new UnitApplicationImpl(engine, graph,
				thorwTransformSecurityAssociationOutRefUnit, null);
		InterpreterUtil.executeOrDie(thorwTransformSecurityAssociationOutRefApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------Transform security association in case of Output Reference to dependency Lane in case of End event(confidentialityDo/integrityDo)----------------------------*/
		Unit thorwTransformSecurityAssociationOutRefLaneUnit = module_Dependency.getUnit("ThrowTransformSecurityAssociationOutRefLane");
		UnitApplication thorwTransformSecurityAssociationOutRefLaneApp = new UnitApplicationImpl(engine, graph,
				thorwTransformSecurityAssociationOutRefLaneUnit, null);
		InterpreterUtil.executeOrDie(thorwTransformSecurityAssociationOutRefLaneApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		// **********************SECURITY DEPENDENCY GROUP: (C) TRANSFORM MESSAGE FLOW TO DEPENDENCY********************/
	    // *************************************************************************************************************************/
		
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit SecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("SecuritytMessageFlowParticipant");
		UnitApplication SecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				SecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(SecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit taskStartSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("TaskStartSecuritytMessageFlowParticipant");
		UnitApplication taskStartSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				taskStartSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(taskStartSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit taskCatchSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("TaskCatchSecuritytMessageFlowParticipant");
		UnitApplication taskCatchSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				taskCatchSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(taskCatchSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit endStartSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("EndStartSecuritytMessageFlowParticipant");
		UnitApplication endStartSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				endStartSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(endStartSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit endCatchSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("EndCatchSecuritytMessageFlowParticipant");
		UnitApplication endCatchSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				endCatchSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(endCatchSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit endTaskSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("EndTaskSecuritytMessageFlowParticipant");
		UnitApplication endTaskSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				endTaskSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(endTaskSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit throwStartSecuritytMessageFlowParticipantUnit = module_Dependency
				.getUnit("ThrowStartSecuritytMessageFlowParticipant");
		UnitApplication throwStartSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				throwStartSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(throwStartSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit throwCatchSecuritytMessageFlowParticipantUnit = module_Dependency
				.getUnit("ThrowCatchSecuritytMessageFlowParticipant");
		UnitApplication throwCatchSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				throwCatchSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(throwCatchSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Transform Message Flow  to dependency  (confidentialityDo/integrityDo)------------------------------------------------------*/
		Unit throwTaskSecuritytMessageFlowParticipantUnit = module_Dependency.getUnit("ThrowTaskSecuritytMessageFlowParticipant");
		UnitApplication throwTaskSecuritytMessageFlowParticipantApp = new UnitApplicationImpl(engine, graph,
				throwTaskSecuritytMessageFlowParticipantUnit, null);
		InterpreterUtil.executeOrDie(throwTaskSecuritytMessageFlowParticipantApp);
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		

		
	 // **********************************ABAC GROUP: (A) SECURITY REQUIREMENTS Security Act TO RABAC******************************************/
    // ***************************************************************************************************************************************/

			/*--------------------------------------------AccountabilityAct To Role Based Access Control-----------------------------*/

					Rule transformAccountabilityActUnit = (Rule) module_ABAC.getUnit("TransformAccountabilityAct");
					RuleApplication transformAccountabilityActApp = new RuleApplicationImpl(engine, graph,
							transformAccountabilityActUnit, null);
					transformAccountabilityActApp.execute(null);

					// X: find created abacRequire object: go from match to multi-rule match
					EObject requireConf;
					Rule classRuleConf = transformAccountabilityActUnit.getMultiRules().get(0);
					Rule operationsRuleConf = classRuleConf.getMultiRules().get(0);
					if (!transformAccountabilityActApp.getResultMatch().getMultiMatches(classRuleConf).isEmpty()) {
						for (Match multiMatch : transformAccountabilityActApp.getResultMatch().getMultiMatches(classRuleConf).get(0)
								.getMultiMatches(operationsRuleConf)) {
							requireConf = (EObject) multiMatch.getParameterValues().get(0);
							addToResource(requireConf);

						}
					}

		   /*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		   /*--------------------------------------------IntegrityAct To Role Based Access Control--------------------------------------------------------------------------------------*/

					Rule transformIntegrityActUnit = (Rule) module_ABAC.getUnit("TransformIntegrityAct");
					RuleApplication transformIntegrityyActApp = new RuleApplicationImpl(engine, graph, transformIntegrityActUnit,
							null);
					transformIntegrityyActApp.execute(null);

					// X: find created abacRequire object: go from match to multi-rule match
					EObject requireIntegrity;
					Rule classRuleIntegrity = transformIntegrityActUnit.getMultiRules().get(0);
					Rule operationsRuleIntegrity = classRuleIntegrity.getMultiRules().get(0);

					if (!transformIntegrityyActApp.getResultMatch().getMultiMatches(classRuleIntegrity).isEmpty()) {
						for (Match multiMatch : transformIntegrityyActApp.getResultMatch().getMultiMatches(classRuleIntegrity)
								.get(0).getMultiMatches(operationsRuleIntegrity)) {
							requireIntegrity = (EObject) multiMatch.getParameterValues().get(0);
							addToResource(requireIntegrity);

						}
					}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

					
		// **********************************ABAC GROUP: (B) SECURITY REQUIREMENTS Security Data object TO RABAC******************************************/
		// **************************************************************************************************************************/
					
					
		/*--------------------------------------------ConfidentialityDO Input To Role Based Access Control--------------------------------------------------------------------------------------*/

				Rule transformConfidentialityDoToAbacUnit = (Rule) module_ABAC.getUnit("TransformConfidentialityDoToAbacInput");
				RuleApplication transformConfidentialityDoToAbacApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityDoToAbacUnit, null);
				transformConfidentialityDoToAbacApp.execute(null);

				EObject requireConfDoAbac;
				Rule classRuleConfDoAbac = transformConfidentialityDoToAbacUnit.getMultiRules().get(0);
				Rule operationsRuleConfDoAbac = classRuleConfDoAbac.getMultiRules().get(0);

				if (!transformConfidentialityDoToAbacApp.getResultMatch().getMultiMatches(classRuleConfDoAbac).isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityDoToAbacApp.getResultMatch()
							.getMultiMatches(classRuleConfDoAbac)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleConfDoAbac)) {
							requireConfDoAbac = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfDoAbac);
						}
					}

				}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		/*--------------------------------------------IntegrityDO Input To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityDoToAbacInputUnit = (Rule) module_ABAC.getUnit("TransformIntegrityDoToAbacInput");
				RuleApplication transformIntegrityDoToAbacInputApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityDoToAbacInputUnit, null);
				transformIntegrityDoToAbacInputApp.execute(null);

				EObject requireIntDoAbacInput;
				Rule classRuleIntDoAbacInput = transformIntegrityDoToAbacInputUnit.getMultiRules().get(0);
				Rule operationsRuleIntDoAbacInput = classRuleIntDoAbacInput.getMultiRules().get(0);

				if (!transformIntegrityDoToAbacInputApp.getResultMatch().getMultiMatches(classRuleIntDoAbacInput).isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityDoToAbacInputApp.getResultMatch()
							.getMultiMatches(classRuleIntDoAbacInput)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleIntDoAbacInput)) {
							requireIntDoAbacInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntDoAbacInput);
						}
					}

				}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------ConfidentialityDO Output To Role Based Access Control--------------------------------------------------------------------------------------*/

				Rule transformConfidentialityDoToAbacOutUnit = (Rule) module_ABAC.getUnit("TransformConfidentialityDoToAbacOut");
				RuleApplication transformConfidentialityDoToAbacOutApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityDoToAbacOutUnit, null);
				transformConfidentialityDoToAbacOutApp.execute(null);

				EObject requireConfDoAbacOut;
				Rule classRuleConfDoAbacOut = transformConfidentialityDoToAbacOutUnit.getMultiRules().get(0);
				Rule operationsRuleConfDoAbacOut = classRuleConfDoAbacOut.getMultiRules().get(0);

				if (!transformConfidentialityDoToAbacOutApp.getResultMatch().getMultiMatches(classRuleConfDoAbacOut)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityDoToAbacOutApp.getResultMatch()
							.getMultiMatches(classRuleConfDoAbacOut)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleConfDoAbacOut)) {
							requireConfDoAbacOut = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfDoAbacOut);
						}
					}

				}

				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
			

				/*--------------------------------------------IntegrityDO Out To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityDoToAbacOutUnit = (Rule) module_ABAC.getUnit("TransformIntegrityDoToAbacOut");
				RuleApplication transformIntegrityDoToAbacOutApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityDoToAbacOutUnit, null);
				transformIntegrityDoToAbacOutApp.execute(null);

				EObject requireIntDoAbacOut;
				Rule classRuleIntDoAbacOut = transformIntegrityDoToAbacOutUnit.getMultiRules().get(0);
				Rule operationsRuleIntDoAbacOut = classRuleIntDoAbacOut.getMultiRules().get(0);

				if (!transformIntegrityDoToAbacOutApp.getResultMatch().getMultiMatches(classRuleIntDoAbacOut).isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityDoToAbacOutApp.getResultMatch()
							.getMultiMatches(classRuleIntDoAbacOut)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleIntDoAbacOut)) {
							requireIntDoAbacOut = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntDoAbacOut);
						}
					}

				}

				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
				
	// **********************************ABAC GROUP: (B) SECURITY REQUIREMENTS Security Data object TO RABAC******************************************/
	// **************************************************************************************************************************/
				
				/*--------------------------------------------ConfidentialityDO Input Reference To Role Based Access Control--------------------------------------------------------------------------------------*/

				Rule transformConfidentialityDoToAbacInputRefUnit = (Rule) module_ABAC
						.getUnit("TransformConfidentialityDoToAbacInputRef");
				RuleApplication transformConfidentialityDoToAbacInputRefApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityDoToAbacInputRefUnit, null);
				transformConfidentialityDoToAbacInputRefApp.execute(null);

				EObject requireConfDoAbacInputRef;
				Rule classRuleConfDoAbacInputRef = transformConfidentialityDoToAbacInputRefUnit.getMultiRules().get(0);
				Rule operationsRuleConfDoAbacInputRef = classRuleConfDoAbacInputRef.getMultiRules().get(0);

				if (!transformConfidentialityDoToAbacInputRefApp.getResultMatch().getMultiMatches(classRuleConfDoAbacInputRef)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityDoToAbacInputRefApp.getResultMatch()
							.getMultiMatches(classRuleConfDoAbacInputRef)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch
								.getMultiMatches(operationsRuleConfDoAbacInputRef)) {
							requireConfDoAbacInputRef = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfDoAbacInputRef);
						}
					}

				}

				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


				/*--------------------------------------------ConfidentialityDO Out Reference To Role Based Access Control--------------------------------------------------------------------------------------*/

				Rule transformConfidentialityDoToAbacOutRefUnit = (Rule) module_ABAC
						.getUnit("TransformConfidentialityDoToAbacOutRef");
				RuleApplication transformConfidentialityDoToAbacOutRefApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityDoToAbacOutRefUnit, null);
				transformConfidentialityDoToAbacOutRefApp.execute(null);

				EObject requireConfDoAbacOutRef;
				Rule classRuleConfDoAbacOutRef = transformConfidentialityDoToAbacOutRefUnit.getMultiRules().get(0);
				Rule operationsRuleConfDoAbacOutRef = classRuleConfDoAbacOutRef.getMultiRules().get(0);

				if (!transformConfidentialityDoToAbacOutRefApp.getResultMatch().getMultiMatches(classRuleConfDoAbacOutRef)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityDoToAbacOutRefApp.getResultMatch()
							.getMultiMatches(classRuleConfDoAbacOutRef)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleConfDoAbacOutRef)) {
							requireConfDoAbacOutRef = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfDoAbacOutRef);
						}
					}

				}

				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


				/*--------------------------------------------IntegrityDO Input Reference To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityDoToAbacInputRefUnit = (Rule) module_ABAC.getUnit("TransformIntegrityDoToAbacInputRef");
				RuleApplication transformIntegrityDoToAbacInputRefApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityDoToAbacInputRefUnit, null);
				transformIntegrityDoToAbacInputRefApp.execute(null);

				EObject requireIntDoAbacInputRef;
				Rule classRuleIntDoAbacInputRef = transformIntegrityDoToAbacInputRefUnit.getMultiRules().get(0);
				Rule operationsRuleIntDoAbacInputRef = classRuleIntDoAbacInputRef.getMultiRules().get(0);

				if (!transformIntegrityDoToAbacInputRefApp.getResultMatch().getMultiMatches(classRuleIntDoAbacInputRef)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityDoToAbacInputRefApp.getResultMatch()
							.getMultiMatches(classRuleIntDoAbacInputRef)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch
								.getMultiMatches(operationsRuleIntDoAbacInputRef)) {
							requireIntDoAbacInputRef = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntDoAbacInputRef);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


				/*--------------------------------------------IntegrityDO Out ReferenceTo Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityDoToAbacOutRefUnit = (Rule) module_ABAC.getUnit("TransformIntegrityDoToAbacOutRef");
				RuleApplication transformIntegrityDoToAbacOutRefApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityDoToAbacOutRefUnit, null);
				transformIntegrityDoToAbacOutRefApp.execute(null);

				EObject requireIntDoAbacOutRef;
				Rule classRuleIntDoAbacOutRef = transformIntegrityDoToAbacOutRefUnit.getMultiRules().get(0);
				Rule operationsRuleIntDoAbacOutRef = classRuleIntDoAbacOutRef.getMultiRules().get(0);

				if (!transformIntegrityDoToAbacOutRefApp.getResultMatch().getMultiMatches(classRuleIntDoAbacOutRef).isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityDoToAbacOutRefApp.getResultMatch()
							.getMultiMatches(classRuleIntDoAbacOutRef)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleIntDoAbacOutRef)) {
							requireIntDoAbacOutRef = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntDoAbacOutRef);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

				
	// **********************************ABAC GROUP: (D) SECURITY REQUIREMENTS Security Message Flow TO RABAC******************************************/
	// ************************************************************************************************************************************************/		
				
				/*--------------------------------------------ConfedentialityMF Source To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformConfidentialityMFToAbacSourceUnit = (Rule) module_ABAC
						.getUnit("TransformConfidentialityMFToAbacSource");
				RuleApplication transformConfidentialityMFToAbacSourceApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityMFToAbacSourceUnit, null);
				transformConfidentialityMFToAbacSourceApp.execute(null);

				EObject requireConfMFSource;
				Rule classRuleConfMFSource = transformConfidentialityMFToAbacSourceUnit.getMultiRules().get(0);
				Rule operationsConfMFSource = classRuleConfMFSource.getMultiRules().get(0);

				if (!transformConfidentialityMFToAbacSourceApp.getResultMatch().getMultiMatches(classRuleConfMFSource)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityMFToAbacSourceApp.getResultMatch()
							.getMultiMatches(classRuleConfMFSource)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsConfMFSource)) {
							requireConfMFSource = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfMFSource);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

				/*--------------------------------------------ConfedentialityMF Target To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformConfidentialityMFToAbacTargetUnit = (Rule) module_ABAC
						.getUnit("TransformConfidentialityMFToAbacTarget");
				RuleApplication transformConfidentialityMFToAbacTargetApp = new RuleApplicationImpl(engine, graph,
						transformConfidentialityMFToAbacTargetUnit, null);
				transformConfidentialityMFToAbacTargetApp.execute(null);

				EObject requireConfMFTarget;
				Rule classRuleConfMFTarget = transformConfidentialityMFToAbacTargetUnit.getMultiRules().get(0);
				Rule operationsRuleConfMFTarget = classRuleConfMFTarget.getMultiRules().get(0);

				if (!transformConfidentialityMFToAbacTargetApp.getResultMatch().getMultiMatches(classRuleConfMFTarget)
						.isEmpty()) {
					for (Match firstRuleMultiMatch : transformConfidentialityMFToAbacTargetApp.getResultMatch()
							.getMultiMatches(classRuleConfMFTarget)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleConfMFTarget)) {
							requireConfMFTarget = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireConfMFTarget);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

				/*--------------------------------------------IntegrityMF Source To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityMFToAbacSourceUnit = (Rule) module_ABAC.getUnit("TransformIntegrityMFToAbacSource");
				RuleApplication transformIntegrityMFToAbacSourceApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityMFToAbacSourceUnit, null);
				transformIntegrityMFToAbacSourceApp.execute(null);

				EObject requireIntMFSource;
				Rule classRuleIntMFSource = transformIntegrityMFToAbacSourceUnit.getMultiRules().get(0);
				Rule operationsIntMFSource = classRuleIntMFSource.getMultiRules().get(0);

				if (!transformIntegrityMFToAbacSourceApp.getResultMatch().getMultiMatches(classRuleIntMFSource).isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityMFToAbacSourceApp.getResultMatch()
							.getMultiMatches(classRuleIntMFSource)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsIntMFSource)) {
							requireIntMFSource = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntMFSource);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

				/*--------------------------------------------IntegrityMF Target To Role Based Access Control------------------------------------------------------------------------------------------*/

				Rule transformIntegrityMFToAbacTargetUnit = (Rule) module_ABAC.getUnit("TransformIntegrityMFToAbacTarget");
				RuleApplication transformIntegrityMFToAbacTargetApp = new RuleApplicationImpl(engine, graph,
						transformIntegrityMFToAbacTargetUnit, null);
				transformIntegrityMFToAbacTargetApp.execute(null);

				EObject requireIntMFTarget;
				Rule classRuleIntMFTarget = transformIntegrityMFToAbacTargetUnit.getMultiRules().get(0);
				Rule operationsRuleIntMFTarget = classRuleIntMFTarget.getMultiRules().get(0);

				if (!transformIntegrityMFToAbacTargetApp.getResultMatch().getMultiMatches(classRuleIntMFTarget).isEmpty()) {
					for (Match firstRuleMultiMatch : transformIntegrityMFToAbacTargetApp.getResultMatch()
							.getMultiMatches(classRuleIntMFTarget)) {
						for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleIntMFTarget)) {
							requireIntMFTarget = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
							addToResource(requireIntMFTarget);
						}
					}

				}
				/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

				


	
				
		// **********************SECURE DEPENDENCY GROUP: (A) ADD SECRECY OR INTEGRITY TO DEPENDENCY*********************************************/
	    // *************************************************************************************************************************/
		
		/*--------------------------------------------Add <<Secrecy>> to  Dependency (confidentiality)--------------------------------------------------------------------------------------*/

		Rule transformConfidentialityDOSecrecyUnit = (Rule) module_SecureDependency
				.getUnit("TransformConfidentialityDOSecureDependency");
		RuleApplication transformConfidentialityDOSecrecyApp = new RuleApplicationImpl(engine, graph,
				transformConfidentialityDOSecrecyUnit, null);
		transformConfidentialityDOSecrecyApp.execute(null);

		EObject requireConfDoSecrecy;
		Rule classRuleConfDoSecrecy = transformConfidentialityDOSecrecyUnit.getMultiRules().get(0);
		Rule operationsRuleConfDoSecrecy = classRuleConfDoSecrecy.getMultiRules().get(0);

		if (!transformConfidentialityDOSecrecyApp.getResultMatch().getMultiMatches(classRuleConfDoSecrecy).isEmpty()) {
			for (Match firstRuleMultiMatch : transformConfidentialityDOSecrecyApp.getResultMatch()
					.getMultiMatches(classRuleConfDoSecrecy)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleConfDoSecrecy)) {
					requireConfDoSecrecy = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(requireConfDoSecrecy);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<integrity>> to Dependency (integrity)--------------------------------------------------------------------------------------*/


		 Rule transformIntegrityDOIntegrityUnit = (Rule)
		 module_SecureDependency.getUnit("TransformIntegrityDOIntegritySecureDependency");
		
		 RuleApplication transformIntegrityDOIntegrityApp = new RuleApplicationImpl(engine, graph,
		 transformIntegrityDOIntegrityUnit, null);
		 transformIntegrityDOIntegrityApp.execute(null);
		
		 EObject requireIntDo;
		 Rule classRuleIntDo =transformIntegrityDOIntegrityUnit.getMultiRules().get(0);
		 Rule operationsRuleIntDo = classRuleIntDo.getMultiRules().get(0);
		
		 if
		 (!transformIntegrityDOIntegrityApp.getResultMatch().getMultiMatches(classRuleIntDo).isEmpty())
		 {
		 for (Match firstRuleMultiMatch:transformIntegrityDOIntegrityApp.getResultMatch().getMultiMatches(classRuleIntDo))
		 {
			 for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleIntDo)) {
				 	requireIntDo = (EObject)
				 	secondRuleMultiMatch.getParameterValues().get(0);
				 	addToResource(requireIntDo);
				 	}
		 }
		
		 }
		
		
		 /*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		// **********************SECURE DEPENDENCY GROUP: (B) ADD CALL OR SEND TO DEPENDENCY***************************************/
	    // *************************************************************************************************************************/
		
		/*-------------------------------------------- ConfidentialityDO/IntegrityDo add <<call>> to Dependency Participant/Lane--------------------------------------------------------------------------------------*/

		Rule addCallDependencyUnit = (Rule) module_SecureDependency.getUnit("AddCallDependencyObject");
		RuleApplication addCallDependencyApp = new RuleApplicationImpl(engine, graph, addCallDependencyUnit, null);
		addCallDependencyApp.execute(null);

		EObject callDep;
		Rule classRuleCallDep = addCallDependencyUnit.getMultiRules().get(0);
		Rule operationsRuleCallDep = classRuleCallDep.getMultiRules().get(0);

		if (!addCallDependencyApp.getResultMatch().getMultiMatches(classRuleCallDep).isEmpty()) {
			for (Match firstRuleMultiMatch : addCallDependencyApp.getResultMatch().getMultiMatches(classRuleCallDep)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleCallDep)) {
					callDep = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(callDep);

				}
			}

		}

		/*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------------- ConfidentialityDO/IntegrityDo add <<call>> to Dependency Participant/Lane--------------------------------------------------------------------------------------*/

		Rule addCallDependencyRefUnit = (Rule) module_SecureDependency.getUnit("AddCallDependencyObjectRef");
		RuleApplication addCallDependencyRefApp = new RuleApplicationImpl(engine, graph, addCallDependencyRefUnit,
				null);
		addCallDependencyRefApp.execute(null);

		EObject callDepRef;
		Rule classRuleCallDepRef = addCallDependencyRefUnit.getMultiRules().get(0);
		Rule operationsRuleCallDepRef = classRuleCallDepRef.getMultiRules().get(0);

		if (!addCallDependencyRefApp.getResultMatch().getMultiMatches(classRuleCallDepRef).isEmpty()) {
			for (Match firstRuleMultiMatch : addCallDependencyRefApp.getResultMatch()
					.getMultiMatches(classRuleCallDepRef)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleCallDepRef)) {
					callDepRef = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(callDepRef);

				}
			}

		}

		/*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------------------------- ConfidentialityDO/IntegrityDo add <<send>> to Dependency Participant/Lane--------------------------------------------------------------------------------------*/

		Rule addSendDependencyMFUnit = (Rule) module_SecureDependency.getUnit("AddSendDependencyMF");
		RuleApplication addSendDependencyMFApp = new RuleApplicationImpl(engine, graph, addSendDependencyMFUnit, null);
		addSendDependencyMFApp.execute(null);

		EObject callDepMF;
		Rule classRuleCallDepMF = addSendDependencyMFUnit.getMultiRules().get(0);
		Rule operationsRuleCallDepMF = classRuleCallDepMF.getMultiRules().get(0);

		if (!addSendDependencyMFApp.getResultMatch().getMultiMatches(classRuleCallDepMF).isEmpty()) {
			for (Match firstRuleMultiMatch : addSendDependencyMFApp.getResultMatch()
					.getMultiMatches(classRuleCallDepMF)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsRuleCallDepMF)) {
					callDepMF = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(callDepMF);

				}
			}

		}

		/*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		
		
		//*************************************SECURE DEPENDENCY GROUP: (C) ADD CRITICAL TO Supplier CASE DATA OBJECT****************/
		// *************************************************************************************************************************/

		/*-----------------------Add <<critical>> to  data object  Class Case (Integrity-DataInput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjIntegrityInputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityInputSupplier");
		RuleApplication addCriticalToDataObjIntegrityInputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityInputSupplierUnit, null);
		addCriticalToDataObjIntegrityInputSupplierApp.execute(null);

		EObject criticalSupplierIntegrityInput;
		Rule criticalRuleSupplierIntegrityInput = addCriticalToDataObjIntegrityInputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalIntegrityInput = criticalRuleSupplierIntegrityInput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleSupplierIntegrityInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleSupplierIntegrityInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalIntegrityInput)) {
					criticalSupplierIntegrityInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrityInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  data object  Class Case (Integrity-DataOutput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjIntegrityOutputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityOutputSupplier");
		RuleApplication addCriticalToDataObjIntegrityOutputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityOutputSupplierUnit, null);
		addCriticalToDataObjIntegrityOutputSupplierApp.execute(null);

		EObject criticalSupplierIntegrityOutput;
		Rule criticalRuleSupplierIntegrityOutput = addCriticalToDataObjIntegrityOutputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalIntegrityOutput = criticalRuleSupplierIntegrityOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleSupplierIntegrityOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleSupplierIntegrityOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalIntegrityOutput)) {
					criticalSupplierIntegrityOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrityOutput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  data object  Class Case (Confidentiality-DataInput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjConfidentialityInputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityInputSupplier");
		RuleApplication addCriticalToDataObjConfidentialityInputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityInputSupplierUnit, null);
		addCriticalToDataObjConfidentialityInputSupplierApp.execute(null);

		EObject criticalSupplierConfidentialityInput;
		Rule criticalRuleConfidentialityInput = addCriticalToDataObjConfidentialityInputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalConfidentialityInput = criticalRuleConfidentialityInput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalConfidentialityInput)) {
					criticalSupplierConfidentialityInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierConfidentialityInput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  data object  Class Case (Confidentiality-DataOutput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjConfidentialityOutputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityOutputSupplier");
		RuleApplication addCriticalToDataObjConfidentialityOutputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityOutputSupplierUnit, null);
		addCriticalToDataObjConfidentialityOutputSupplierApp.execute(null);

		EObject criticalSupplierConfidentialityOutput;
		Rule criticalRuleConfidentialityOutput = addCriticalToDataObjConfidentialityOutputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalConfidentialityOutput = criticalRuleConfidentialityOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalConfidentialityOutput)) {
					criticalSupplierConfidentialityOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierConfidentialityOutput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		//*************************************SECURE DEPENDENCY GROUP: (D) ADD CRITICAL TO Supplier CASE Reference DATA OBJECT****************/
		// ***********************************************************************************************************************************/
				
		/*--------------------------------------------Add <<critical>> to  data object  Class case Integrity Input Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjIntegrityRefInputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityRefInputSupplier");
		RuleApplication addCriticalToDataObjIntegrityRefInputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityRefInputSupplierUnit,
				null);
		addCriticalToDataObjIntegrityRefInputSupplierApp.execute(null);

		EObject criticalSupplierIntegrityRefInput;
		Rule criticalRuleIntegrityRefInput = addCriticalToDataObjIntegrityRefInputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalIntegrityRefInput = criticalRuleIntegrityRefInput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityRefInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleIntegrityRefInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityRefInputSupplierApp.getResultMatch()
					.getMultiMatches(criticalRuleIntegrityRefInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalIntegrityRefInput)) {
					criticalSupplierIntegrityRefInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrityRefInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  data object  Class case Integrity Output Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjIntegrityRefOutputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityRefOutputSupplier");
		RuleApplication addCriticalToDataObjIntegrityRefOutputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityRefOutputSupplierUnit,
				null);
		addCriticalToDataObjIntegrityRefOutputSupplierApp.execute(null);

		EObject criticalSupplierIntegrityRefOutput;
		Rule criticalRuleIntegrityRefOutput = addCriticalToDataObjIntegrityRefOutputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalIntegrityRefOutput = criticalRuleIntegrityRefOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityRefOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleIntegrityRefOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityRefOutputSupplierApp.getResultMatch()
					.getMultiMatches(criticalRuleIntegrityRefOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalIntegrityRefOutput)) {
					criticalSupplierIntegrityRefOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrityRefOutput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  data object  Class case Confidentiality Input Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjConfidentialityRefInputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityRefInputSupplier");
		RuleApplication addCriticalToDataObjConfidentialityRefInputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityRefInputSupplierUnit,
				null);
		addCriticalToDataObjConfidentialityRefInputSupplierApp.execute(null);

		EObject criticalSupplierConfidentialityRefInput;
		Rule criticalRuleConfidentialityRefInput = addCriticalToDataObjConfidentialityRefInputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalConfidentialityRefInput = criticalRuleConfidentialityRefInput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityRefInputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityRefInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityRefInputSupplierApp.getResultMatch()
					.getMultiMatches(criticalRuleConfidentialityRefInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalConfidentialityRefInput)) {
					criticalSupplierConfidentialityRefInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierConfidentialityRefInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  data object  Class case Confidentiality Output Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjConfidentialityRefOutputSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityRefOutputSupplier");
		RuleApplication addCriticalToDataObjConfidentialityRefOutputSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityRefOutputSupplierUnit,
				null);
		addCriticalToDataObjConfidentialityRefOutputSupplierApp.execute(null);

		EObject criticalSupplierConfidentialityRefOutput;
		Rule criticalRuleConfidentialityRefOutput = addCriticalToDataObjConfidentialityRefOutputSupplierUnit.getMultiRules().get(0);
		Rule operationsCriticalConfidentialityRefOutput = criticalRuleConfidentialityRefOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityRefOutputSupplierApp.getResultMatch().getMultiMatches(criticalRuleConfidentialityRefOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityRefOutputSupplierApp.getResultMatch()
					.getMultiMatches(criticalRuleConfidentialityRefOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalConfidentialityRefOutput)) {
					criticalSupplierConfidentialityRefOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierConfidentialityRefOutput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		//*************************************SECURE DEPENDENCY GROUP: (E) ADD CRITICAL TO Clients case data objects***************/
		// ********************************************************************************************************************************/

		/*-----------------------Add <<critical>> to  Client  Class Case (Integrity-DataInput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjIntegrityInputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityInputClient");
		RuleApplication addCriticalToDataObjIntegrityInputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityInputClientUnit, null);
		addCriticalToDataObjIntegrityInputClientApp.execute(null);

		EObject criticalClientIntegrityInput;
		Rule criticalRuleClientIntegrityInput = addCriticalToDataObjIntegrityInputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientIntegrityInput = criticalRuleClientIntegrityInput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientIntegrityInput)) {
					criticalClientIntegrityInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientIntegrityInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  Client  Class Case (Integrity-DataOutput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjIntegrityOutputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityOutputClient");
		RuleApplication addCriticalToDataObjIntegrityOutputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityOutputClientUnit, null);
		addCriticalToDataObjIntegrityOutputClientApp.execute(null);

		EObject criticalClientIntegrityOutput;
		Rule criticalRuleClientIntegrityOutput = addCriticalToDataObjIntegrityOutputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientIntegrityOutput = criticalRuleClientIntegrityOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientIntegrityOutput)) {
					criticalClientIntegrityOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientIntegrityOutput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  Client  Class Case (Confidentiality-DataInput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjConfidentialityInputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityInputClient");
		RuleApplication addCriticalToDataObjConfidentialityInputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityInputClientUnit, null);
		addCriticalToDataObjConfidentialityInputClientApp.execute(null);

		EObject criticalClientConfidentialityInput;
		Rule criticalRuleClientConfidentialityInput = addCriticalToDataObjConfidentialityInputClientUnit.getMultiRules().get(0);
		Rule operationsClientConfidentialityInput = criticalRuleClientConfidentialityInput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientConfidentialityInput)) {
					criticalClientConfidentialityInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientConfidentialityInput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------Add <<critical>> to  Client  Class Case (Confidentiality-DataOutput)----------------------------------------------------------------*/

		Rule addCriticalToDataObjConfidentialityOutputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityOutputClient");
		RuleApplication addCriticalToDataObjConfidentialityOutputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityOutputClientUnit, null);
		addCriticalToDataObjConfidentialityOutputClientApp.execute(null);

		EObject criticalClientConfidentialityOutput;
		Rule criticalRuleClientConfidentialityOutput = addCriticalToDataObjConfidentialityOutputClientUnit.getMultiRules().get(0);
		Rule operationsClientConfidentialityOutput = criticalRuleClientConfidentialityOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientConfidentialityOutput)) {
					criticalClientConfidentialityOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientConfidentialityOutput);

				}
			}

		}

		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		//*************************************SECURE DEPENDENCY GROUP: (F) ADD CRITICAL TO Clients case data objects Reference***************/
		// ********************************************************************************************************************************/
		
		/*--------------------------------------------Add <<critical>> to  client  Class case Integrity Input Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjIntegrityRefInputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityRefInputClient");
		RuleApplication addCriticalToDataObjIntegrityRefInputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityRefInputClientUnit,
				null);
		addCriticalToDataObjIntegrityRefInputClientApp.execute(null);

		EObject criticalClientIntegrityRefInput;
		Rule criticalRuleClientIntegrityRefInput = addCriticalToDataObjIntegrityRefInputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientIntegrityRefInput = criticalRuleClientIntegrityRefInput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityRefInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityRefInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityRefInputClientApp.getResultMatch()
					.getMultiMatches(criticalRuleClientIntegrityRefInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientIntegrityRefInput)) {
					criticalClientIntegrityRefInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientIntegrityRefInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  client  Class case Integrity Output Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjIntegrityRefOutputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjIntegrityRefOutputClient");
		RuleApplication addCriticalToDataObjIntegrityRefOutputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjIntegrityRefOutputClientUnit,
				null);
		addCriticalToDataObjIntegrityRefOutputClientApp.execute(null);

		EObject criticalClientIntegrityRefOutput;
		Rule criticalRuleClientIntegrityRefOutput = addCriticalToDataObjIntegrityRefOutputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientIntegrityRefOutput = criticalRuleClientIntegrityRefOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjIntegrityRefOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientIntegrityRefOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjIntegrityRefOutputClientApp.getResultMatch()
					.getMultiMatches(criticalRuleClientIntegrityRefOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientIntegrityRefOutput)) {
					criticalClientIntegrityRefOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientIntegrityRefOutput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  client  Class case Confidentiality Input Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjConfidentialityRefInputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityRefInputClient");
		RuleApplication addCriticalToDataObjConfidentialityRefInputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityRefInputClientUnit,
				null);
		addCriticalToDataObjConfidentialityRefInputClientApp.execute(null);

		EObject criticalClientConfidentialityRefInput;
		Rule criticalRuleClientConfidentialityRefInput = addCriticalToDataObjConfidentialityRefInputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientConfidentialityRefInput = criticalRuleClientConfidentialityRefInput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityRefInputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityRefInput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityRefInputClientApp.getResultMatch()
					.getMultiMatches(criticalRuleClientConfidentialityRefInput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientConfidentialityRefInput)) {
					criticalClientConfidentialityRefInput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientConfidentialityRefInput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> to  client  Class case Confidentiality Output Reference--------------------------------------------------------------------------------------*/
		Rule addCriticalToDataObjConfidentialityRefOutputClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalToDataObjConfidentialityRefOutputClient");
		RuleApplication addCriticalToDataObjConfidentialityRefOutputClientApp = new RuleApplicationImpl(engine, graph, addCriticalToDataObjConfidentialityRefOutputClientUnit,
				null);
		addCriticalToDataObjConfidentialityRefOutputClientApp.execute(null);

		EObject criticalClientConfidentialityRefOutput;
		Rule criticalRuleClientConfidentialityRefOutput = addCriticalToDataObjConfidentialityRefOutputClientUnit.getMultiRules().get(0);
		Rule operationsCriticalClientConfidentialityRefOutput = criticalRuleClientConfidentialityRefOutput.getMultiRules().get(0);

		if (!addCriticalToDataObjConfidentialityRefOutputClientApp.getResultMatch().getMultiMatches(criticalRuleClientConfidentialityRefOutput).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalToDataObjConfidentialityRefOutputClientApp.getResultMatch()
					.getMultiMatches(criticalRuleClientConfidentialityRefOutput)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCriticalClientConfidentialityRefOutput)) {
					criticalClientConfidentialityRefOutput = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalClientConfidentialityRefOutput);

				}
			}

		}
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		
		//*************************************SECURE DEPENDENCY GROUP: (G) ADD CRITICAL TO CLASSES CASE MESSAGE FLOW****************/
		// *************************************************************************************************************************/
		/*--------------------------------------------Add <<critical>> Secrecy to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalSecrecyClient");
		RuleApplication addCriticalClientApp = new RuleApplicationImpl(engine, graph, addCriticalClientUnit, null);
		addCriticalClientApp.execute(null);

		EObject criticalCleint;
		Rule criticalClientRule = addCriticalClientUnit.getMultiRules().get(0);
		Rule operationsClient = criticalClientRule.getMultiRules().get(0);

		if (!addCriticalClientApp.getResultMatch().getMultiMatches(criticalClientRule).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalClientApp.getResultMatch()
					.getMultiMatches(criticalClientRule)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClient)) {
					criticalCleint = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleint);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Secrecy to  Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalSupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalSecrecySupplier");
		RuleApplication addCriticalSupplierApp = new RuleApplicationImpl(engine, graph, addCriticalSupplierUnit, null);
		addCriticalSupplierApp.execute(null);

		EObject criticalSupplier;
		Rule criticalSupplierRule = addCriticalSupplierUnit.getMultiRules().get(0);
		Rule operationsSupplier = criticalSupplierRule.getMultiRules().get(0);

		if (!addCriticalSupplierApp.getResultMatch().getMultiMatches(criticalSupplierRule).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalSupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRule)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSupplier)) {
					criticalSupplier = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplier);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Integrity to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalIntegrityClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalIntegrityClient");
		RuleApplication addCriticalIntegrityClientApp = new RuleApplicationImpl(engine, graph,
				addCriticalIntegrityClientUnit, null);
		addCriticalIntegrityClientApp.execute(null);

		EObject criticalCleintIntegrity;
		Rule criticalClientRuleIntegrity = addCriticalIntegrityClientUnit.getMultiRules().get(0);
		Rule operationsClientIntegrity = criticalClientRuleIntegrity.getMultiRules().get(0);

		if (!addCriticalIntegrityClientApp.getResultMatch().getMultiMatches(criticalClientRuleIntegrity).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalIntegrityClientApp.getResultMatch()
					.getMultiMatches(criticalClientRuleIntegrity)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientIntegrity)) {
					criticalCleintIntegrity = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleintIntegrity);
				}
			}
		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Integrity to  Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalIntegritySupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalIntegritySupplier");
		RuleApplication addCriticalIntegritySupplierApp = new RuleApplicationImpl(engine, graph,
				addCriticalIntegritySupplierUnit, null);
		addCriticalIntegritySupplierApp.execute(null);

		EObject criticalSupplierIntegrity;
		Rule criticalSupplierRuleIntegrity = addCriticalIntegritySupplierUnit.getMultiRules().get(0);
		Rule operationsSupplierIntegrity = criticalSupplierRuleIntegrity.getMultiRules().get(0);

		if (!addCriticalIntegritySupplierApp.getResultMatch().getMultiMatches(criticalSupplierRuleIntegrity)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalIntegritySupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRuleIntegrity)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSupplierIntegrity)) {
					criticalSupplierIntegrity = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrity);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Secrecy Throw to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalThrowSecrecyClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalThrowSecrecyClient");
		RuleApplication addCriticalThrowSecrecyClientApp = new RuleApplicationImpl(engine, graph,
				addCriticalThrowSecrecyClientUnit, null);
		addCriticalThrowSecrecyClientApp.execute(null);

		EObject criticalCleintThrowSecrecy;
		Rule criticalClientRuleThrowSecrecy = addCriticalThrowSecrecyClientUnit.getMultiRules().get(0);
		Rule operationsClientThrowSecrecy = criticalClientRuleThrowSecrecy.getMultiRules().get(0);

		if (!addCriticalThrowSecrecyClientApp.getResultMatch().getMultiMatches(criticalClientRuleThrowSecrecy)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalThrowSecrecyClientApp.getResultMatch()
					.getMultiMatches(criticalClientRuleThrowSecrecy)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientThrowSecrecy)) {
					criticalCleintThrowSecrecy = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleintThrowSecrecy);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Secrecy Throw to  Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalThrowSecrecySupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalThrowSecrecySupplier");
		RuleApplication addCriticalThrowSecrecySupplierApp = new RuleApplicationImpl(engine, graph,
				addCriticalThrowSecrecySupplierUnit, null);
		addCriticalThrowSecrecySupplierApp.execute(null);

		EObject criticalSupplierThrowSecrecy;
		Rule criticalSupplierRuleThrowSecrecy = addCriticalThrowSecrecySupplierUnit.getMultiRules().get(0);
		Rule operationsSupplierThrowSecrecy = criticalSupplierRuleThrowSecrecy.getMultiRules().get(0);

		if (!addCriticalThrowSecrecySupplierApp.getResultMatch().getMultiMatches(criticalSupplierRuleThrowSecrecy)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalThrowSecrecySupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRuleThrowSecrecy)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSupplierThrowSecrecy)) {
					criticalSupplierThrowSecrecy = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierThrowSecrecy);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> Integrity Throw to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalThrowIntegrityClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalThrowIntegrityClient");
		RuleApplication addCriticalThrowIntegrityClientApp = new RuleApplicationImpl(engine, graph,
				addCriticalThrowIntegrityClientUnit, null);
		addCriticalThrowIntegrityClientApp.execute(null);

		EObject criticalCleintThrowIntegrity;
		Rule criticalClientRuleThrowIntegrity = addCriticalThrowIntegrityClientUnit.getMultiRules().get(0);
		Rule operationsClientThrowIntegrity = criticalClientRuleThrowIntegrity.getMultiRules().get(0);

		if (!addCriticalThrowIntegrityClientApp.getResultMatch().getMultiMatches(criticalClientRuleThrowIntegrity)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalThrowIntegrityClientApp.getResultMatch()
					.getMultiMatches(criticalClientRuleThrowIntegrity)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientThrowIntegrity)) {
					criticalCleintThrowIntegrity = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleintThrowIntegrity);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Integrity Throw to  Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalThrowIntegritySupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalThrowIntegritySupplier");
		RuleApplication addCriticalThrowIntegritySupplierApp = new RuleApplicationImpl(engine, graph,
				addCriticalThrowIntegritySupplierUnit, null);
		addCriticalThrowIntegritySupplierApp.execute(null);

		EObject criticalSupplierThrowIntegrity;
		Rule criticalSupplierRuleThrowIntegrity = addCriticalThrowIntegritySupplierUnit.getMultiRules().get(0);
		Rule operationsSupplierThrowIntegrity = criticalSupplierRuleThrowIntegrity.getMultiRules().get(0);

		if (!addCriticalThrowIntegritySupplierApp.getResultMatch().getMultiMatches(criticalSupplierRuleThrowIntegrity)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalThrowIntegritySupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRuleThrowIntegrity)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch
						.getMultiMatches(operationsSupplierThrowIntegrity)) {
					criticalSupplierThrowIntegrity = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierThrowIntegrity);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> Secrecy End to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalEndSecrecyClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalEndSecrecyClient");
		RuleApplication addCriticalEndSecrecyClientApp = new RuleApplicationImpl(engine, graph,
				addCriticalEndSecrecyClientUnit, null);
		addCriticalEndSecrecyClientApp.execute(null);

		EObject criticalCleintSecrecyEnd;
		Rule criticalClientRuleSecrecyEnd = addCriticalEndSecrecyClientUnit.getMultiRules().get(0);
		Rule operationsClientSecrecyEnd = criticalClientRuleSecrecyEnd.getMultiRules().get(0);

		if (!addCriticalEndSecrecyClientApp.getResultMatch().getMultiMatches(criticalClientRuleSecrecyEnd).isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalEndSecrecyClientApp.getResultMatch()
					.getMultiMatches(criticalClientRuleSecrecyEnd)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientSecrecyEnd)) {
					criticalCleintSecrecyEnd = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleintSecrecyEnd);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> to  Secrecy END Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalEndSecrecySupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalEndSecrecySupplier");
		RuleApplication addCriticalEndSecrecySupplierApp = new RuleApplicationImpl(engine, graph,
				addCriticalEndSecrecySupplierUnit, null);
		addCriticalEndSecrecySupplierApp.execute(null);

		EObject criticalSupplierSecrecyEnd;
		Rule criticalSupplierRuleSecrecyEnd = addCriticalEndSecrecySupplierUnit.getMultiRules().get(0);
		Rule operationsSupplierSecrecyEnd = criticalSupplierRuleSecrecyEnd.getMultiRules().get(0);

		if (!addCriticalEndSecrecySupplierApp.getResultMatch().getMultiMatches(criticalSupplierRuleSecrecyEnd)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalEndSecrecySupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRuleSecrecyEnd)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSupplierSecrecyEnd)) {
					criticalSupplierSecrecyEnd = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierSecrecyEnd);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*--------------------------------------------Add <<critical>> integrity End to  CLEINT CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalEndIntegrityClientUnit = (Rule) module_SecureDependency.getUnit("AddCriticalEndIntegrityClient");
		RuleApplication addCriticalEndIntegrityClientApp = new RuleApplicationImpl(engine, graph,
				addCriticalEndIntegrityClientUnit, null);
		addCriticalEndIntegrityClientApp.execute(null);

		EObject criticalCleintIntegrityEnd;
		Rule criticalClientRuleIntegrityEnd = addCriticalEndIntegrityClientUnit.getMultiRules().get(0);
		Rule operationsClientIntegrityEnd = criticalClientRuleIntegrityEnd.getMultiRules().get(0);

		if (!addCriticalEndIntegrityClientApp.getResultMatch().getMultiMatches(criticalClientRuleIntegrityEnd)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalEndIntegrityClientApp.getResultMatch()
					.getMultiMatches(criticalClientRuleIntegrityEnd)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsClientIntegrityEnd)) {
					criticalCleintIntegrityEnd = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalCleintIntegrityEnd);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*--------------------------------------------Add <<critical>> Integrity End to  Supplier CLASS  -------------------------------------------------------------------------------------------------*/

		Rule addCriticalEndIntegritySupplierUnit = (Rule) module_SecureDependency.getUnit("AddCriticalEndIntegritySupplier");
		RuleApplication addCriticalEndIntegritySupplierApp = new RuleApplicationImpl(engine, graph,
				addCriticalEndIntegritySupplierUnit, null);
		addCriticalEndIntegritySupplierApp.execute(null);

		EObject criticalSupplierIntegrityEnd;
		Rule criticalSupplierRuleIntegrityEnd = addCriticalEndIntegritySupplierUnit.getMultiRules().get(0);
		Rule operationsSupplierIntegrityEnd = criticalSupplierRuleIntegrityEnd.getMultiRules().get(0);

		if (!addCriticalEndIntegritySupplierApp.getResultMatch().getMultiMatches(criticalSupplierRuleIntegrityEnd)
				.isEmpty()) {
			for (Match firstRuleMultiMatch : addCriticalEndIntegritySupplierApp.getResultMatch()
					.getMultiMatches(criticalSupplierRuleIntegrityEnd)) {
				for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSupplierIntegrityEnd)) {
					criticalSupplierIntegrityEnd = (EObject) secondRuleMultiMatch.getParameterValues().get(0);
					addToResource(criticalSupplierIntegrityEnd);
				}
			}

		}

		/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		
		
		
		
		//*************************************SECURE LINKS GROUP: (A) TRANSFORM PARTICIPANTS AND LANES TO NODES****************/
		// *************************************************************************************************************************/
		
		/*-------------------------Transform Each Process To Server Node-----------------------------------------------*/
		Unit transformProcessToServerNodeUnit = module_SecureLinks.getUnit("AddServerNodeForEachProcessParticipant");
		UnitApplication transformProcessToServerNodeApp = new UnitApplicationImpl(engine, graph,
				transformProcessToServerNodeUnit, null);
		InterpreterUtil.executeOrDie(transformProcessToServerNodeApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*-------------------------Transform Each Process has lanes To Server Node-----------------------------------------------*/
		Unit addServerNodeForEachProcessLaneUnit = module_SecureLinks.getUnit("AddServerNodeForEachProcessLane");
		UnitApplication addServerNodeForEachProcessLaneApp = new UnitApplicationImpl(engine, graph,
				addServerNodeForEachProcessLaneUnit, null);
		InterpreterUtil.executeOrDie(addServerNodeForEachProcessLaneApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*-------------------------add application artifacts to a Process Server Node that has lanes-----------------------------------------------*/
		Unit addApplicationArtifactLaneServerNodeUnit = module_SecureLinks.getUnit("AddApplicationArtifactLaneServerNode");
		UnitApplication addApplicationArtifactLaneServerNodeApp = new UnitApplicationImpl(engine, graph,
				addApplicationArtifactLaneServerNodeUnit, null);
		InterpreterUtil.executeOrDie(addApplicationArtifactLaneServerNodeApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		
		/*-------------------------Transform participants to client nodes-----------------------------------------------*/
		Unit transformParticipantToNodeUnit = module_SecureLinks.getUnit("TransformParticipantToClientNode");
		UnitApplication transformParticipantToNodeApp = new UnitApplicationImpl(engine, graph,
				transformParticipantToNodeUnit, null);
		InterpreterUtil.executeOrDie(transformParticipantToNodeApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/

		/*-------------------------Transform lanes to clients nodes-----------------------------------------------*/
		Unit transformLaneToNodeUnit = module_SecureLinks.getUnit("TransformLaneToClientNode");
		UnitApplication transformLaneToNodeApp = new UnitApplicationImpl(engine, graph,
				transformLaneToNodeUnit, null);
		InterpreterUtil.executeOrDie(transformLaneToNodeApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/
		

		
		//*************************************SECURE LINKS GROUP: (B) TRANSFORM DATA OBJECTS TO ARTIFACTS**************************/
		// *************************************************************************************************************************/
		
		
		/*-------------------------Transform Data Objects to artifacts in the server nodes-----------------------------------------------*/
		Unit transformDataObjectToArtifactUnit = module_SecureLinks.getUnit("TransformDataObjectToArtifact");
		UnitApplication transformDataObjectToArtifactApp = new UnitApplicationImpl(engine, graph,
				transformDataObjectToArtifactUnit, null);
		InterpreterUtil.executeOrDie(transformDataObjectToArtifactApp);
		/*---------------------------------------------------------------------------------------------------------------------------*/

		
		//*************************************SECURE LINKS GROUP: (C) ADD Internet COMMUNICATION PATHS*****************************/
        // *************************************************************************************************************************/
		
		/*-------------------------Internet Communication Paths between Participant and its corresponding Server------------------------*/
		 Rule addIntrnetToPathUnit = (Rule)module_SecureLinks.getUnit("AddInternetCommunicationPathParticipantServer");
		 RuleApplication addIntrnetToPathApp = new RuleApplicationImpl(engine, graph,
				 addIntrnetToPathUnit, null);
		 addIntrnetToPathApp.execute(null);
		 
		 EObject pathInternet;
		 Rule internetPathRule =addIntrnetToPathUnit.getMultiRules().get(0);
		 
		 
		 if(!addIntrnetToPathApp.getResultMatch().getMultiMatches(internetPathRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addIntrnetToPathApp.getResultMatch().getMultiMatches(internetPathRule))
			 {  
				 pathInternet= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
				   
			     addToResource(pathInternet);
			 }
		
		 }

		/*---------------------------------------------------------------------------------------------------------------------------*/
	
		 /*-------------------------Internet Communication Paths between Participant and its corresponding Server Case (Accountability)------------------------*/

		 Rule addIntrnetToPathAccUnit = (Rule)module_SecureLinks.getUnit("AddInternetCommunicationPathParticipantServerAccount");
		 RuleApplication addIntrnetToPathAccApp = new RuleApplicationImpl(engine, graph,
				 addIntrnetToPathAccUnit, null);
		 addIntrnetToPathAccApp.execute(null);
		 
		 EObject pathInternetAcc;
		 Rule internetPathRuleAcc =addIntrnetToPathAccUnit.getMultiRules().get(0);
		 
		 
		 if(!addIntrnetToPathAccApp.getResultMatch().getMultiMatches(internetPathRuleAcc).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addIntrnetToPathAccApp.getResultMatch().getMultiMatches(internetPathRuleAcc))
			 {  
				 pathInternetAcc= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
				   
			     addToResource(pathInternetAcc);
			 }
		
		 }
	/*---------------------------------------------------------------------------------------------------------------------------*/
		 
		/*-------------------------Internet Communication Paths between Lane and its corresponding Server------------------------*/
		 Rule addIntrnetToPathLaneUnit = (Rule)module_SecureLinks.getUnit("AddInternetCommunicationPathLaneServer");
		 RuleApplication addIntrnetToPathLaneApp = new RuleApplicationImpl(engine, graph,
				 addIntrnetToPathLaneUnit, null);
		 addIntrnetToPathLaneApp.execute(null);
		 
		 EObject pathInternetLane;
		 Rule internetPathLaneRule =addIntrnetToPathLaneUnit.getMultiRules().get(0);
		 
		 
		 if(!addIntrnetToPathLaneApp.getResultMatch().getMultiMatches(internetPathLaneRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addIntrnetToPathLaneApp.getResultMatch().getMultiMatches(internetPathLaneRule))
			 {  
				 pathInternetLane= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
				   
			     addToResource(pathInternetLane);
			 }
		
		 }

		/*---------------------------------------------------------------------------------------------------------------------------*/
	 


		/*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case Start Event/DataOut)------------------------*/
		 Rule addCommunicationPathLaneServerStartOutUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerStartOut");
		 RuleApplication addCommunicationPathLaneServerStartOutApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerStartOutUnit, null);
		 addCommunicationPathLaneServerStartOutApp.execute(null);
		 
		 EObject pathEncrytedLaneStartOut;
		 Rule encrytedPathLaneStartOutRule =addCommunicationPathLaneServerStartOutUnit.getMultiRules().get(0);
		 Rule operationsStartOut = encrytedPathLaneStartOutRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerStartOutApp.getResultMatch().getMultiMatches(encrytedPathLaneStartOutRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerStartOutApp.getResultMatch().getMultiMatches(encrytedPathLaneStartOutRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsStartOut))
		 			{
					    pathEncrytedLaneStartOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneStartOut);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	
	
    /*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case Catch Event/DataOut)------------------------*/
		 Rule addCommunicationPathLaneServerCatchOutUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerCatchOut");
		 RuleApplication addCommunicationPathLaneServerCatchOutApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerCatchOutUnit, null);
		 addCommunicationPathLaneServerCatchOutApp.execute(null);
		 
		 EObject pathEncrytedLaneCatchOut;
		 Rule encrytedPathLaneCatchOutRule =addCommunicationPathLaneServerCatchOutUnit.getMultiRules().get(0);
		 Rule operationsCatchOut = encrytedPathLaneCatchOutRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerCatchOutApp.getResultMatch().getMultiMatches(encrytedPathLaneCatchOutRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerCatchOutApp.getResultMatch().getMultiMatches(encrytedPathLaneCatchOutRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsCatchOut))
		 			{
					     pathEncrytedLaneCatchOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneCatchOut);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	
	
	/*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case Task/DataOut)------------------------*/
		 Rule addCommunicationPathLaneServerTaskOutUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerTaskOut");
		 RuleApplication addCommunicationPathLaneServerTaskOutApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerTaskOutUnit, null);
		 addCommunicationPathLaneServerTaskOutApp.execute(null);
		 
		 EObject pathEncrytedLaneTaskOut;
		 Rule encrytedPathLaneTaskOutRule =addCommunicationPathLaneServerTaskOutUnit.getMultiRules().get(0);
		 Rule operationsTaskOut = encrytedPathLaneTaskOutRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerTaskOutApp.getResultMatch().getMultiMatches(encrytedPathLaneTaskOutRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerTaskOutApp.getResultMatch().getMultiMatches(encrytedPathLaneTaskOutRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskOut))
		 			{
					    pathEncrytedLaneTaskOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneTaskOut);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	
		 
	 
	
    /*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case End Event/DataInput)------------------------*/
		 Rule addCommunicationPathLaneServerEndInputUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerEndInput");
		 RuleApplication addCommunicationPathLaneServerEndInputApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerEndInputUnit, null);
		 addCommunicationPathLaneServerEndInputApp.execute(null);
		 
		 EObject pathEncrytedLaneEndInput;
		 Rule encrytedPathLaneEndInputRule =addCommunicationPathLaneServerEndInputUnit.getMultiRules().get(0);
		 Rule operationsEndInput = encrytedPathLaneEndInputRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerEndInputApp.getResultMatch().getMultiMatches(encrytedPathLaneEndInputRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerEndInputApp.getResultMatch().getMultiMatches(encrytedPathLaneEndInputRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsEndInput))
		 			{
					  pathEncrytedLaneEndInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneEndInput);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	
	/*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case Throw Event/DataInput)------------------------*/
		 Rule addCommunicationPathLaneServerThrowInputUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerThrowInput");
		 RuleApplication addCommunicationPathLaneServerThrowInputApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerThrowInputUnit, null);
		 addCommunicationPathLaneServerThrowInputApp.execute(null);
		 
		 EObject pathEncrytedLaneThrowInput;
		 Rule encrytedPathLaneThrowInputRule =addCommunicationPathLaneServerThrowInputUnit.getMultiRules().get(0);
		 Rule operationsThrowInput = encrytedPathLaneThrowInputRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerThrowInputApp.getResultMatch().getMultiMatches(encrytedPathLaneThrowInputRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerThrowInputApp.getResultMatch().getMultiMatches(encrytedPathLaneThrowInputRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsThrowInput))
		 			{
					    pathEncrytedLaneThrowInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneThrowInput);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	
	/*-------------------------Internet Communication Paths between Lane and its corresponding Server (Case Task/DataInput)------------------------*/
		 Rule addCommunicationPathLaneServerTaskInputUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerTaskInput");
		 RuleApplication addCommunicationPathLaneServerTaskInputApp = new RuleApplicationImpl(engine, graph,
				 addCommunicationPathLaneServerTaskInputUnit, null);
		 addCommunicationPathLaneServerTaskInputApp.execute(null);
		 
		 EObject pathEncrytedLaneTaskInput;
		 Rule encrytedPathLaneTaskInputRule =addCommunicationPathLaneServerTaskInputUnit.getMultiRules().get(0);
		 Rule operationsTaskInput = encrytedPathLaneTaskInputRule.getMultiRules().get(0);

		 
		 if(!addCommunicationPathLaneServerTaskInputApp.getResultMatch().getMultiMatches(encrytedPathLaneTaskInputRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerTaskInputApp.getResultMatch().getMultiMatches(encrytedPathLaneTaskInputRule))
			 {  
				  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskInput))
		 			{
					    pathEncrytedLaneTaskInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
			   
		 				addToResource(pathEncrytedLaneTaskInput);
		 			}
			 }
		
		 }

    /*---------------------------------------------------------------------------------------------------------------------------*/	

	//*************************************SECURE LINKS GROUP: (C) ADD Encrypted COMMUNICATION PATHS*****************************/
	// *************************************************************************************************************************/	 
	/*-------------------------Encrypted Communication Paths between Participant and its corresponding Server (Case Confidentiality)------------------------*/
		 Rule addEncrytedConfToPathUnit = (Rule)module_SecureLinks.getUnit("AddEncryptedCommunicationPathParticipantServerConfidentiality");
		 RuleApplication addEncrytedConfToPathApp = new RuleApplicationImpl(engine, graph,
				 addEncrytedConfToPathUnit, null);
		 addEncrytedConfToPathApp.execute(null);
		 
		 EObject pathEncrytedConf;
		 Rule encrytedConfPathRule =addEncrytedConfToPathUnit.getMultiRules().get(0);
		 
		 
		 if(!addEncrytedConfToPathApp.getResultMatch().getMultiMatches(encrytedConfPathRule).isEmpty())
		 {
			 for (Match firstRuleMultiMatch:addEncrytedConfToPathApp.getResultMatch().getMultiMatches(encrytedConfPathRule))
			 {  
				 pathEncrytedConf= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
				   
			     addToResource(pathEncrytedConf);
			 }
		
		 }

		/*---------------------------------------------------------------------------------------------------------------------------*/
		 
		/*-------------------------Encrypted Communication Paths between Participant and its corresponding Server (Case Integrity)------------------------*/
			 Rule addEncrytedIntToPathUnit = (Rule)module_SecureLinks.getUnit("AddEncryptedCommunicationPathParticipantServerIntegrity");
			 RuleApplication addEncrytedIntToPathApp = new RuleApplicationImpl(engine, graph,
					 addEncrytedIntToPathUnit, null);
			 addEncrytedIntToPathApp.execute(null);
			 
			 EObject pathEncrytedInt;
			 Rule encrytedIntPathRule =addEncrytedIntToPathUnit.getMultiRules().get(0);
			 
			 
			 if(!addEncrytedIntToPathApp.getResultMatch().getMultiMatches(encrytedIntPathRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addEncrytedIntToPathApp.getResultMatch().getMultiMatches(encrytedIntPathRule))
				 {  
					 pathEncrytedInt= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
					   
				     addToResource(pathEncrytedInt);
				 }
			
			 }

	    /*---------------------------------------------------------------------------------------------------------------------------*/		 
		 
	    /*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataOut/Confidentiality)------------------------*/
			 Rule addCommunicationPathLaneServerConfTaskOutUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerConfOut");
			 RuleApplication addCommunicationPathLaneServerConfTaskOutApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathLaneServerConfTaskOutUnit, null);
			 addCommunicationPathLaneServerConfTaskOutApp.execute(null);
			 
			 EObject pathEncrytedTaskOutConf;
			 Rule encrytedPathTaskOutConfRule =addCommunicationPathLaneServerConfTaskOutUnit.getMultiRules().get(0);
			 Rule operationsTaskOutConf = encrytedPathTaskOutConfRule.getMultiRules().get(0);
			 
			 if(!addCommunicationPathLaneServerConfTaskOutApp.getResultMatch().getMultiMatches(encrytedPathTaskOutConfRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerConfTaskOutApp.getResultMatch().getMultiMatches(encrytedPathTaskOutConfRule))
				 {  
					 for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskOutConf))
					 {
						 pathEncrytedTaskOutConf= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
						   
					     addToResource(pathEncrytedTaskOutConf);
					 }
					 
				 }
			
			 }

	
			
	    /*---------------------------------------------------------------------------------------------------------------------------*/	


			 
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataOut/integrity)--------*/
			 Rule addCommunicationPathLaneServerIntTaskOutUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerIntOut");
			 RuleApplication addCommunicationPathLaneServerIntTaskOutApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathLaneServerIntTaskOutUnit, null);
			 addCommunicationPathLaneServerIntTaskOutApp.execute(null);
			 
			 EObject pathEncrytedTaskOutInt;
			 Rule encrytedPathTaskOutIntRule =addCommunicationPathLaneServerIntTaskOutUnit.getMultiRules().get(0);
			 Rule operationsTaskOutInt = encrytedPathTaskOutIntRule.getMultiRules().get(0);

			 
			 if(!addCommunicationPathLaneServerIntTaskOutApp.getResultMatch().getMultiMatches(encrytedPathTaskOutIntRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerIntTaskOutApp.getResultMatch().getMultiMatches(encrytedPathTaskOutIntRule))
				 {  
					 for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskOutInt))
			 			{
						    pathEncrytedTaskOutInt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(pathEncrytedTaskOutInt);
			 			}
				 }
			
			 }

	    /*---------------------------------------------------------------------------------------------------------------------------*/	

			 
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case /DataInput/Confidentiality)--------*/
			 Rule addCommunicationPathLaneServerTaskInputConfUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerInputConf");
			 RuleApplication addCommunicationPathLaneServerTaskInputConfpp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathLaneServerTaskInputConfUnit, null);
			 addCommunicationPathLaneServerTaskInputConfpp.execute(null);
			 
			 EObject pathEncrytedTaskInputConf;
			 Rule encrytedPathTaskInputConfRule =addCommunicationPathLaneServerTaskInputConfUnit.getMultiRules().get(0);
		     Rule operationsTaskInputConf = encrytedPathTaskInputConfRule.getMultiRules().get(0);
 
			 
			 if(!addCommunicationPathLaneServerTaskInputConfpp.getResultMatch().getMultiMatches(encrytedPathTaskInputConfRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerTaskInputConfpp.getResultMatch().getMultiMatches(encrytedPathTaskInputConfRule))
				 {  
					 for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskInputConf))
			 			{
						 pathEncrytedTaskInputConf= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(pathEncrytedTaskInputConf);
			 			}
				 }
			
			 }

	    /*---------------------------------------------------------------------------------------------------------------------------*/	
			 
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataInput/Integrity)--------*/
			 Rule addCommunicationPathLaneServerTaskInputIntUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerInputInt");
			 RuleApplication addCommunicationPathLaneServerTaskInputIntApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathLaneServerTaskInputIntUnit, null);
			 addCommunicationPathLaneServerTaskInputIntApp.execute(null);
			 
			 EObject pathEncrytedTaskInputInt;
			 Rule encrytedPathTaskInputIntRule =addCommunicationPathLaneServerTaskInputIntUnit.getMultiRules().get(0);
			 Rule operationsTaskInputInt = encrytedPathTaskInputIntRule.getMultiRules().get(0);
	 
			 
			 if(!addCommunicationPathLaneServerTaskInputIntApp.getResultMatch().getMultiMatches(encrytedPathTaskInputIntRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addCommunicationPathLaneServerTaskInputIntApp.getResultMatch().getMultiMatches(encrytedPathTaskInputIntRule))
				 {  
					 for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskInputInt))
			 			{
						    pathEncrytedTaskInputInt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(pathEncrytedTaskInputInt);
			 			}
				 }
			
			 }

	    /*---------------------------------------------------------------------------------------------------------------------------*/	
			 


		//***************SECURE LINKS GROUP: (D) ADD Internet/Encrypted COMMUNICATION PATHS (DataObject Reference)******************/
		// *************************************************************************************************************************/
		
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataOut/Confidentiality)------------------------*/
				Rule addCommunicationPathLaneServerConfTaskOutRefUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerConfOutRef");
				RuleApplication addCommunicationPathLaneServerConfTaskOutRefApp = new RuleApplicationImpl(engine, graph,
								 addCommunicationPathLaneServerConfTaskOutRefUnit, null);
				addCommunicationPathLaneServerConfTaskOutRefApp.execute(null);
						 
				EObject pathEncrytedTaskOutConfRef;
				Rule encrytedPathTaskOutConfRefRule =addCommunicationPathLaneServerConfTaskOutRefUnit.getMultiRules().get(0);
				Rule operationsTaskOutConfRef = encrytedPathTaskOutConfRefRule.getMultiRules().get(0);
						 
				if(!addCommunicationPathLaneServerConfTaskOutRefApp.getResultMatch().getMultiMatches(encrytedPathTaskOutConfRefRule).isEmpty())
					{
					  for (Match firstRuleMultiMatch:addCommunicationPathLaneServerConfTaskOutRefApp.getResultMatch().getMultiMatches(encrytedPathTaskOutConfRefRule))
						{  
							for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskOutConfRef))
							{
								pathEncrytedTaskOutConfRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
									   
							    addToResource(pathEncrytedTaskOutConfRef);
							}
								 
					  }
						
				}

		/*---------------------------------------------------------------------------------------------------------------------------*/	
				
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataInput/Confidentiality)------------------------*/
				
				Rule addCommunicationPathLaneServerConfTaskInputRefUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerConfInputRef");
				RuleApplication addCommunicationPathLaneServerConfTaskInputRefApp = new RuleApplicationImpl(engine, graph,
								 addCommunicationPathLaneServerConfTaskInputRefUnit, null);
				addCommunicationPathLaneServerConfTaskInputRefApp.execute(null);
						 
				EObject pathEncrytedTaskInputConfRef;
				Rule encrytedPathTaskInputConfRefRule =addCommunicationPathLaneServerConfTaskInputRefUnit.getMultiRules().get(0);
				Rule operationsTaskInputConfRef = encrytedPathTaskInputConfRefRule.getMultiRules().get(0);
						 
				if(!addCommunicationPathLaneServerConfTaskInputRefApp.getResultMatch().getMultiMatches(encrytedPathTaskInputConfRefRule).isEmpty())
					{
					  for (Match firstRuleMultiMatch:addCommunicationPathLaneServerConfTaskInputRefApp.getResultMatch().getMultiMatches(encrytedPathTaskInputConfRefRule))
						{  
							for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskInputConfRef))
							{
								pathEncrytedTaskInputConfRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
									   
							    addToResource(pathEncrytedTaskInputConfRef);
							}
								 
					  }
						
				}
		/*---------------------------------------------------------------------------------------------------------------------------*/	
				/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataOut/Integrity)------------------------*/
				Rule addCommunicationPathLaneServerIntTaskOutRefUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerIntOutRef");
				RuleApplication addCommunicationPathLaneServerIntTaskOutRefApp = new RuleApplicationImpl(engine, graph,
								 addCommunicationPathLaneServerIntTaskOutRefUnit, null);
				addCommunicationPathLaneServerIntTaskOutRefApp.execute(null);
						 
				EObject pathEncrytedTaskOutIntRef;
				Rule encrytedPathTaskOutIntRefRule =addCommunicationPathLaneServerIntTaskOutRefUnit.getMultiRules().get(0);
				Rule operationsTaskOutIntRef = encrytedPathTaskOutIntRefRule.getMultiRules().get(0);
						 
				if(!addCommunicationPathLaneServerIntTaskOutRefApp.getResultMatch().getMultiMatches(encrytedPathTaskOutIntRefRule).isEmpty())
					{
					  for (Match firstRuleMultiMatch:addCommunicationPathLaneServerIntTaskOutRefApp.getResultMatch().getMultiMatches(encrytedPathTaskOutIntRefRule))
						{  
							for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskOutIntRef))
							{
								pathEncrytedTaskOutIntRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
									   
							    addToResource(pathEncrytedTaskOutIntRef);
							}
								 
					  }
						
				}

		/*---------------------------------------------------------------------------------------------------------------------------*/	
				
		/*-------------------------Encrypted Communication Paths between Lane and its corresponding Server (Case DataInput/Integrity)------------------------*/
				
				Rule addCommunicationPathLaneServerIntTaskInputRefUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathLaneServerIntInputRef");
				RuleApplication addCommunicationPathLaneServerIntTaskInputRefApp = new RuleApplicationImpl(engine, graph,
								 addCommunicationPathLaneServerIntTaskInputRefUnit, null);
				addCommunicationPathLaneServerIntTaskInputRefApp.execute(null);
						 
				EObject pathEncrytedTaskInputIntRef;
				Rule encrytedPathTaskInputIntRefRule =addCommunicationPathLaneServerIntTaskInputRefUnit.getMultiRules().get(0);
				Rule operationsTaskInputIntRef = encrytedPathTaskInputIntRefRule.getMultiRules().get(0);
						 
				if(!addCommunicationPathLaneServerIntTaskInputRefApp.getResultMatch().getMultiMatches(encrytedPathTaskInputIntRefRule).isEmpty())
					{
					  for (Match firstRuleMultiMatch:addCommunicationPathLaneServerIntTaskInputRefApp.getResultMatch().getMultiMatches(encrytedPathTaskInputIntRefRule))
						{  
							for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsTaskInputIntRef))
							{
								pathEncrytedTaskInputIntRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
									   
							    addToResource(pathEncrytedTaskInputIntRef);
							}
								 
					  }
						
				}
		/*---------------------------------------------------------------------------------------------------------------------------*/	
	    /*-------------------------Internet Communication Paths between the process (DataObject Reference)------------------------*/
			 Rule addCommunicationPathBetweenProcessesUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathBetweenProcessesRef");
			 RuleApplication addCommunicationPathBetweenProcessesApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathBetweenProcessesUnit, null);
			 addCommunicationPathBetweenProcessesApp.execute(null);
			 
			 EObject pathInternetProcess;
			 Rule pathInternetProcessRule =addCommunicationPathBetweenProcessesUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathBetweenProcessesApp.getResultMatch().getMultiMatches(pathInternetProcessRule).isEmpty())
			 {
				 
					if (!addCommunicationPathBetweenProcessesApp.getResultMatch().getMultiMatches(pathInternetProcessRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathBetweenProcessesApp.getResultMatch().getMultiMatches(pathInternetProcessRule))
						 {  
							pathInternetProcess= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcess);
						 }
				}

			
			 }

	    /*---------------------------------------------------------------------------------------------------------------------------*/	
		
	    /*-------------------------	Encrypted Communication Paths between the processes (DataObject Reference/Confidentiality)------------------------*/		 
			 Rule addCommunicationPathBetweenProcessesRefConfUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathBetweenProcessesRefConf");
			 RuleApplication addCommunicationPathBetweenProcessesRefConfApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathBetweenProcessesRefConfUnit, null);
			 addCommunicationPathBetweenProcessesRefConfApp.execute(null);
			 
			 EObject pathEncryptedProcessRefConf;
			 Rule pathEncryptedProcessRefConfRule =addCommunicationPathBetweenProcessesRefConfUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathBetweenProcessesRefConfApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefConfRule).isEmpty())
			 {
				 
					if (!addCommunicationPathBetweenProcessesRefConfApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefConfRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathBetweenProcessesRefConfApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefConfRule))
						 {  
							pathEncryptedProcessRefConf= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncryptedProcessRefConf);
						 }
				}

			
			 }
		 
	    /*---------------------------------------------------------------------------------------------------------------------------*/	
	   /*-------------------------	Encrypted Communication Paths between the processes (DataObject Reference/Integrity)------------------------*/		 
			 Rule addCommunicationPathBetweenProcessesRefIntUnit = (Rule)module_SecureLinks.getUnit("AddCommunicationPathBetweenProcessesRefInt");
			 RuleApplication addCommunicationPathBetweenProcessesRefIntApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathBetweenProcessesRefIntUnit, null);
			 addCommunicationPathBetweenProcessesRefIntApp.execute(null);
			 
			 EObject pathEncryptedProcessRefInt;
			 Rule pathEncryptedProcessRefIntRule =addCommunicationPathBetweenProcessesRefIntUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathBetweenProcessesRefIntApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefIntRule).isEmpty())
			 {
				 
					if (!addCommunicationPathBetweenProcessesRefIntApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefIntRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathBetweenProcessesRefIntApp.getResultMatch().getMultiMatches(pathEncryptedProcessRefIntRule))
						 {  
							pathEncryptedProcessRefInt= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncryptedProcessRefInt);
						 }
				}

			
			 }
		 
	    /*---------------------------------------------------------------------------------------------------------------------------*/			 
	
	    //***************SECURE LINKS GROUP: (E) ADD Internet/Encrypted COMMUNICATION PATHS (Message Flow exists)******************/
		// *************************************************************************************************************************/
			
		/*-------------------------Internet Communication Paths between the process (Message Flow Task_Task)------------------------*/
			 
			 Rule addCommunicationPathMessageFlowTask_TaskUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_Task");
			 RuleApplication addCommunicationPathMessageFlowTask_TaskApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_TaskUnit, null);
			 addCommunicationPathMessageFlowTask_TaskApp.execute(null);
			 
			 EObject pathInternetProcessTask_Task;
			 Rule pathInternetProcessTask_TaskRule =addCommunicationPathMessageFlowTask_TaskUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskRule))
						 {  
							pathInternetProcessTask_Task= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_Task);
						 }
				}

			
			 }		
			 
	   /*---------------------------------------------------------------------------------------------------------------------------*/			 
	
       /*-------------------------Internet Communication Paths between the process (Message Flow Task_Start)------------------------*/

			 Rule addCommunicationPathMessageFlowTask_StartUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_Start");
			 RuleApplication addCommunicationPathMessageFlowTask_StartApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_StartUnit, null);
			 addCommunicationPathMessageFlowTask_StartApp.execute(null);
			 
			 EObject pathInternetProcessTask_Start;
			 Rule pathInternetProcessTask_StartRule =addCommunicationPathMessageFlowTask_StartUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_StartApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_StartApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_StartApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartRule))
						 {  
							pathInternetProcessTask_Start= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_Start);
						 }
				}

			
			 }
		 /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
	     /*-------------------------Internet Communication Paths between the process (Message Flow Task_Catch)------------------------*/			 
			 Rule addCommunicationPathMessageFlowTask_CatchUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_Catch");
			 RuleApplication addCommunicationPathMessageFlowTask_CatchApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_CatchUnit, null);
			 addCommunicationPathMessageFlowTask_CatchApp.execute(null);
			 
			 EObject pathInternetProcessTask_Catch;
			 Rule pathInternetProcessTask_CatchRule =addCommunicationPathMessageFlowTask_CatchUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchRule))
						 {  
							pathInternetProcessTask_Catch= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_Catch);
						 }
				}

			
			 }
			 
         /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
		 /*-------------------------Internet Communication Paths between the process (Message Flow End_Start)------------------------*/			 
			 Rule addCommunicationPathMessageFlowEnd_StartUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_Start");
			 RuleApplication addCommunicationPathMessageFlowEnd_StartApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_StartUnit, null);
			 addCommunicationPathMessageFlowEnd_StartApp.execute(null);
			 
			 EObject pathInternetProcessEnd_Start;
			 Rule pathInternetProcessEnd_StartRule =addCommunicationPathMessageFlowEnd_StartUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_StartApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_StartApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_StartApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartRule))
						 {  
							pathInternetProcessEnd_Start= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_Start);
						 }
				}

			
			 }
	  /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
	  /*-------------------------Internet Communication Paths between the process (Message Flow End_Catch)------------------------*/			 
			 
			 Rule addCommunicationPathMessageFlowEnd_CatchUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_Catch");
			 RuleApplication addCommunicationPathMessageFlowEnd_CatchApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_CatchUnit, null);
			 addCommunicationPathMessageFlowEnd_CatchApp.execute(null);
			 
			 EObject pathInternetProcessEnd_Catch;
			 Rule pathInternetProcessEnd_CatchRule =addCommunicationPathMessageFlowEnd_CatchUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchRule))
						 {  
							pathInternetProcessEnd_Catch= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_Catch);
						 }
				}

			
			 }
	  /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
	  /*-------------------------Internet Communication Paths between the process (Message Flow End_Task)------------------------*/			 
			 Rule addCommunicationPathMessageFlowEnd_TaskUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_Task");
			 RuleApplication addCommunicationPathMessageFlowEnd_TaskApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_TaskUnit, null);
			 addCommunicationPathMessageFlowEnd_TaskApp.execute(null);
			 
			 EObject pathInternetProcessEnd_Task;
			 Rule pathInternetProcessEnd_TaskRule =addCommunicationPathMessageFlowEnd_TaskUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskRule))
						 {  
							pathInternetProcessEnd_Task= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_Task);
						 }
				}

			
			 }
	  /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
	  /*-------------------------Internet Communication Paths between the process (Message Flow Throw_Task)------------------------*/			 
			 Rule addCommunicationPathMessageFlowThrow_TaskUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_Task");
			 RuleApplication addCommunicationPathMessageFlowThrow_TaskApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_TaskUnit, null);
			 addCommunicationPathMessageFlowThrow_TaskApp.execute(null);
			 
			 EObject pathInternetProcessThrow_Task;
			 Rule pathInternetProcessThrow_TaskRule =addCommunicationPathMessageFlowThrow_TaskUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_TaskApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskRule))
						 {  
							pathInternetProcessThrow_Task= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_Task);
						 }
				}

			
			 }
		/*---------------------------------------------------------------------------------------------------------------------------*/			 
				
		/*-------------------------Internet Communication Paths between the process (Message Flow Throw_Catch)------------------------*/			 
			 Rule addCommunicationPathMessageFlowThrow_CatchUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_Catch");
			 RuleApplication addCommunicationPathMessageFlowThrow_CatchApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_CatchUnit, null);
			 addCommunicationPathMessageFlowThrow_CatchApp.execute(null);
			 
			 EObject pathInternetProcessThrow_Catch;
			 Rule pathInternetProcessThrow_CatchRule =addCommunicationPathMessageFlowThrow_CatchUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_CatchApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchRule))
						 {  
							pathInternetProcessThrow_Catch= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_Catch);
						 }
				}

			
			 }
	  /*---------------------------------------------------------------------------------------------------------------------------*/			 
				
	 /*-------------------------Internet Communication Paths between the process (Message Flow Throw_Task)------------------------*/			 
			 Rule addCommunicationPathMessageFlowThrow_StartUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_Start");
			 RuleApplication addCommunicationPathMessageFlowThrow_StartApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_StartUnit, null);
			 addCommunicationPathMessageFlowThrow_StartApp.execute(null);
			 
			 EObject pathInternetProcessThrow_Start;
			 Rule pathInternetProcessThrow_StartRule =addCommunicationPathMessageFlowThrow_StartUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_StartApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_StartApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_StartApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartRule))
						 {  
							pathInternetProcessThrow_Start= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_Start);
						 }
				}

			
			 }
	   /*---------------------------------------------------------------------------------------------------------------------------*/			 

       /*-------------------------Encrypted Communication Paths between the process (Message Flow Task_Task)------------------------*/			 

			 Rule addCommunicationPathMessageFlowTask_TaskSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_TaskSec");
			 RuleApplication addCommunicationPathMessageFlowTask_TaskSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_TaskSecUnit, null);
			 addCommunicationPathMessageFlowTask_TaskSecApp.execute(null);
			 
			 EObject pathInternetProcessTask_TaskSec;
			 Rule pathInternetProcessTask_TaskSecRule =addCommunicationPathMessageFlowTask_TaskSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_TaskSecRule))
						 {  
							pathInternetProcessTask_TaskSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_TaskSec);
						 }
				}

			
			 }					 
				
	  /*---------------------------------------------------------------------------------------------------------------------------*/			 

	  /*-------------------------Encrypted Communication Paths between the process (Message Flow Task_Start)------------------------*/			 
			
			 Rule addCommunicationPathMessageFlowTask_StartSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_StartSec");
			 RuleApplication addCommunicationPathMessageFlowTask_StartSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_StartSecUnit, null);
			 addCommunicationPathMessageFlowTask_StartSecApp.execute(null);
			 
			 EObject pathInternetProcessTask_StartSec;
			 Rule pathInternetProcessTask_StartSecRule =addCommunicationPathMessageFlowTask_StartSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_StartSecRule))
						 {  
							pathInternetProcessTask_StartSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_StartSec);
						 }
				}

			
			 }
		/*---------------------------------------------------------------------------------------------------------------------------*/			 

		/*-------------------------Encrypted Communication Paths between the process (Message Flow Task_Catch)------------------------*/				 
			 
			 Rule addCommunicationPathMessageFlowTask_CatchSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowTask_CatchSec");
			 RuleApplication addCommunicationPathMessageFlowTask_CatchSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowTask_CatchSecUnit, null);
			 addCommunicationPathMessageFlowTask_CatchSecApp.execute(null);
			 
			 EObject pathInternetProcessTask_CatchSec;
			 Rule pathInternetProcessTask_CatchSecRule =addCommunicationPathMessageFlowTask_CatchSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowTask_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowTask_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowTask_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessTask_CatchSecRule))
						 {  
							pathInternetProcessTask_CatchSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessTask_CatchSec);
						 }
				}

			
			 }
			 
	     /*---------------------------------------------------------------------------------------------------------------------------*/			 

		 /*-------------------------Encrypted Communication Paths between the process (Message Flow End_Start)------------------------*/				 
			 
			 Rule addCommunicationPathMessageFlowEnd_StartSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_StartSec");
			 RuleApplication addCommunicationPathMessageFlowEnd_StartSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_StartSecUnit, null);
			 addCommunicationPathMessageFlowEnd_StartSecApp.execute(null);
			 
			 EObject pathInternetProcessEnd_StartSec;
			 Rule pathInternetProcessEnd_StartSecRule =addCommunicationPathMessageFlowEnd_StartSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_StartSecRule))
						 {  
							pathInternetProcessEnd_StartSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_StartSec);
						 }
				}

			
			 }
		 /*---------------------------------------------------------------------------------------------------------------------------*/			 

		 /*-------------------------Encrypted Communication Paths between the process (Message Flow End_Catch)------------------------*/	 
			 Rule addCommunicationPathMessageFlowEnd_CatchSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_CatchSec");
			 RuleApplication addCommunicationPathMessageFlowEnd_CatchSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_CatchSecUnit, null);
			 addCommunicationPathMessageFlowEnd_CatchSecApp.execute(null);
			 
			 EObject pathInternetProcessEnd_CatchSec;
			 Rule pathInternetProcessEnd_CatchSecRule =addCommunicationPathMessageFlowEnd_CatchSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_CatchSecRule))
						 {  
							pathInternetProcessEnd_CatchSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_CatchSec);
						 }
				}

			
			 }
			 
	    /*---------------------------------------------------------------------------------------------------------------------------*/			 

		/*-------------------------Encrypted Communication Paths between the process (Message Flow End_Task)------------------------*/	 
			 Rule addCommunicationPathMessageFlowEnd_TaskSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowEnd_TaskSec");
			 RuleApplication addCommunicationPathMessageFlowEnd_TaskSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowEnd_TaskSecUnit, null);
			 addCommunicationPathMessageFlowEnd_TaskSecApp.execute(null);
			 
			 EObject pathInternetProcessEnd_TaskSec;
			 Rule pathInternetProcessEnd_TaskSecRule =addCommunicationPathMessageFlowEnd_TaskSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowEnd_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowEnd_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowEnd_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessEnd_TaskSecRule))
						 {  
							pathInternetProcessEnd_TaskSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessEnd_TaskSec);
						 }
				}

			
			 }
		/*---------------------------------------------------------------------------------------------------------------------------*/			 

		/*-------------------------Encrypted Communication Paths between the process (Message Flow Throw_Start)------------------------*/				 
			 Rule addCommunicationPathMessageFlowThrow_StartSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_StartSec");
			 RuleApplication addCommunicationPathMessageFlowThrow_StartSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_StartSecUnit, null);
			 addCommunicationPathMessageFlowThrow_StartSecApp.execute(null);
			 
			 EObject pathInternetProcessThrow_StartSec;
			 Rule pathInternetProcessThrow_StartSecRule =addCommunicationPathMessageFlowThrow_StartSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_StartSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_StartSecRule))
						 {  
							pathInternetProcessThrow_StartSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_StartSec);
						 }
				}

			
			 }
	    /*---------------------------------------------------------------------------------------------------------------------------*/			 

		/*-------------------------Encrypted Communication Paths between the process (Message Flow Throw_Catch)------------------------*/				 
			 Rule addCommunicationPathMessageFlowThrow_CatchSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_CatchSec");
			 RuleApplication addCommunicationPathMessageFlowThrow_CatchSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_CatchSecUnit, null);
			 addCommunicationPathMessageFlowThrow_CatchSecApp.execute(null);
			 
			 EObject pathInternetProcessThrow_CatchSec;
			 Rule pathInternetProcessThrow_CatchSecRule =addCommunicationPathMessageFlowThrow_CatchSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_CatchSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_CatchSecRule))
						 {  
							pathInternetProcessThrow_CatchSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_CatchSec);
						 }
				}

			
			 }
			 
	   /*---------------------------------------------------------------------------------------------------------------------------*/			 

	   /*-------------------------Encrypted Communication Paths between the process (Message Flow Throw_Task)------------------------*/				 
			 Rule addCommunicationPathMessageFlowThrow_TaskSecUnit = (Rule)module_SecureLinks2.getUnit("addCommunicationPathMessageFlowThrow_TaskSec");
			 RuleApplication addCommunicationPathMessageFlowThrow_TaskSecApp = new RuleApplicationImpl(engine, graph,
					 addCommunicationPathMessageFlowThrow_TaskSecUnit, null);
			 addCommunicationPathMessageFlowThrow_TaskSecApp.execute(null);
			 
			 EObject pathInternetProcessThrow_TaskSec;
			 Rule pathInternetProcessThrow_TaskSecRule =addCommunicationPathMessageFlowThrow_TaskSecUnit.getMultiRules().get(0);
			 
			 if(!addCommunicationPathMessageFlowThrow_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskSecRule).isEmpty())
			 {
				 
					if (!addCommunicationPathMessageFlowThrow_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskSecRule).isEmpty()) {
						for (Match firstRuleMultiMatch:addCommunicationPathMessageFlowThrow_TaskSecApp.getResultMatch().getMultiMatches(pathInternetProcessThrow_TaskSecRule))
						 {  
							pathInternetProcessThrow_TaskSec= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathInternetProcessThrow_TaskSec);
						 }
				}

			
			 }
			 
			 
			 
	 /*---------------------------------------------------------------------------------------------------------------------------*/	
			 
			 
    //***************SECURE LINKS GROUP: (F) Edit COMMUNICATION PATHS Types (Encrypted Message Flow exists)******************/
	// *************************************************************************************************************************/		
			 
    /*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Source Task)-------------*/				 
			 Rule editPathTypeLaneSourceTaskUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneSourceTask");
			 RuleApplication editPathTypeLaneSourceTaskApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneSourceTaskUnit, null);
			 editPathTypeLaneSourceTaskApp.execute(null);
			 
			 EObject pathEncrytedLaneSourceTask;
			 Rule encrytedPathLaneSourceTaskRule =editPathTypeLaneSourceTaskUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceTaskRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceTaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceTaskRule))
						 {  
							pathEncrytedLaneSourceTask= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneSourceTask);
						 }
				}

			
			 }	
     /*---------------------------------------------------------------------------------------------------------------------------*/			

	 /*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Source End)-------------*/				 
		 
			 Rule editPathTypeLaneSourceEndUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneSourceEnd");
			 RuleApplication editPathTypeLaneSourceEndApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneSourceEndUnit, null);
			 editPathTypeLaneSourceEndApp.execute(null);
			 
			 EObject pathEncrytedLaneSourceEnd;
			 Rule encrytedPathLaneSourceEndRule =editPathTypeLaneSourceEndUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneSourceEndApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceEndRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneSourceEndApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceEndRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneSourceEndApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceEndRule))
						 {  
							pathEncrytedLaneSourceEnd= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneSourceEnd);
						 }
				}

			
			 }	
			 
	  /*---------------------------------------------------------------------------------------------------------------------------*/			

	 /*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Source Throw)-------------*/				 
			 
			 Rule editPathTypeLaneSourceThrowUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneSourceThrow");
			 RuleApplication editPathTypeLaneSourceThrowApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneSourceThrowUnit, null);
			 editPathTypeLaneSourceThrowApp.execute(null);
			 
			 EObject pathEncrytedLaneSourceThrow;
			 Rule encrytedPathLaneSourceThrowRule =editPathTypeLaneSourceThrowUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceThrowRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceThrowRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathLaneSourceThrowRule))
						 {  
							pathEncrytedLaneSourceThrow= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneSourceThrow);
						 }
				}

			
			 }	
	/*---------------------------------------------------------------------------------------------------------------------------*/			
	
	/*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Target Task)-------------*/				 
			 
			 Rule editPathTypeLaneTargetTaskUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneTargetTask");
			 RuleApplication editPathTypeLaneTargetTaskApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneTargetTaskUnit, null);
			 editPathTypeLaneTargetTaskApp.execute(null);
			 
			 EObject pathEncrytedLaneTargetTask;
			 Rule encrytedPathLaneTargetTaskRule =editPathTypeLaneTargetTaskUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetTaskRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetTaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetTaskRule))
						 {  
							pathEncrytedLaneTargetTask= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneTargetTask);
						 }
				}

			
			 }	
	/*---------------------------------------------------------------------------------------------------------------------------*/			

	/*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Target  Start)-------------*/				 
			 Rule editPathTypeLaneTargetStartUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneTargetStart");
			 RuleApplication editPathTypeLaneTargetStartApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneTargetStartUnit, null);
			 editPathTypeLaneTargetStartApp.execute(null);
			 
			 EObject pathEncrytedLaneTargetStart;
			 Rule encrytedPathLaneTargetStartRule =editPathTypeLaneTargetStartUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneTargetStartApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetStartRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneTargetStartApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetStartRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneTargetStartApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetStartRule))
						 {  
							pathEncrytedLaneTargetStart= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneTargetStart);
						 }
				}

			
			 }	
	/*---------------------------------------------------------------------------------------------------------------------------*/			

	/*-------------------------Edit Communication Paths between the lane its associated  system (Message Flow Target Catch)-------------*/				 
			 Rule editPathTypeLaneTargetCatchUnit = (Rule)module_SecureLinks2.getUnit("editPathTypeLaneTargetCatch");
			 RuleApplication editPathTypeLaneTargetCatchApp = new RuleApplicationImpl(engine, graph,
					 editPathTypeLaneTargetCatchUnit, null);
			 editPathTypeLaneTargetCatchApp.execute(null);
			 
			 EObject pathEncrytedLaneTargetCatch;
			 Rule encrytedPathLaneTargetCatchRule =editPathTypeLaneTargetCatchUnit.getMultiRules().get(0);
			 
			 if(!editPathTypeLaneTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetCatchRule).isEmpty())
			 {
				 
					if (!editPathTypeLaneTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetCatchRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypeLaneTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathLaneTargetCatchRule))
						 {  
							pathEncrytedLaneTargetCatch= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedLaneTargetCatch);
						 }
				}

			
			 }	
	 /*---------------------------------------------------------------------------------------------------------------------------*/			

	/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source Task)-------------*/				 

			 Rule editPathTypePartSourceTaskUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartSourceTask");
			 RuleApplication editPathTypePartSourceTaskApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartSourceTaskUnit, null);
			 editPathTypePartSourceTaskApp.execute(null);
			 
			 EObject pathEncrytedPartSourceTask;
			 Rule encrytedPathPartSourceTaskRule =editPathTypePartSourceTaskUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathPartSourceTaskRule).isEmpty())
			 {
				 
					if (!editPathTypePartSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathPartSourceTaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartSourceTaskApp.getResultMatch().getMultiMatches(encrytedPathPartSourceTaskRule))
						 {  
							pathEncrytedPartSourceTask= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartSourceTask);
						 }
				}

			
			 }	
	/*---------------------------------------------------------------------------------------------------------------------------*/			

	/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source End)-------------*/			 
			 
			 Rule editPathTypePartSourceEndUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartSourceEnd");
			 RuleApplication editPathTypePartSourceEndApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartSourceEndUnit, null);
			 editPathTypePartSourceEndApp.execute(null);
			 
			 EObject pathEncrytedPartSourceEnd;
			 Rule encrytedPathPartSourceEndRule =editPathTypePartSourceEndUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartSourceEndApp.getResultMatch().getMultiMatches(encrytedPathPartSourceEndRule).isEmpty())
			 {
				 
					if (!editPathTypePartSourceEndApp.getResultMatch().getMultiMatches(encrytedPathPartSourceEndRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartSourceEndApp.getResultMatch().getMultiMatches(encrytedPathPartSourceEndRule))
						 {  
							pathEncrytedPartSourceEnd= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartSourceEnd);
						 }
				}

			
			 }
		/*---------------------------------------------------------------------------------------------------------------------------*/			

		/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source Throw)-------------*/			 
			 Rule editPathTypePartSourceThrowUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartSourceThrow");
			 RuleApplication editPathTypePartSourceThrowApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartSourceThrowUnit, null);
			 editPathTypePartSourceThrowApp.execute(null);
			 
			 EObject pathEncrytedPartSourceThrow;
			 Rule encrytedPathPartSourceThrowRule =editPathTypePartSourceThrowUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathPartSourceThrowRule).isEmpty())
			 {
				 
					if (!editPathTypePartSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathPartSourceThrowRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartSourceThrowApp.getResultMatch().getMultiMatches(encrytedPathPartSourceThrowRule))
						 {  
							pathEncrytedPartSourceThrow= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartSourceThrow);
						 }
				}

			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/			
			 
	/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source Task)-------------*/			 
			 
			 Rule editPathTypePartTargetTaskUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartTargetTask");
			 RuleApplication editPathTypePartTargetTaskApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartTargetTaskUnit, null);
			 editPathTypePartTargetTaskApp.execute(null);
			 
			 EObject pathEncrytedPartTargetTask;
			 Rule encrytedPathPartTargetTaskRule =editPathTypePartTargetTaskUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathPartTargetTaskRule).isEmpty())
			 {
				 
					if (!editPathTypePartTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathPartTargetTaskRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartTargetTaskApp.getResultMatch().getMultiMatches(encrytedPathPartTargetTaskRule))
						 {  
							pathEncrytedPartTargetTask= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartTargetTask);
						 }
				}

			
			 }
	 /*---------------------------------------------------------------------------------------------------------------------------*/			
			 
	/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source Start)-------------*/					 
			 Rule editPathTypePartTargetStartUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartTargetStart");
			 RuleApplication editPathTypePartTargetStartApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartTargetStartUnit, null);
			 editPathTypePartTargetStartApp.execute(null);
			 
			 EObject pathEncrytedPartTargetStart;
			 Rule encrytedPathPartTargetStartRule =editPathTypePartTargetStartUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartTargetStartApp.getResultMatch().getMultiMatches(encrytedPathPartTargetStartRule).isEmpty())
			 {
				 
					if (!editPathTypePartTargetStartApp.getResultMatch().getMultiMatches(encrytedPathPartTargetStartRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartTargetStartApp.getResultMatch().getMultiMatches(encrytedPathPartTargetStartRule))
						 {  
							pathEncrytedPartTargetStart= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartTargetStart);
						 }
				}

			
			 }
		/*---------------------------------------------------------------------------------------------------------------------------*/			
			 
		/*-------------------------Edit Communication Paths between the Participant its associated  system (Message Flow Source Catch)-------------*/					 
			 Rule editPathTypePartTargetCatchUnit = (Rule)module_SecureLinks2.getUnit("editPathTypePartTargetCatch");
			 RuleApplication editPathTypePartTargetCatchApp = new RuleApplicationImpl(engine, graph,
					 editPathTypePartTargetCatchUnit, null);
			 editPathTypePartTargetCatchApp.execute(null);
			 
			 EObject pathEncrytedPartTargetCatch;
			 Rule encrytedPathPartTargetCatchRule =editPathTypePartTargetCatchUnit.getMultiRules().get(0);
			 
			 if(!editPathTypePartTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathPartTargetCatchRule).isEmpty())
			 {
				 
					if (!editPathTypePartTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathPartTargetCatchRule).isEmpty()) {
						for (Match firstRuleMultiMatch:editPathTypePartTargetCatchApp.getResultMatch().getMultiMatches(encrytedPathPartTargetCatchRule))
						 {  
							pathEncrytedPartTargetCatch= (EObject)firstRuleMultiMatch.getParameterValues().get(0);	
							   
						     addToResource(pathEncrytedPartTargetCatch);
						 }
				}

			
			 }
	/*---------------------------------------------------------------------------------------------------------------------------*/		

		//***************SECURE LINKS GROUP: (E) Add dependencies between artifacts (Case Data object and object references)******************/
	    // ***********************************************************************************************************************************/

			 
			 
	     /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Task_Out)-------------*/					 	 
			 Rule addDependencyPartTaskOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartTaskOut");
			 RuleApplication addDependencyPartTaskOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartTaskOutUnit, null);
			 addDependencyPartTaskOutApp.execute(null);
			 
			 EObject depPartTaskOut;
			 Rule depPartTaskOutRule =addDependencyPartTaskOutUnit.getMultiRules().get(0);
			 Rule operationsDepPartTaskOut = depPartTaskOutRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartTaskOutApp.getResultMatch().getMultiMatches(depPartTaskOutRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartTaskOutApp.getResultMatch().getMultiMatches(depPartTaskOutRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartTaskOut))
			 			{
						  depPartTaskOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartTaskOut);
			 			}
				 }
			
			 }
	   /*---------------------------------------------------------------------------------------------------------------------------*/		
	   
	   /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Start_Out)-------------*/					 
			 
			 Rule addDependencyPartStartOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartStartOut");
			 RuleApplication addDependencyPartStartOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartStartOutUnit, null);
			 addDependencyPartStartOutApp.execute(null);
			 
			 EObject depPartStartOut;
			 Rule depPartStartOutRule =addDependencyPartStartOutUnit.getMultiRules().get(0);
			 Rule operationsDepPartStartOut = depPartStartOutRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartStartOutApp.getResultMatch().getMultiMatches(depPartStartOutRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartStartOutApp.getResultMatch().getMultiMatches(depPartStartOutRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartStartOut))
			 			{
						  depPartStartOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartStartOut);
			 			}
				 }
			
			 }
      /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Catch_Out)-------------*/			 
			 Rule addDependencyPartCatchOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartCatchOut");
			 RuleApplication addDependencyPartCatchOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartCatchOutUnit, null);
			 addDependencyPartCatchOutApp.execute(null);
			 
			 EObject depPartCatchOut;
			 Rule depPartCatchOutRule =addDependencyPartCatchOutUnit.getMultiRules().get(0);
			 Rule operationsDepPartCatchOut = depPartCatchOutRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartCatchOutApp.getResultMatch().getMultiMatches(depPartCatchOutRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartCatchOutApp.getResultMatch().getMultiMatches(depPartCatchOutRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartCatchOut))
			 			{
						  depPartCatchOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartCatchOut);
			 			}
				 }
			
			 }
	 /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Task_Input)-------------*/			 
			 Rule addDependencyPartTaskInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartTaskInput");
			 RuleApplication addDependencyPartTaskInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartTaskInputUnit, null);
			 addDependencyPartTaskInputApp.execute(null);
			 
			 EObject depPartTaskInput;
			 Rule depPartTaskInputRule =addDependencyPartTaskInputUnit.getMultiRules().get(0);
			 Rule operationsDepPartTaskInput = depPartTaskInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartTaskInputApp.getResultMatch().getMultiMatches(depPartTaskInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartTaskInputApp.getResultMatch().getMultiMatches(depPartTaskInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartTaskInput))
			 			{
						  depPartTaskInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartTaskInput);
			 			}
				 }
			
			 }
			 
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between participant GUI artifact and  data object artifact (End_Input)-------------*/		 
			 Rule addDependencyPartEndInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartEndInput");
			 RuleApplication addDependencyPartEndInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartEndInputUnit, null);
			 addDependencyPartEndInputApp.execute(null);
			 
			 EObject depPartEndInput;
			 Rule depPartEndInputRule =addDependencyPartEndInputUnit.getMultiRules().get(0);
			 Rule operationsDepPartEndInput = depPartEndInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartEndInputApp.getResultMatch().getMultiMatches(depPartEndInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartEndInputApp.getResultMatch().getMultiMatches(depPartEndInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartEndInput))
			 			{
						  depPartEndInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartEndInput);
			 			}
				 }
			
			 }
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Throw_Input)-------------*/			 
			 Rule addDependencyPartThrowInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartThrowInput");
			 RuleApplication addDependencyPartThrowInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyPartThrowInputUnit, null);
			 addDependencyPartThrowInputApp.execute(null);
			 
			 EObject depPartThrowInput;
			 Rule depPartThrowInputRule =addDependencyPartThrowInputUnit.getMultiRules().get(0);
			 Rule operationsDepPartThrowInput = depPartThrowInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyPartThrowInputApp.getResultMatch().getMultiMatches(depPartThrowInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyPartThrowInputApp.getResultMatch().getMultiMatches(depPartThrowInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartThrowInput))
			 			{
						  depPartThrowInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depPartThrowInput);
			 			}
				 }
			
			 }
			 
	   /*---------------------------------------------------------------------------------------------------------------------------*/		
	   
	   /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Task_OutRef)-------------*/					 	 
				 Rule addDependencyPartTaskOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartTaskOutRef");
				 RuleApplication addDependencyPartTaskOutRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartTaskOutRefUnit, null);
				 addDependencyPartTaskOutRefApp.execute(null);
				 
				 EObject depPartTaskOutRef;
				 Rule depPartTaskOutRefRule =addDependencyPartTaskOutRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartTaskOutRef = depPartTaskOutRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartTaskOutRefApp.getResultMatch().getMultiMatches(depPartTaskOutRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartTaskOutRefApp.getResultMatch().getMultiMatches(depPartTaskOutRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartTaskOutRef))
				 			{
							  depPartTaskOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartTaskOutRef);
				 			}
					 }
				
				 }
		   /*---------------------------------------------------------------------------------------------------------------------------*/		
		   
		   /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Start_OutRef)-------------*/					 
				 
				 Rule addDependencyPartStartOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartStartOutRef");
				 RuleApplication addDependencyPartStartOutRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartStartOutRefUnit, null);
				 addDependencyPartStartOutRefApp.execute(null);
				 
				 EObject depPartStartOutRef;
				 Rule depPartStartOutRefRule =addDependencyPartStartOutRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartStartOutRef = depPartStartOutRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartStartOutRefApp.getResultMatch().getMultiMatches(depPartStartOutRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartStartOutRefApp.getResultMatch().getMultiMatches(depPartStartOutRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartStartOutRef))
				 			{
							  depPartStartOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartStartOutRef);
				 			}
					 }
				
				 }
	      /*---------------------------------------------------------------------------------------------------------------------------*/		
				   
		 /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Catct_OutRef)-------------*/			 
				 Rule addDependencyPartCatchOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartCatchOutRef");
				 RuleApplication addDependencyPartCatchOutRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartCatchOutRefUnit, null);
				 addDependencyPartCatchOutRefApp.execute(null);
				 
				 EObject depPartCatchOutRef;
				 Rule depPartCatchOutRefRule =addDependencyPartCatchOutRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartCatchOutRef = depPartCatchOutRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartCatchOutRefApp.getResultMatch().getMultiMatches(depPartCatchOutRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartCatchOutRefApp.getResultMatch().getMultiMatches(depPartCatchOutRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartCatchOutRef))
				 			{
							  depPartCatchOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartCatchOutRef);
				 			}
					 }
				
				 }
		 /*---------------------------------------------------------------------------------------------------------------------------*/		
				   
		 /*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Task_InputRef)-------------*/			 
				 Rule addDependencyPartTaskInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartTaskInputRef");
				 RuleApplication addDependencyPartTaskInputRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartTaskInputRefUnit, null);
				 addDependencyPartTaskInputRefApp.execute(null);
				 
				 EObject depPartTaskInputRef;
				 Rule depPartTaskInputRefRule =addDependencyPartTaskInputRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartTaskInputRef = depPartTaskInputRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartTaskInputRefApp.getResultMatch().getMultiMatches(depPartTaskInputRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartTaskInputRefApp.getResultMatch().getMultiMatches(depPartTaskInputRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartTaskInputRef))
				 			{
							  depPartTaskInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartTaskInputRef);
				 			}
					 }
				
				 }
				 
		/*---------------------------------------------------------------------------------------------------------------------------*/		
				   
		/*-------------------------Add a dependency between participant GUI artifact and  data object artifact (End_InputRef)-------------*/		 
				 Rule addDependencyPartEndInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartEndInputRef");
				 RuleApplication addDependencyPartEndInputRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartEndInputRefUnit, null);
				 addDependencyPartEndInputRefApp.execute(null);
				 
				 EObject depPartEndInputRef;
				 Rule depPartEndInputRefRule =addDependencyPartEndInputRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartEndRefInput = depPartEndInputRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartEndInputRefApp.getResultMatch().getMultiMatches(depPartEndInputRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartEndInputRefApp.getResultMatch().getMultiMatches(depPartEndInputRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartEndRefInput))
				 			{
							  depPartEndInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartEndInputRef);
				 			}
					 }
				
				 }
		/*---------------------------------------------------------------------------------------------------------------------------*/		
				   
		/*-------------------------Add a dependency between participant GUI artifact and  data object artifact (Throw_InputRef)-------------*/			 
				 Rule addDependencyPartThrowInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyPartThrowInputRef");
				 RuleApplication addDependencyPartThrowInputRefApp = new RuleApplicationImpl(engine, graph,
						 addDependencyPartThrowInputRefUnit, null);
				 addDependencyPartThrowInputRefApp.execute(null);
				 
				 EObject depPartThrowInputRef;
				 Rule depPartThrowInputRefRule =addDependencyPartThrowInputRefUnit.getMultiRules().get(0);
				 Rule operationsDepPartThrowInputRef = depPartThrowInputRefRule.getMultiRules().get(0);

				 
				 if(!addDependencyPartThrowInputRefApp.getResultMatch().getMultiMatches(depPartThrowInputRefRule).isEmpty())
				 {
					 for (Match firstRuleMultiMatch:addDependencyPartThrowInputRefApp.getResultMatch().getMultiMatches(depPartThrowInputRefRule))
					 {  
						  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepPartThrowInputRef))
				 			{
							  depPartThrowInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
					   
				 				addToResource(depPartThrowInputRef);
				 			}
					 }
				
				 }
				 
	   /*---------------------------------------------------------------------------------------------------------------------------*/		
				 
	   /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Task_Out)-------------*/					 
				
			 Rule addDependencyLaneTaskOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneTaskOut");
			 RuleApplication addDependencyLaneTaskOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneTaskOutUnit, null);
			 addDependencyLaneTaskOutApp.execute(null);

			 EObject depLaneTaskOut;
			 Rule depLaneTaskOutRule =addDependencyLaneTaskOutUnit.getMultiRules().get(0);
			 Rule operationsDepLaneTaskOut = depLaneTaskOutRule.getMultiRules().get(0);

			 if(!addDependencyLaneTaskOutApp.getResultMatch().getMultiMatches(depLaneTaskOutRule).isEmpty())
			 {

				 for (Match firstRuleMultiMatch:addDependencyLaneTaskOutApp.getResultMatch().getMultiMatches(depLaneTaskOutRule))
				 {  

					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneTaskOut))
			 			{

						  depLaneTaskOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	

			 				addToResource(depLaneTaskOut);

			 			}
				 }
			
			 }
			 
	 /*---------------------------------------------------------------------------------------------------------------------------*/	
			 
     /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Start_Out)-------------*/					 

			 Rule addDependencyLaneStartOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneStartOut");
			 RuleApplication addDependencyLaneStartOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneStartOutUnit, null);
			 addDependencyLaneStartOutApp.execute(null);
			 
			 EObject depLaneStartOut;
			 Rule depLaneStartOutRule =addDependencyLaneStartOutUnit.getMultiRules().get(0);
			 Rule operationsDepLaneStartOut = depLaneStartOutRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneStartOutApp.getResultMatch().getMultiMatches(depLaneStartOutRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneStartOutApp.getResultMatch().getMultiMatches(depLaneStartOutRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneStartOut))
			 			{
						  depLaneStartOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneStartOut);
			 			}
				 }
			
			 }
      /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Catch_Out)-------------*/			 
			 Rule addDependencyLaneCatchOutUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneCatchOut");
			 RuleApplication addDependencyLaneCatchOutApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneCatchOutUnit, null);
			 addDependencyLaneCatchOutApp.execute(null);
			 
			 EObject depLaneCatchOut;
			 Rule depLaneCatchOutRule =addDependencyLaneCatchOutUnit.getMultiRules().get(0);
			 Rule operationsDepLaneCatchOut = depLaneCatchOutRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneCatchOutApp.getResultMatch().getMultiMatches(depLaneCatchOutRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneCatchOutApp.getResultMatch().getMultiMatches(depLaneCatchOutRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneCatchOut))
			 			{
						  depLaneCatchOut= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneCatchOut);
			 			}
				 }
			
			 }
	 /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Task_Input)-------------*/			 
			 Rule addDependencyLaneTaskInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneTaskInput");
			 RuleApplication addDependencyLaneTaskInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneTaskInputUnit, null);
			 addDependencyLaneTaskInputApp.execute(null);
			 
			 EObject depLaneTaskInput;
			 Rule depLaneTaskInputRule =addDependencyLaneTaskInputUnit.getMultiRules().get(0);
			 Rule operationsDepLaneTaskInput = depLaneTaskInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneTaskInputApp.getResultMatch().getMultiMatches(depLaneTaskInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneTaskInputApp.getResultMatch().getMultiMatches(depLaneTaskInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneTaskInput))
			 			{
						  depLaneTaskInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneTaskInput);
			 			}
				 }
			
			 }
			 
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (End_Input)-------------*/		 
			 Rule addDependencyLaneEndInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneEndInput");
			 RuleApplication addDependencyLaneEndInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneEndInputUnit, null);
			 addDependencyLaneEndInputApp.execute(null);
			 
			 EObject depLaneEndInput;
			 Rule depLaneEndInputRule =addDependencyLaneEndInputUnit.getMultiRules().get(0);
			 Rule operationsDepLaneEndInput = depLaneEndInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneEndInputApp.getResultMatch().getMultiMatches(depLaneEndInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneEndInputApp.getResultMatch().getMultiMatches(depLaneEndInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneEndInput))
			 			{
						  depLaneEndInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneEndInput);
			 			}
				 }
			
			 }
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between Lane  GUI artifact and  data object artifact (Throw_Input)-------------*/			 
			 Rule addDependencyLaneThrowInputUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneThrowInput");
			 RuleApplication addDependencyLaneThrowInputApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneThrowInputUnit, null);
			 addDependencyLaneThrowInputApp.execute(null);
			 
			 EObject depLaneThrowInput;
			 Rule depLaneThrowInputRule =addDependencyLaneThrowInputUnit.getMultiRules().get(0);
			 Rule operationsDepLaneThrowInput = depLaneThrowInputRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneThrowInputApp.getResultMatch().getMultiMatches(depLaneThrowInputRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneThrowInputApp.getResultMatch().getMultiMatches(depLaneThrowInputRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneThrowInput))
			 			{
						  depLaneThrowInput= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneThrowInput);
			 			}
				 }
			
			 }
			 
	   /*---------------------------------------------------------------------------------------------------------------------------*/	 
			 
			 
		/*-------------------------Add a dependency between Lane  GUI artifact and  data object artifact (Task_OutRef)-------------*/			 
			 
			 Rule addDependencyLaneTaskOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneTaskOutRef");
			 RuleApplication addDependencyLaneTaskOutRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneTaskOutRefUnit, null);
			 addDependencyLaneTaskOutRefApp.execute(null);

			 EObject depLaneTaskOutRef;
			 Rule depLaneTaskOutRefRule =addDependencyLaneTaskOutRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneTaskOutRef = depLaneTaskOutRefRule.getMultiRules().get(0);

			 if(!addDependencyLaneTaskOutRefApp.getResultMatch().getMultiMatches(depLaneTaskOutRefRule).isEmpty())
			 {

				 for (Match firstRuleMultiMatch:addDependencyLaneTaskOutRefApp.getResultMatch().getMultiMatches(depLaneTaskOutRefRule))
				 {  

					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneTaskOutRef))
			 			{

						  depLaneTaskOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	

			 				addToResource(depLaneTaskOutRef);

			 			}
				 }
			
			 }
	   /*---------------------------------------------------------------------------------------------------------------------------*/
			 
	  /*-------------------------Add a dependency between Lane  GUI artifact and  data object artifact (Task_startRef)-------------*/			 

			 Rule addDependencyLaneStartOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneStartOutRef");
			 RuleApplication addDependencyLaneStartOutRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneStartOutRefUnit, null);
			 addDependencyLaneStartOutRefApp.execute(null);
			 
			 EObject depLaneStartOutRef;
			 Rule depLaneStartOutRefRule =addDependencyLaneStartOutRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneStartOutRef = depLaneStartOutRefRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneStartOutRefApp.getResultMatch().getMultiMatches(depLaneStartOutRefRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneStartOutRefApp.getResultMatch().getMultiMatches(depLaneStartOutRefRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneStartOutRef))
			 			{
						  depLaneStartOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneStartOutRef);
			 			}
				 }
			
			 }
      /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Catct_OutRef)-------------*/			 
			 Rule addDependencyLaneCatchOutRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneCatchOutRef");
			 RuleApplication addDependencyLaneCatchOutRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneCatchOutRefUnit, null);
			 addDependencyLaneCatchOutRefApp.execute(null);
			 
			 EObject depLaneCatchOutRef;
			 Rule depLaneCatchOutRefRule =addDependencyLaneCatchOutRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneCatchOutRef = depLaneCatchOutRefRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneCatchOutRefApp.getResultMatch().getMultiMatches(depLaneCatchOutRefRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneCatchOutRefApp.getResultMatch().getMultiMatches(depLaneCatchOutRefRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneCatchOutRef))
			 			{
						  depLaneCatchOutRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneCatchOutRef);
			 			}
				 }
			
			 }
	 /*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	 /*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Task_InputRef)-------------*/			 
			 Rule addDependencyLaneTaskInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneTaskInputRef");
			 RuleApplication addDependencyLaneTaskInputRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneTaskInputRefUnit, null);
			 addDependencyLaneTaskInputRefApp.execute(null);
			 
			 EObject depLaneTaskInputRef;
			 Rule depLaneTaskInputRefRule =addDependencyLaneTaskInputRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneTaskInputRef = depLaneTaskInputRefRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneTaskInputRefApp.getResultMatch().getMultiMatches(depLaneTaskInputRefRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneTaskInputRefApp.getResultMatch().getMultiMatches(depLaneTaskInputRefRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneTaskInputRef))
			 			{
						  depLaneTaskInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneTaskInputRef);
			 			}
				 }
			
			 }
			 
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (End_InputRef)-------------*/		 
			 Rule addDependencyLaneEndInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneEndInputRef");
			 RuleApplication addDependencyLaneEndInputRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneEndInputRefUnit, null);
			 addDependencyLaneEndInputRefApp.execute(null);
			 
			 EObject depLaneEndInputRef;
			 Rule depLaneEndInputRefRule =addDependencyLaneEndInputRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneEndRefInput = depLaneEndInputRefRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneEndInputRefApp.getResultMatch().getMultiMatches(depLaneEndInputRefRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneEndInputRefApp.getResultMatch().getMultiMatches(depLaneEndInputRefRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneEndRefInput))
			 			{
						  depLaneEndInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneEndInputRef);
			 			}
				 }
			
			 }
	/*---------------------------------------------------------------------------------------------------------------------------*/		
			   
	/*-------------------------Add a dependency between Lane GUI artifact and  data object artifact (Throw_InputRef)-------------*/			 
			 Rule addDependencyLaneThrowInputRefUnit = (Rule)module_SecureLinks3.getUnit("addDependencyLaneThrowInputRef");
			 RuleApplication addDependencyLaneThrowInputRefApp = new RuleApplicationImpl(engine, graph,
					 addDependencyLaneThrowInputRefUnit, null);
			 addDependencyLaneThrowInputRefApp.execute(null);
			 
			 EObject depLaneThrowInputRef;
			 Rule depLaneThrowInputRefRule =addDependencyLaneThrowInputRefUnit.getMultiRules().get(0);
			 Rule operationsDepLaneThrowInputRef = depLaneThrowInputRefRule.getMultiRules().get(0);

			 
			 if(!addDependencyLaneThrowInputRefApp.getResultMatch().getMultiMatches(depLaneThrowInputRefRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyLaneThrowInputRefApp.getResultMatch().getMultiMatches(depLaneThrowInputRefRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsDepLaneThrowInputRef))
			 			{
						  depLaneThrowInputRef= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depLaneThrowInputRef);
			 			}
				 }
			
			 }
			 
     /*---------------------------------------------------------------------------------------------------------------------------*/
	
			 
	//***************SECURE LINKS GROUP 4: (A) Add dependencies between artifacts of two communicated processes nodes (Case Message Flow)******************/
	// ***********************************************************************************************************************************/		 
			 
			 
			 /*-------------------------Add a dependency between Nodes (case Message flow between Task and Start)-------------*/			 
			 Rule addDependencyMessageFlowTaskStartUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowTaskStart");
			 RuleApplication addDependencyMessageFlowTaskStartApp = new RuleApplicationImpl(engine, graph,
					 addDependencyMessageFlowTaskStartUnit, null);
			 addDependencyMessageFlowTaskStartApp.execute(null);
			 
			 EObject depTaskStart;
			 Rule depTaskStartRule =addDependencyMessageFlowTaskStartUnit.getMultiRules().get(0);
			 Rule depTaskStartOperations = depTaskStartRule.getMultiRules().get(0);

			 
			 if(!addDependencyMessageFlowTaskStartApp.getResultMatch().getMultiMatches(depTaskStartRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDependencyMessageFlowTaskStartApp.getResultMatch().getMultiMatches(depTaskStartRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depTaskStartOperations))
			 			{
						  depTaskStart= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depTaskStart);
			 			}
				 }
			
			 }
			 
			 
			 
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between Task and Task)-------------------------*/			 
			 Rule addDepClientSubTaskTaskArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowTaskTask");
			 RuleApplication addDepClientSubTaskTaskArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubTaskTaskArtUnit, null);
			 addDepClientSubTaskTaskArtUnitApp.execute(null);
			 
			 EObject depTaskTaskArt;
			 Rule depTaskTaskArtRule =addDepClientSubTaskTaskArtUnit.getMultiRules().get(0);
			 Rule depTaskTaskArtOperations = depTaskTaskArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubTaskTaskArtUnitApp.getResultMatch().getMultiMatches(depTaskTaskArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubTaskTaskArtUnitApp.getResultMatch().getMultiMatches(depTaskTaskArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depTaskTaskArtOperations))
			 			{
						  depTaskTaskArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depTaskTaskArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between Task and Catch)-------------------------*/			 
			 Rule addDepClientSubTaskCatchArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowTaskCatch");
			 RuleApplication addDepClientSubTaskCatchArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubTaskCatchArtUnit, null);
			 addDepClientSubTaskCatchArtUnitApp.execute(null);
			 
			 EObject depTaskCatchArt;
			 Rule depTaskCatchArtRule =addDepClientSubTaskCatchArtUnit.getMultiRules().get(0);
			 Rule depTaskCatchArtOperations = depTaskCatchArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubTaskCatchArtUnitApp.getResultMatch().getMultiMatches(depTaskCatchArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubTaskCatchArtUnitApp.getResultMatch().getMultiMatches(depTaskCatchArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depTaskCatchArtOperations))
			 			{
						  depTaskCatchArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depTaskCatchArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between End and Start)-------------------------*/			 
			 Rule addDepClientSubEndStartArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowEndStart");
			 RuleApplication addDepClientSubEndStartArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubEndStartArtUnit, null);
			 addDepClientSubEndStartArtUnitApp.execute(null);
			 
			 EObject depEndStartArt;
			 Rule depEndStartArtRule =addDepClientSubEndStartArtUnit.getMultiRules().get(0);
			 Rule depEndStartArtOperations = depEndStartArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubEndStartArtUnitApp.getResultMatch().getMultiMatches(depEndStartArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubEndStartArtUnitApp.getResultMatch().getMultiMatches(depEndStartArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depEndStartArtOperations))
			 			{
						  depEndStartArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depEndStartArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between End and Task)-------------------------*/			 
			 Rule addDepClientSubEndTaskArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowEndTask");
			 RuleApplication addDepClientSubEndTaskArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubEndTaskArtUnit, null);
			 addDepClientSubEndTaskArtUnitApp.execute(null);
			 
			 EObject depEndTaskArt;
			 Rule depEndTaskArtRule =addDepClientSubEndTaskArtUnit.getMultiRules().get(0);
			 Rule depEndTaskArtOperations = depEndTaskArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubEndTaskArtUnitApp.getResultMatch().getMultiMatches(depEndTaskArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubEndTaskArtUnitApp.getResultMatch().getMultiMatches(depEndTaskArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depEndTaskArtOperations))
			 			{
						  depEndTaskArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depEndTaskArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between End and Catch)-------------------------*/			 
			 Rule addDepClientSubEndCatchArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowEndCatch");
			 RuleApplication addDepClientSubEndCatchArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubEndCatchArtUnit, null);
			 addDepClientSubEndCatchArtUnitApp.execute(null);
			 
			 EObject depEndCatchArt;
			 Rule depEndCatchArtRule =addDepClientSubEndCatchArtUnit.getMultiRules().get(0);
			 Rule depEndCatchArtOperations = depEndCatchArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubEndCatchArtUnitApp.getResultMatch().getMultiMatches(depEndCatchArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubEndCatchArtUnitApp.getResultMatch().getMultiMatches(depEndCatchArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depEndCatchArtOperations))
			 			{
						  depEndCatchArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depEndCatchArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between Throw and Start)-------------------------*/			 
			 Rule addDepClientSubThrowStartArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowThrowStart");
			 RuleApplication addDepClientSubThrowStartArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubThrowStartArtUnit, null);
			 addDepClientSubThrowStartArtUnitApp.execute(null);
			 
			 EObject depThrowStartArt;
			 Rule depThrowStartArtRule =addDepClientSubThrowStartArtUnit.getMultiRules().get(0);
			 Rule depThrowStartArtOperations = depThrowStartArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubThrowStartArtUnitApp.getResultMatch().getMultiMatches(depThrowStartArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubThrowStartArtUnitApp.getResultMatch().getMultiMatches(depThrowStartArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depThrowStartArtOperations))
			 			{
						  depThrowStartArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depThrowStartArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between Throw and Task)-------------------------*/			 
			 Rule addDepClientSubThrowTaskArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowThrowTask");
			 RuleApplication addDepClientSubThrowTaskArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubThrowTaskArtUnit, null);
			 addDepClientSubThrowTaskArtUnitApp.execute(null);
			 
			 EObject depThrowTaskArt;
			 Rule depThrowTaskArtRule =addDepClientSubThrowTaskArtUnit.getMultiRules().get(0);
			 Rule depThrowTaskArtOperations = depThrowTaskArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubThrowTaskArtUnitApp.getResultMatch().getMultiMatches(depThrowTaskArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubThrowTaskArtUnitApp.getResultMatch().getMultiMatches(depThrowTaskArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depThrowTaskArtOperations))
			 			{
						  depThrowTaskArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depThrowTaskArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/		 
	/*-------------------------Add a dependency between Nodes (case Message flow between Throw and Catch)-------------------------*/			 
			 Rule addDepClientSubThrowCatchArtUnit = (Rule)module_SecureLinks4.getUnit("AddDependencyMessageFlowThrowCatch");
			 RuleApplication addDepClientSubThrowCatchArtUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubThrowCatchArtUnit, null);
			 addDepClientSubThrowCatchArtUnitApp.execute(null);
			 
			 EObject depThrowCatchArt;
			 Rule depThrowCatchArtRule =addDepClientSubThrowCatchArtUnit.getMultiRules().get(0);
			 Rule depThrowCatchArtOperations = depThrowCatchArtRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubThrowCatchArtUnitApp.getResultMatch().getMultiMatches(depThrowCatchArtRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubThrowCatchArtUnitApp.getResultMatch().getMultiMatches(depThrowCatchArtRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depThrowCatchArtOperations))
			 			{
						  depThrowCatchArt= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depThrowCatchArt);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
	
	//***************SECURE LINKS GROUP 4: (B) Add dependencies between each client and processes node of the process has a secure message flow********/
	// ***********************************************************************************************************************************/		
	/*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubStartTargetUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubStartTarget");
			 RuleApplication addDepClientSubStartTargetUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubStartTargetUnit, null);
			 addDepClientSubStartTargetUnitApp.execute(null);
			 
			 EObject depStartTarget;
			 Rule depStartTargetRule =addDepClientSubStartTargetUnit.getMultiRules().get(0);
			 Rule depStartTargetOperations = depStartTargetRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubStartTargetUnitApp.getResultMatch().getMultiMatches(depStartTargetRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubStartTargetUnitApp.getResultMatch().getMultiMatches(depStartTargetRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depStartTargetOperations))
			 			{
						  depStartTarget= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depStartTarget);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
	/*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubTaskTargetUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubTaskTarget");
			 RuleApplication addDepClientSubTaskTargetUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubTaskTargetUnit, null);
			 addDepClientSubTaskTargetUnitApp.execute(null);
			 
			 EObject depTaskTarget;
			 Rule depTaskTargetRule =addDepClientSubTaskTargetUnit.getMultiRules().get(0);
			 Rule depTaskTargetOperations = depTaskTargetRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubTaskTargetUnitApp.getResultMatch().getMultiMatches(depTaskTargetRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubTaskTargetUnitApp.getResultMatch().getMultiMatches(depTaskTargetRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depTaskTargetOperations))
			 			{
						  depTaskTarget= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depTaskTarget);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
			 /*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubCatchTargetUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubCatchTarget");
			 RuleApplication addDepClientSubCatchTargetUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubCatchTargetUnit, null);
			 addDepClientSubCatchTargetUnitApp.execute(null);
			 
			 EObject depCatchTarget;
			 Rule depCatchTargetRule =addDepClientSubCatchTargetUnit.getMultiRules().get(0);
			 Rule depCatchTargetOperations = depCatchTargetRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubCatchTargetUnitApp.getResultMatch().getMultiMatches(depCatchTargetRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubCatchTargetUnitApp.getResultMatch().getMultiMatches(depCatchTargetRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depCatchTargetOperations))
			 			{
						  depCatchTarget= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depCatchTarget);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/

	/*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubTaskSourceUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubTaskSource");
			 RuleApplication addDepClientSubTaskSourceUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubTaskSourceUnit, null);
			 addDepClientSubTaskSourceUnitApp.execute(null);
			 
			 EObject depTaskSource;
			 Rule depTaskSourceRule =addDepClientSubTaskSourceUnit.getMultiRules().get(0);
			 Rule depTaskSourceOperations = depTaskSourceRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubTaskSourceUnitApp.getResultMatch().getMultiMatches(depTaskSourceRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubTaskSourceUnitApp.getResultMatch().getMultiMatches(depTaskSourceRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depTaskSourceOperations))
			 			{
						  depTaskSource= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depTaskSource);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
	/*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubEndSourceUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubEndSource");
			 RuleApplication addDepClientSubEndSourceUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubEndSourceUnit, null);
			 addDepClientSubEndSourceUnitApp.execute(null);
			 
			 EObject depEndSource;
			 Rule depEndSourceRule =addDepClientSubEndSourceUnit.getMultiRules().get(0);
			 Rule depEndSourceOperations = depEndSourceRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubEndSourceUnitApp.getResultMatch().getMultiMatches(depEndSourceRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubEndSourceUnitApp.getResultMatch().getMultiMatches(depEndSourceRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depEndSourceOperations))
			 			{
						  depEndSource= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depEndSource);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
			 
	/*-------------------------Add a dependency between Nodes -------------------------*/			 
			 Rule addDepClientSubThrowSourceUnit = (Rule)module_SecureLinks4.getUnit("AddDepClientSubThrowSource");
			 RuleApplication addDepClientSubThrowSourceUnitApp = new RuleApplicationImpl(engine, graph,
					 addDepClientSubThrowSourceUnit, null);
			 addDepClientSubThrowSourceUnitApp.execute(null);
			 
			 EObject depThrowSource;
			 Rule depThrowSourceRule =addDepClientSubThrowSourceUnit.getMultiRules().get(0);
			 Rule depThrowSourceOperations = depThrowSourceRule.getMultiRules().get(0);

			 
			 if(!addDepClientSubThrowSourceUnitApp.getResultMatch().getMultiMatches(depThrowSourceRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addDepClientSubThrowSourceUnitApp.getResultMatch().getMultiMatches(depThrowSourceRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(depThrowSourceOperations))
			 			{
						  depThrowSource= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(depThrowSource);
			 			}
				 }
			
			 }
     /*---------------------------------------------------------------------------------------------------------------------------*/
			 

    /*--------------------------------------------Add <<secrecy>> to Dependency (Confidentiality)--------------------------------------------------------------------------------------*/
			 Rule addSecureDependUnit = (Rule)module_SecureLinks4.getUnit("addSecureDependency");
			 RuleApplication addSecureDependApp = new RuleApplicationImpl(engine, graph,addSecureDependUnit, null);
			 addSecureDependApp.execute(null);
			 
			 EObject secrecyDependency;
			 Rule secrecyDependencyRule =addSecureDependUnit.getMultiRules().get(0);
			 Rule operationsSecrecyDependency = secrecyDependencyRule.getMultiRules().get(0);

			 if(!addSecureDependApp.getResultMatch().getMultiMatches(secrecyDependencyRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addSecureDependApp.getResultMatch().getMultiMatches(secrecyDependencyRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsSecrecyDependency))
			 			{
						  secrecyDependency= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(secrecyDependency);
			 			}
				 }
			
			 }		
/*---------------------------------------------------------------------------------------------------------------------------*/
			 
/*--------------------------------------------Add <<integrity>> to Dependency (Integrity)--------------------------------------------------------------------------------------*/

			 Rule addIntegrityDependencyUnit = (Rule)module_SecureLinks4.getUnit("addIntegrityDependency");
			 RuleApplication addIntegrityDependencyApp = new RuleApplicationImpl(engine, graph,
					 addIntegrityDependencyUnit, null);
			 addIntegrityDependencyApp.execute(null);
			 
			 EObject integrityDependency;
			 Rule integrityDependencyRule =addIntegrityDependencyUnit.getMultiRules().get(0);
			 Rule operationsIntegrityDependency = integrityDependencyRule.getMultiRules().get(0);

			 
			 if(!addIntegrityDependencyApp.getResultMatch().getMultiMatches(integrityDependencyRule).isEmpty())
			 {
				 for (Match firstRuleMultiMatch:addIntegrityDependencyApp.getResultMatch().getMultiMatches(integrityDependencyRule))
				 {  
					  for (Match secondRuleMultiMatch : firstRuleMultiMatch.getMultiMatches(operationsIntegrityDependency))
			 			{
						  integrityDependency= (EObject)secondRuleMultiMatch.getParameterValues().get(0);	
				   
			 				addToResource(integrityDependency);
			 			}
				 }
			
			 }		
         /*---------------------------------------------------------------------------------------------------------------------------*/
			 

		// *************************************************************************************************************************/
		// *************************************************************************************************************************/
		// ***************************************Save the transformation results***************************************************/
		// *************************************************************************************************************************/
		// *************************************************************************************************************************/

		EObject result = (EObject) createUmlModelUnitApp.getResultParameterValue("result");
		System.out.println("Generating UMLsec model for '" + bpmnModel + "'...");

		graph.addTree(RabacPackage.eINSTANCE);
		graph.addTree(UmlsecPackage.eINSTANCE);

		FileOutputStream fileOutputStream = null;
		ByteArrayOutputStream byteArrayOutputStream = null;

		// Save the result?
		if (saveResult) {
			String resultFile = bpmnModel.replaceFirst(".bpmn", "-generated-result.uml");

			rs.saveEObject(result, resultFile);
			Resource resource = rs.getResource(resultFile);

			// add matched objects to the resource
			System.out.println(objects.size() + " objects in \"objects\"");
			for (EObject ob : objects) {
				System.out.println("" + ob.toString());
				if (!resource.getContents().contains(ob))
					resource.getContents().add(ob);
				else
					System.out.println("Tried to add object twice: " + ob);
			}

			removeDuplicateAssociations((Model) result, resource);
			removeDuplicatePaths((Model) result, resource);
			removeDuplicateDependencies((Model) result, resource);
			removeDuplicateTagesFromCritical(resource);
			removeDuplicateAbacRequire(resource);
		    addRolesToAbac((Model) result, resource);
		    removeWhitespacesFromCritical((Model) result, resource);
		    removeWhitespacesFromClassNames((Model) result, resource);

			try {
				byteArrayOutputStream = new ByteArrayOutputStream();
				resource.save(byteArrayOutputStream, Collections.EMPTY_MAP);
				String output = byteArrayOutputStream.toString().replaceFirst(
						"xmlns:RABAC=\"http:///RABAC.ecore\" xmlns:UMLsec=\"http:///UMLsec.ecore\"",
						"xmlns:UMLsec=\"http:///schemas/UMLsec/_C2YE4E8dEeaXAd2ou1VF_w/3\" xmlns:RABAC=\"http:///schemas/RABAC/_7YYbEAa-EeWwtKn7NAM2pQ/0\" xmlns:ecore=\"http://www.eclipse.org/emf/2002/Ecore\" xsi:schemaLocation=\"http:///schemas/RABAC/_7YYbEAa-EeWwtKn7NAM2pQ/0 platform:/plugin/carisma.profile.umlsec.rabac/profile/RABAC.profile.uml#_7YaQQAa-EeWwtKn7NAM2pQ http:///schemas/UMLsec/_C2YE4E8dEeaXAd2ou1VF_w/3 platform:/plugin/carisma.profile.umlsec/profile/UMLsec.profile.uml#_C2ZTAE8dEeaXAd2ou1VF_w\"");
				fileOutputStream = new FileOutputStream("Transformed_serialized_profile.uml");
				fileOutputStream.write(output.getBytes());

				resource.save(new HashMap<String, String>());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Saved result in '" + resultFile + "'");
		}

	}
	
	private static void removeWhitespacesFromCritical(Model umlModel, Resource resource) {
		List<org.eclipse.uml2.uml.Class> classes = getOwnedClasses(umlModel);

		for (EObject obj : objects) {

			if (obj instanceof critical) {

				critical cri = (critical) obj;
				
			    EList<String> secrecyData=new BasicEList<String>(cri.getSecrecy());
			    List<org.eclipse.uml2.uml.Operation> operations = new BasicEList<org.eclipse.uml2.uml.Operation>(getOwnedOperations(classes));
			    
				cri.getSecrecy().clear();
				for (String secrecyData1:secrecyData)
				{
					for (org.eclipse.uml2.uml.Operation op:operations)
					{
						if(op.getName().equals(secrecyData1))
						{
							secrecyData1=getSignature(op);
						    cri.getSecrecy().add(secrecyData1);
						}
					}
					
				}
				
				EList<String> integrityData=new BasicEList<String>(cri.getIntegrity());
				cri.getIntegrity().clear();
				for (String integrityData1:integrityData)
				{
					for (org.eclipse.uml2.uml.Operation op:operations)
					{
						if(op.getName().equals(integrityData1))
						{
							integrityData1=getSignature(op);
						    cri.getIntegrity().add(integrityData1);
						}
					}
					
				}
				
		

	
			}
		}
		
	}
	
    public static String getSignature(Operation operation) {
        String result = operation.getName().replace(" ", "") + "(";
        Iterator<org.eclipse.uml2.uml.Parameter> it = operation.getOwnedParameters().iterator();
        while (it.hasNext()) {
            org.eclipse.uml2.uml.Parameter next = (org.eclipse.uml2.uml.Parameter) it.next();
            result += next.getName().replace(" ", "");
            result += ": ";
            result += next.getType().getName().replace(" ", "");
            if (it.hasNext())
                result += ", ";
        }
        result += ")";
        return result;
    } 

	//remove whitespaces from the class and operations names
	private static void removeWhitespacesFromClassNames(Model umlModel, Resource resource) {
		List<org.eclipse.uml2.uml.Class> classes = getOwnedClasses(umlModel);
		
		 for (org.eclipse.uml2.uml.Class class1:classes)
			  {
			    String className= class1.getName().replaceAll("\\s+","");
			    class1.setName(className);
			    List<org.eclipse.uml2.uml.Operation> operations = class1.getOwnedOperations();
			    for (org.eclipse.uml2.uml.Operation oper1:operations)
			    {
			    	String operationName=oper1.getName().replaceAll("\\s+","");
			    	oper1.setName(operationName);
			    	
			    }
				  
			  }

			
	}

	private static void removeDuplicateAssociations(Model umlModel,Resource resource) { // this method should be modified to be more simple
		List<Association> assos = getOwnedAssociations(umlModel);
		List<Association> del = new ArrayList<Association>();
		List<Association> keep = new ArrayList<Association>();
		for (Association asso1 : assos) {
			for (Association asso2 : keep) {
				if (asso1.getName().equals(asso2.getName())) {
					del.add(asso1);					
				}

			}
			
			if (!del.contains(asso1))
				keep.add(asso1);
		}
		
	
		
		umlModel.getPackagedElements().removeAll(del);
		
		
	}
	
	private static void removeDuplicatePaths(Model umlModel,Resource resource) { // this method should be modified to be more simple
		List<CommunicationPath> paths = getOwnedPaths(umlModel);
		ArrayList<EObject> delObjets = new ArrayList<EObject>();
		List<CommunicationPath> keep = new ArrayList<CommunicationPath>();
		List<CommunicationPath> deletePaths = new ArrayList<CommunicationPath>();

		for (CommunicationPath path1 : paths) {
			String[] partsPath1 = path1.getName().toString().split("_");;
			for (CommunicationPath path2 : keep) {
				String[] partsPath2 = path2.getName().toString().split("_");;
				if (((partsPath1[0].equals(partsPath2[0])) && (partsPath1[1].equals(partsPath2[1]))) || ((partsPath1[1].equals(partsPath2[0])) && (partsPath1[0].equals(partsPath2[1]))))
					deletePaths.add(path1);
			}
			if (!deletePaths.contains(path1))
				keep.add(path1);
		}
		
		//assign stereotypes to paths before removing duplicated paths.
		for (CommunicationPath path1:deletePaths)
		{  	
			String[] partsPath1 = path1.getName().toString().split("_");;

			for (EObject o : objects)
			{
				
				if (o instanceof Internet && ((Internet)o).getBase_CommunicationPath()==null)
			    {
			    	delObjets.add(o);
			     }
				if (o instanceof encrypted && ((encrypted)o).getBase_CommunicationPath()==null)
			    {
			    	delObjets.add(o);
			     }
				
				if (o instanceof encrypted && ((encrypted)o).getBase_CommunicationPath()!=null && ((encrypted) o).getBase_CommunicationPath().getName().equals(path1.getName()))
				{
					
					for (CommunicationPath path2:keep)
					{
						String[] partsPath2 = path2.getName().toString().split("_");;
						if(((partsPath1[0].equals(partsPath2[0])) && (partsPath1[1].equals(partsPath2[1]))) || ((partsPath1[1].equals(partsPath2[0])) && (partsPath1[0].equals(partsPath2[1]))))
						((encrypted)o).setBase_CommunicationPath(path2);
					}
				}
				
				if (o instanceof Internet && ((Internet)o).getBase_CommunicationPath()!=null && ((Internet) o).getBase_CommunicationPath().getName().equals(path1.getName()))
				{
					for (CommunicationPath path2:keep)
					{
						String[] partsPath2 = path2.getName().toString().split("_");;
					
						if(((partsPath1[0].equals(partsPath2[0])) && (partsPath1[1].equals(partsPath2[1]))) || ((partsPath1[1].equals(partsPath2[0])) && (partsPath1[0].equals(partsPath2[1]))))
						((Internet)o).setBase_CommunicationPath(path2);
					}

				
				}

					
			}
		}
		
		objects.removeAll(delObjets);
		for (EObject o : delObjets)
			resource.getContents().remove(o);
		
		delObjets.clear();
	    
		for (CommunicationPath path1:keep)
		{
			ArrayList<EObject> KeepStreo= new ArrayList<EObject>();
			for (EObject o:objects)
			{
				if(o instanceof encrypted && ((encrypted) o).getBase_CommunicationPath().equals(path1)) 
				{	
					if (KeepStreo.isEmpty())
                     {
				      	KeepStreo.add(o);
				    }
				   else
			     	delObjets.add(o);

				}
				
			}
			for (EObject o:objects)
			{
				if(o instanceof Internet && ((Internet) o).getBase_CommunicationPath().equals(path1))
				{
					if (KeepStreo.isEmpty())
                    {
				      	KeepStreo.add(o);
				    }
				   else
			     	delObjets.add(o);
				}
			}

		}
		
		objects.removeAll(delObjets);
		for (EObject o : delObjets)
			resource.getContents().remove(o);

		
		
		 for (CommunicationPath delAss:deletePaths)
		    {
				for (Property me : delAss.getMemberEnds()) {
					if (me.eContainer() instanceof Node) {
						Node container = (Node) me.eContainer();
						container.getOwnedAttributes().remove(me);
						
					}
				}
		    }
		
		for (CommunicationPath path1 : deletePaths){
			ArrayList<EObject> delObj2 = new ArrayList<EObject>();
			for (EObject o : objects) {
				if (o instanceof Internet && ((Internet)o).getBase_CommunicationPath() == path1) 
					delObj2.add(o);
				
				if (o instanceof encrypted && ((encrypted)o).getBase_CommunicationPath() == path1) 
					delObj2.add(o);
				
			}
			
			objects.removeAll(delObj2);
			for (EObject o : delObj2)
				resource.getContents().remove(o);
		}
		
		
		umlModel.getPackagedElements().removeAll(deletePaths);
	
		
	}
	

	private static void removeDuplicateDependencies(Model umlModel, Resource resource) {
		List<Dependency> assos = getOwnedDependencies(umlModel);
		ArrayList<EObject> delObjets = new ArrayList<EObject>();
		List<Dependency> keep = new ArrayList<Dependency>();
		List<Dependency> del = new ArrayList<Dependency>();
		
		for (Dependency dep1 : assos) {
			for (Dependency dep2 : keep) {
				if (dep1.getName().equals(dep2.getName()))
					del.add(dep1);
			}
			if (!del.contains(dep1))
				keep.add(dep1);
		}
		
		//assign stereotypes to dependencies before removing duplicated dependencies.
		for (Dependency dep1:del)
		{
			for (EObject o : objects)
			{
				if (o instanceof secrecy && ((secrecy)o).getBase_Dependency()==null)
			    {
			    	delObjets.add(o);
			     }
				if (o instanceof integrity && ((integrity)o).getBase_Dependency()==null)
			    {
			    	delObjets.add(o);
			     }
				
				if (o instanceof secrecy && ((secrecy)o).getBase_Dependency()!=null && ((secrecy) o).getBase_Dependency().getName().equals(dep1.getName()))
				{
					
					for (Dependency dep2:keep)
					{
						if(dep1.getName().equals(dep2.getName()))
						((secrecy)o).setBase_Dependency(dep2);
					}
				}
				if (o instanceof integrity && ((integrity)o).getBase_Dependency()!=null && ((integrity) o).getBase_Dependency().getName().equals(dep1.getName()))
				{
					
					for (Dependency dep2:keep)
					{
						if(dep1.getName().equals(dep2.getName()))
						((integrity)o).setBase_Dependency(dep2);
					}
				}

					
			}
		}
		
		objects.removeAll(delObjets);
		for (EObject o : delObjets)
			resource.getContents().remove(o);
		
		delObjets.clear();
		
		
		for (Dependency dep1:keep)
		{
			ArrayList<EObject> KeepStreoSec= new ArrayList<EObject>();
			ArrayList<EObject> KeepStreoInt=new ArrayList<EObject>();

			for (EObject o:objects)
			{
				if(o instanceof secrecy && ((secrecy) o).getBase_Dependency().equals(dep1)) 
				{	
					if (KeepStreoSec.isEmpty())
                     {
						KeepStreoSec.add(o);
				    }
				   else
			     	delObjets.add(o);

				}
				
			}
			for (EObject o:objects)
			{
				if(o instanceof integrity && ((integrity) o).getBase_Dependency().equals(dep1))
				{
					if (KeepStreoInt.isEmpty())
                    {
						KeepStreoInt.add(o);
				    }
				   else
			     	delObjets.add(o);
				}
			}

		}
		
		objects.removeAll(delObjets);
		for (EObject o : delObjets)
			resource.getContents().remove(o);
		
		
		for (Dependency dep1 : del){
			ArrayList<EObject> delObj2 = new ArrayList<EObject>();
			for (EObject o : objects) {
				if (o instanceof secrecy && ((secrecy)o).getBase_Dependency() == dep1) 
					delObj2.add(o);
				
				if (o instanceof integrity && ((integrity)o).getBase_Dependency() == dep1) 
					delObj2.add(o);
				
				if (o instanceof send && ((send)o).getBase_Dependency() == dep1) 
					delObj2.add(o);
				
				if (o instanceof call && ((call)o).getBase_Dependency() == dep1) 
					delObj2.add(o);
				
			}
			
			objects.removeAll(delObj2);
			for (EObject o : delObj2)
				resource.getContents().remove(o);
		}
		
		
		umlModel.getPackagedElements().removeAll(del);
		
		
	}

	private static List<Association> getOwnedAssociations(Model umlModel) {
		List<Association> result = new ArrayList<Association>();
		for (Element e : umlModel.getPackagedElements())
			if (e instanceof Association && !(e instanceof CommunicationPath))
				result.add((Association) e);
		return result;
	}
	
	private static List<CommunicationPath> getOwnedPaths(Model umlModel) {
		List<CommunicationPath> result = new ArrayList<CommunicationPath>();
		for (Element e : umlModel.getPackagedElements())
			if (e instanceof CommunicationPath)
				result.add((CommunicationPath) e);
		return result;
	}

	private static List<Dependency> getOwnedDependencies(Model umlModel) {
		List<Dependency> result = new ArrayList<Dependency>();
		for (Element e : umlModel.getPackagedElements())
			if (e instanceof Dependency && !(e instanceof Deployment))
				result.add((Dependency) e);
		return result;
	}

	private static void removeDuplicateTagesFromCritical(Resource resource) {
		Map<Class, Set<critical>> class2crit = getClass2Crit(objects);
		EList<critical> keep = new BasicEList<critical>();
		EList<critical> del = new BasicEList<critical>();
		ArrayList<EObject> delObj = new ArrayList<EObject>();
		
		for (EObject obj : objects) {
			if (obj instanceof critical) {
				critical cri = (critical) obj;
				if (cri.getIntegrity().isEmpty() && cri.getSecrecy().isEmpty()) {
					del.add(cri);
					delObj.add(cri);
				}
				if (!cri.getSecrecy().isEmpty()) {
					String sec = cri.getSecrecy().get(0);
					for (critical cri2 : class2crit.get(cri.getBase_Class())) {
						if (keep.contains(cri2) && !cri2.getSecrecy().isEmpty()
								&& cri2.getSecrecy().get(0).equals(sec)) {
							del.add(cri);
							delObj.add(cri);
							break;
						}
					}
				}
				if (!cri.getIntegrity().isEmpty()) {
					String sec = cri.getIntegrity().get(0);
					for (critical cri2 : class2crit.get(cri.getBase_Class())) {
						if (keep.contains(cri2) && !cri2.getIntegrity().isEmpty()
								&& cri2.getIntegrity().get(0).equals(sec)) {
							del.add(cri);
							delObj.add(cri);
							break;
						}
					}
				}
				if (!del.contains(cri))
					keep.add(cri);
			}
		}
		objects.removeAll(delObj);
		for (EObject o : delObj)
			resource.getContents().remove(o);
		
		// merge critical stereotypes reference the same data object
		for (EObject obj:objects)
		{	
			if (obj instanceof critical)
			{   
				critical cri = (critical) obj;
				org.eclipse.uml2.uml.Class baseClass = cri.getBase_Class();
				String sec=new String();
				String integ=new String();
				
				if(!cri.getSecrecy().isEmpty())
				   sec=cri.getSecrecy().get(0);
				      
				if(!cri.getIntegrity().isEmpty())
				     integ=cri.getIntegrity().get(0);
				     
				for (critical crit:keep)
				{   
		
					if (crit.getBase_Class().getName().equals(baseClass.getName()))
					{  
						if (!sec.isEmpty() && !crit.getSecrecy().contains(sec))
								crit.getSecrecy().add(sec);
						
						if (!integ.isEmpty() && !crit.getIntegrity().contains(integ))
							     crit.getIntegrity().add(integ);
					}
					
				}
			}
			
		}
		
		
      // remove duplicated critical that still reference the same data object
		EList<critical> keep2 = new BasicEList<critical>();
		delObj.clear();
	    for(EObject obj:objects)
	    {
	    	if (obj instanceof critical)
	    	{
	    		critical cri = (critical) obj;
	    		for (critical crit:keep2)
	    		{
	    			if(cri.getBase_Class().getName().equals(crit.getBase_Class().getName()))
	    			{
	    				delObj.add(cri);
	    			}
	    		}
	    		if (!delObj.contains(cri))
					keep2.add(cri);	
	    	}
	    }
	    objects.removeAll(delObj);
		for (EObject o : delObj)
			resource.getContents().remove(o);
		
		
}
	
	private static void removeDuplicateAbacRequire(Resource resource) {
		Map<Operation, Set<abacRequire>> oper2Req = getOperationRequire(objects);
		EList<abacRequire> keep = new BasicEList<abacRequire>();
		EList<abacRequire> del = new BasicEList<abacRequire>();
		ArrayList<EObject> delObj = new ArrayList<EObject>();
		
		for (EObject obj : objects) {
			if (obj instanceof abacRequire) {
				abacRequire req = (abacRequire) obj;
				if (req.getRight().isEmpty()) {
					del.add(req);
					delObj.add(req);
				}
				if (!req.getRight().isEmpty()) {
					String right = req.getRight().toString();
					for (abacRequire req2 : oper2Req.get(req.getBase_Operation())) {
						if (keep.contains(req2) && !req2.getRight().isEmpty()
								&& req2.getRight().equals(right)) {
							del.add(req);
							delObj.add(req);
							break;
						}
					}
				}
				if (!del.contains(req))
					keep.add(req);
			}
		}
		objects.removeAll(delObj);
		for (EObject o : delObj)
			resource.getContents().remove(o);
		

		for (EObject obj:objects)
		{	
			if (obj instanceof abacRequire)
			{   
				abacRequire req = (abacRequire) obj;
				org.eclipse.uml2.uml.Operation baseOperation = req.getBase_Operation();
				String right=new String();
				
				if(!req.getRight().isEmpty())
				   right=req.getRight().toString();
				     
				for (abacRequire require:keep)
				{   
		
					if (require.getBase_Operation().getName().equals(baseOperation.getName()))
					{  
						if (!right.isEmpty() && !require.getRight().toString().contains(right)&& !right.toString().contains(require.getRight().toString()))
						{
							     
							     right=require.getRight().concat(right);
							     require.setRight(right);
								}
						
					}
					
				}
			}
			
		}
		
		Map<Operation, Set<abacRequire>> operReq = getOperationRequire(objects);
		delObj.clear();
		EList<abacRequire> keep2 = new BasicEList<abacRequire>();
		EList<Operation> keepProOper = new BasicEList<Operation>();
		for (EObject obj : objects) {
			int length=0;
			keep2.clear();
			if (obj instanceof abacRequire){
				abacRequire require = (abacRequire) obj;
				if (!keepProOper.contains(require.getBase_Operation()))
				{
					keepProOper.add(require.getBase_Operation());
					for (abacRequire req : operReq.get(require.getBase_Operation())) {
						if (req.getRight().length()>length) 
						{
							
							length=req.getRight().length();
							if(!keep2.isEmpty())
							{   
								delObj.add(keep2.get(0));
							    keep2.remove(0);
							    keep2.add(req);
							}
							else 
								 keep2.add(req);
								
						}
						else
							delObj.add(req);
					}
				}
			
			}
		}
	    objects.removeAll(delObj);
		for (EObject o : delObj)
			resource.getContents().remove(o);
	}
	
	
	
	private static Map<org.eclipse.uml2.uml.Class, Set<critical>> getClass2Crit(List<EObject> objects2) {
		Map<org.eclipse.uml2.uml.Class, Set<critical>> result = new HashMap<org.eclipse.uml2.uml.Class, Set<critical>>();
		for (EObject obj : objects2) {
			if (obj instanceof critical) {
				critical crit = (critical) obj;
				org.eclipse.uml2.uml.Class baseClass = crit.getBase_Class();
				Set<critical> setForBaseClass = result.get(baseClass);
				if (setForBaseClass == null) {
					setForBaseClass = new HashSet<critical>();
					result.put(baseClass, setForBaseClass);
				}
				setForBaseClass.add(crit);
			}
		}
		return result;
	}

	private static Map<org.eclipse.uml2.uml.Operation, Set<abacRequire>> getOperationRequire(List<EObject> objects2) {
		Map<org.eclipse.uml2.uml.Operation, Set<abacRequire>> result = new HashMap<org.eclipse.uml2.uml.Operation, Set<abacRequire>>();
		for (EObject obj : objects2) {
			if (obj instanceof abacRequire) {
				abacRequire req = (abacRequire) obj;
				org.eclipse.uml2.uml.Operation baseOperation = req.getBase_Operation();
				Set<abacRequire> setForBaseOperation = result.get(baseOperation);
				if (setForBaseOperation == null) {
					setForBaseOperation = new HashSet<abacRequire>();
					result.put(baseOperation, setForBaseOperation);
				}
				setForBaseOperation.add(req);
			}
		}
		return result;
	}


	private static void addRolesToAbac(Model umlModel, Resource resource) {
		List<org.eclipse.uml2.uml.Class> classes = getOwnedClasses(umlModel);
		for (EObject obj:objects)
		{    String roles=new String();
			if (obj instanceof abac)
			{ abac abacPolicy= (abac)obj;
			  org.eclipse.uml2.uml.Class abacClass= abacPolicy.getBase_Class();
			  
			  for (org.eclipse.uml2.uml.Class class1:classes)
			  {
				  
				  if (class1.getSuperClasses().contains(abacClass))
				  {   
					  roles+="(Subject,"+class1.getName().toString()+"),";
					 }
				  else
				  {
					  List<org.eclipse.uml2.uml.Class> hirarClasses =class1.getSuperClasses();
					  for (org.eclipse.uml2.uml.Class class2:hirarClasses)
					  {
						  if (class2.getSuperClasses().contains(abacClass))
						      {
							     roles+="(Subject,"+class1.getName().toString()+"),";
						      }
					  }
				  }

			  }
			abacPolicy.setRoles("{"+roles+"}");
			}
		}
	}
	
	
	private static List<org.eclipse.uml2.uml.Class> getOwnedClasses(Model umlModel) {
		List<org.eclipse.uml2.uml.Class> result = new ArrayList<org.eclipse.uml2.uml.Class>();
		for (Element e : umlModel.getPackagedElements())
			if (e instanceof org.eclipse.uml2.uml.Class)
				result.add((org.eclipse.uml2.uml.Class) e);
		return result;
	}
	
	private static List<org.eclipse.uml2.uml.Operation> getOwnedOperations(List<org.eclipse.uml2.uml.Class> classes) {
		List<org.eclipse.uml2.uml.Operation> result = new ArrayList<org.eclipse.uml2.uml.Operation>();
		List<org.eclipse.uml2.uml.Operation> operations= new ArrayList<org.eclipse.uml2.uml.Operation>();

		for (Class cl : classes)
		{
			operations=cl.getOwnedOperations();
			for (Operation op:operations)
			{
				result.add(op);
			}
		}
		
		return result;
	}
	
	private static Property getAttribute(Stereotype keepEl, String attributeName) {
		for (Property p : keepEl.getAttributes()) {
			if (p.getName().equals(attributeName))
				return p;
		}
		return null;
	}

	public static void addToResource(EObject obj) {

		if (obj != null) {
			objects.add(obj);
		}

	}

	public static void main(String[] args) {
		run(PATH, EXAMPLE, true); // we assume the working directory is the root
									// of the examples plug-in
	}

	@Test
	public void main() {
		run(PATH, EXAMPLE, true); // we assume the working directory is the root
									// of the examples plug-in
	}
	
//	public void transformSecBPMNtoUMLSec(String inputPath, String outputPath) {
//		
//	}
//	
//    public void transformSecBPMNtoUMLSec(BPMNDiagram bpmnDiagram, String outputPath) {
//		
//	}
}
