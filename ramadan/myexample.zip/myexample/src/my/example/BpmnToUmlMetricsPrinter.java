/**
 * <copyright>
 * Copyright (c) 2010-2014 Henshin developers. All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 which 
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * </copyright>
 */
package my.example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.bpmn2.Bpmn2Package;
import org.eclipse.bpmn2.DataAssociation;
import org.eclipse.bpmn2.DataObject;
import org.eclipse.bpmn2.Event;
import org.eclipse.bpmn2.MessageEventDefinition;
import org.eclipse.bpmn2.MessageFlow;
import org.eclipse.bpmn2.Participant;
import org.eclipse.bpmn2.Task;
import org.eclipse.bpmn2.util.Bpmn2ResourceFactoryImpl;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.henshin.interpreter.EGraph;
import org.eclipse.emf.henshin.interpreter.Engine;
import org.eclipse.emf.henshin.interpreter.impl.EGraphImpl;
import org.eclipse.emf.henshin.interpreter.impl.EngineImpl;
import org.eclipse.emf.henshin.model.Module;
import org.eclipse.emf.henshin.model.Unit;
import org.eclipse.emf.henshin.model.resource.HenshinResourceSet;
import org.eclipse.emf.henshin.trace.TracePackage;
import org.eclipse.uml2.uml.Artifact;
import org.eclipse.uml2.uml.Association;
import org.eclipse.uml2.uml.Class;
import org.eclipse.uml2.uml.CommunicationPath;
import org.eclipse.uml2.uml.Dependency;
import org.eclipse.uml2.uml.Deployment;
import org.eclipse.uml2.uml.Node;
import org.eclipse.uml2.uml.Operation;
import org.eclipse.uml2.uml.Profile;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.UMLPackage;
import org.junit.Test;

import carisma.profile.umlsec.rabac.RabacPackage;
import carisma.profile.umlsec.rabac.abacRequire;
import carisma.profile.umlsec.UmlsecPackage;
import carisma.profile.umlsec.critical;
import carisma.profile.umlsec.encrypted;
import carisma.profile.umlsec.integrity;
import carisma.profile.umlsec.secrecy;

/**
 * Ecore2UML example for Henshin.
 * 
 * @author Christian Krause
 */
public class BpmnToUmlMetricsPrinter {

	public static final String PATH = "src/my/example";
	public static final String[] BPMN_EXAMPLES = { "example.bpmn","Flightplan.bpmn","Landing.bpmn","Externalservices1.bpmn","Externalservices2.bpmn"};
	public static final String[] UML_EXAMPLES = {  "example.uml","Flightplan.uml","Landing.uml","Externalservices1.uml","Externalservices2.uml"};
	public static List<EObject> objects = new ArrayList<EObject>();

	/**
	 * Run the Ecore2UML conversion.
	 * 
	 * @param path
	 *            Relative path to the model files.
	 * @param ecore
	 *            The Ecore file.
	 * @param saveResult
	 *            Whether the result should be saved.
	 */
	public static void main(String... args) {
		UMLPackage.eINSTANCE.getName();
		Bpmn2Package.eINSTANCE.getName();
		TracePackage.eINSTANCE.getName();
		UmlsecPackage.eINSTANCE.getName();
		RabacPackage.eINSTANCE.getName();

		// Load the transformation module and the input model:
		HenshinResourceSet rs = new HenshinResourceSet(PATH);
		rs.getPackageRegistry().put("http://www.omg.org/spec/BPMN/20100524/MODEL-XMI", Bpmn2Package.eINSTANCE);
		rs.getPackageRegistry().put("http://www.eclipse.org/uml2/2.0.0/UML", UMLPackage.eINSTANCE);
		rs.getPackageRegistry().put("http://www.umlsec.de/profiles/UMLsec", UmlsecPackage.eINSTANCE);
		rs.getPackageRegistry().put("http:///schemas/UMLsec/_C2YE4E8dEeaXAd2ou1VF_w/3", UmlsecPackage.eINSTANCE);
		rs.getPackageRegistry().put("http://www.umlsec.de/profiles/UMLsec/RABAC", RabacPackage.eINSTANCE);
		rs.getPackageRegistry().put("http:///schemas/RABAC/_7YYbEAa-EeWwtKn7NAM2pQ/0", RabacPackage.eINSTANCE);
		rs.registerDynamicEPackages("secbpmn.ecore");

		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("bpmn", new Bpmn2ResourceFactoryImpl());
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put("uml", new XMIResourceFactoryImpl());



		/*-----------------------------------------------Add UMLsec graph to input graph (EGraph instance)--------------------------------------------------*/

		Resource umlSecProfileResource = rs
				.createResource(URI.createURI("platform:/plugin/carisma.profile.umlsec/profile/UMLsec.profile.uml"));
		try {
			umlSecProfileResource.load(Collections.EMPTY_MAP);
//			graph.addTree((Profile) umlSecProfileResource.getContents().get(0));
		} catch (IOException e) {
			e.printStackTrace();
		}

		/*---------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*-----------------------------------------------Add RABAC graph to input graph (EGraph instance)--------------------------------------------------*/

		Resource rabacProfileResource = rs.createResource(
				URI.createURI("platform:/plugin/carisma.profile.umlsec.rabac/profile/RABAC.profile.uml"));
		try {
			rabacProfileResource.load(Collections.EMPTY_MAP);
//			graph.addTree((Profile) rabacProfileResource.getContents().get(0));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		for (String example :  new ArrayList<String>(Arrays.asList(BPMN_EXAMPLES))) {
			Resource exampleModel = rs.getResource(example);
			printSecBPMNMetrics(exampleModel);
		}
		System.out.println();
		for (String example : new ArrayList<String>(Arrays.asList(UML_EXAMPLES))) {
			Resource exampleModel = rs.getResource(example);
			printUMLSecMetrics(exampleModel);
		}
		


	}

	private static void printUMLSecMetrics(Resource exampleModel) {
		int nodes = 0;
		int paths=0;
		int artifacts=0;
		int classes = 0;
		int operations = 0;
		int associations = 0;
		int dependencies = 0;
		int abacrequires = 0;
		int criticals = 0;
		int secrecyTags = 0;
		int integrityTags = 0;
		int ecnryptedPaths=0;
		int secrecyDep=0;
		int integrityDep=0;

		TreeIterator<EObject> it = exampleModel.getAllContents();
		while (it.hasNext()) {
			EObject o = it.next();

			if (o instanceof Node)
				  nodes++;
			if (o instanceof Artifact)
				  artifacts++;
			if (o instanceof CommunicationPath)
				paths++;
			if (o instanceof Class && !(o instanceof Node))
				  classes++;
			if (o instanceof Operation)
				operations++;
			if (o instanceof Association && !(o instanceof CommunicationPath))
				associations++;
			if (o instanceof Dependency && !(o instanceof Deployment))
				dependencies++;
			if (o instanceof abacRequire)
				abacrequires++;
			if (o instanceof critical) {
				criticals++;
				secrecyTags += ((critical) o).getSecrecy().size();
				integrityTags += ((critical) o).getIntegrity().size();
			}
			if (o instanceof encrypted)
				 ecnryptedPaths++;
			if (o instanceof secrecy)
				 secrecyDep++;
			if (o instanceof integrity)
				 integrityDep++;
			
		}
		System.out.println(
			    "nodes:"+nodes + " " +
			    "artifacts:"+artifacts+ " " +
			    "paths:"+paths + " " +
			    "classes:"+classes + " " +
			    "operations:"+operations + " " +
			    "associations:"+associations + " " +
			    "dependencies:"+dependencies + " " +
			    "abacrequires:"+abacrequires + " " +
			    "criticals:"+criticals + " " +
			    "secrecyTags:"+secrecyTags + " " +
			    "integrityTags:"+integrityTags + " " +
			    "ecnryptedPaths:"+ecnryptedPaths + " " +
			    "secrecyDep:"+secrecyDep + " " +
			    "integrityDep:"+integrityDep);
		
	}

	private static void printSecBPMNMetrics(Resource exampleModel) {
		int pools = 0;
		int dataObjects = 0;
		int tasks = 0;
		int events = 0;
		int dataAssociations = 0;
		int messageFlows=0;
		int securityAssociation=0;
		int accountability = 0;
		int confidentiality = 0;
		int integrity = 0;

		TreeIterator<EObject> it = exampleModel.getAllContents();
		while (it.hasNext()) {
			EObject o = it.next();

			if (o instanceof Participant)
				pools++;
			if (o instanceof DataObject)
				dataObjects++;
			if (o instanceof Task)
				tasks++;
			if (o instanceof Event)
		        events++;
			if (o instanceof DataAssociation)
				dataAssociations++;
			if (o instanceof MessageFlow)
				messageFlows++;
			if ( o.eClass().getName().toLowerCase().equals("securityassociation"))
				securityAssociation++;
			if (o.eClass().getName().toLowerCase().equals("accountability"))
				accountability++;
			if (o.eClass().getName().toLowerCase().equals("confidentiality"))
				confidentiality++;
			if (o.eClass().getName().toLowerCase().equals("integrity"))
				integrity++;
		}

		System.out.println( "pools:"+(pools-1) + " " +  "dataObjects:"+dataObjects + " " +  "tasks:"+tasks + " " +  "events:"+events + " " +  "dataAssociations:"+dataAssociations + " "
				+  "messageFlows:"+messageFlows + " "+  "securityAssociation:"+securityAssociation + " "+  "accountability:"+accountability + " " +  "confidentiality:"+confidentiality + " " +  "integrity:"+integrity

		);

	}




	public static void addToResource(EObject obj) {

		if (obj != null) {
			objects.add(obj);
		}

	}

	@Test
	public void testBla() {
		main(" ");
	}

}
